package com.kuainiu.oes.xtp.util;

import com.kuainiu.oes.xtp.biz.bean.OrderInBean;
import com.kuainiu.oes.xtp.facade.bean.TodayOrderBean;
import com.kuainiu.oes.xtp.facade.request.OrderCancelReq;
import com.kuainiu.oes.xtp.facade.request.OrderCommitReq;
import com.kuainiu.oes.xtp.common.util.BeanMapUtils;
import com.kuainiu.oes.xtp.facade.request.TodayOrderQryReq;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 3:07 PM
 */
public class BizInBeanUtils {
    public static OrderInBean buildOrderInBean(OrderCommitReq request) {
        OrderInBean inBean = new OrderInBean();
        BeanMapUtils.map(request, inBean);
        return inBean;
    }

    public static OrderInBean buildOrderInBean(OrderCancelReq request) {
        OrderInBean inBean = new OrderInBean();
        BeanMapUtils.map(request, inBean);
        return inBean;
    }

    public static TodayOrderBean buildTodayOrderBean(TodayOrderQryReq request) {
        TodayOrderBean inBean=new TodayOrderBean();
        BeanMapUtils.map(request, inBean);
        return inBean;
    }
}
