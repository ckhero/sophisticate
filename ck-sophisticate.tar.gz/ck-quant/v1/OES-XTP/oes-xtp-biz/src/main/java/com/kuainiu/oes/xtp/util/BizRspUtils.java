package com.kuainiu.oes.xtp.util;

import com.kuainiu.oes.xtp.biz.bean.OrderOutBean;
import com.kuainiu.oes.xtp.common.enums.IsWithdrawCode;
import com.kuainiu.oes.xtp.common.enums.OrderStatusType;
import com.kuainiu.oes.xtp.common.enums.OrderSubmitStatusType;
import com.kuainiu.oes.xtp.common.util.BeanMapUtils;
import com.kuainiu.oes.xtp.common.util.QtDateUtils;
import com.kuainiu.oes.xtp.facade.bean.TodayOrderBean;
import com.kuainiu.oes.xtp.facade.bean.TodayTransBean;
import com.kuainiu.oes.xtp.facade.response.OrderCancelRsp;
import com.kuainiu.oes.xtp.facade.response.OrderCommitRsp;
import com.kuainiu.oes.xtp.facade.response.TodayOrderQryRsp;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.OrderResponseWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.TradeResponseWrapper;
import com.kuainiu.qt.trans.facade.code.stk.StkOrderStatusCode;
import com.kuainiu.qt.trans.facade.code.stk.StkOrderSubmitStatusCode;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 3:09 PM
 */
@Slf4j
public class BizRspUtils {
    public static OrderCommitRsp buildOrderCommitRsp(OrderOutBean order) {
        OrderCommitRsp response = new OrderCommitRsp();
        BeanMapUtils.map(order, response);
        return response;
    }

    public static OrderCancelRsp buildOrderCancelRsp(OrderOutBean order) {
        OrderCancelRsp response = new OrderCancelRsp();
        BeanMapUtils.map(order, response);
        return response;
    }

    public static TodayOrderQryRsp buildPATodayOrderQryResponse(TodayOrderBean orderOutBean, List<TodayTransBean> transOutBeans) {
        TodayOrderQryRsp rsp =new TodayOrderQryRsp();
        rsp.setTodayOrderBean(orderOutBean);
        rsp.setTodayTransBeanList(transOutBeans);
        return rsp;
    }

    public static TodayOrderBean buildTodayOrderBean(List<OrderResponseWrapper> responseMsgs) {
        TodayOrderBean order =new TodayOrderBean();
        if(CollectionUtils.isNotEmpty(responseMsgs)){
            OrderResponseWrapper response=responseMsgs.get(0);
//        String qtOrderId = String.valueOf(response.getOrderClientId());
            String channelOrderId = response.getOrderXtpId();
            if (response.getCancelTime() != 0) {
                Date cancelTime = QtDateUtils.convertToDate(response.getCancelTime());
                order.setOrderCancelTime(cancelTime);
            }

            if (response.getInsertTime() != 0) {
                Date confirmTime = QtDateUtils.convertToDate(response.getInsertTime());
                order.setOrderConfirmTime(confirmTime);

            }

            String qtTransOrderStatus = null;
            String qtTransOrderSubmitStatus = null;

            OrderStatusType xtpOrderStatus = response.getOrderStatusType();
            OrderSubmitStatusType xtpOrderSubmitStatus = response.getOrderSubmitStatusType();
            switch (xtpOrderSubmitStatus) {
                case XTP_ORDER_SUBMIT_STATUS_INSERT_ACCEPTED:
                    qtTransOrderSubmitStatus = StkOrderSubmitStatusCode.CONFIRM.getCode();
                    qtTransOrderStatus = StkOrderStatusCode.WAIT_TRANS.getCode();
                    break;

                case XTP_ORDER_SUBMIT_STATUS_INSERT_REJECTED:
                    qtTransOrderSubmitStatus = StkOrderSubmitStatusCode.VOID.getCode();
                    qtTransOrderStatus = StkOrderStatusCode.VOID.getCode();
                    break;

                default:
                    break;
            }

            if (!xtpOrderSubmitStatus.equals(OrderSubmitStatusType.XTP_ORDER_SUBMIT_STATUS_INSERT_REJECTED)) {
                switch (xtpOrderStatus) {
                    case XTP_ORDER_STATUS_ALLTRADED:
                        qtTransOrderSubmitStatus = StkOrderSubmitStatusCode.FINISH.getCode();
                        qtTransOrderStatus = StkOrderStatusCode.FINISH.getCode();
                        break;

                    case XTP_ORDER_STATUS_PARTTRADEDQUEUEING:
                    case XTP_ORDER_STATUS_PARTTRADEDNOTQUEUEING:
                        qtTransOrderSubmitStatus = StkOrderSubmitStatusCode.FINISH.getCode();
                        qtTransOrderStatus = StkOrderStatusCode.PART_CANCEL.getCode();
                        break;

                    case XTP_ORDER_STATUS_CANCELED:
                        qtTransOrderSubmitStatus = StkOrderSubmitStatusCode.FINISH.getCode();
                        qtTransOrderStatus = StkOrderStatusCode.CANCEL.getCode();
                        break;

                    case XTP_ORDER_STATUS_REJECTED:
                        qtTransOrderSubmitStatus = StkOrderSubmitStatusCode.VOID.getCode();
                        qtTransOrderStatus = StkOrderStatusCode.VOID.getCode();
                        break;

                    default:
                        log.info("[Service]order notify, unknow xtp order status");
                        break;
                }
            }

            order.setChannelOrderId(channelOrderId);
//        order.setQtOrderId(qtOrderId);
            order.setStatus(qtTransOrderStatus);
            order.setSubmitStatus(qtTransOrderSubmitStatus);
        }
        return order;
    }

    public static List<TodayTransBean> buildTodayTradeBean(List<TradeResponseWrapper> responseMsgs) {
        List<TodayTransBean> rsps=new ArrayList<>();
        if(CollectionUtils.isNotEmpty(responseMsgs)){
            responseMsgs.stream().forEach(resp->rsps.add(buildTodayTransOutBean(resp)));
        }
        return rsps;
    }

    private static TodayTransBean buildTodayTransOutBean(TradeResponseWrapper response) {
        if(response==null){
            return null;
        }
        TodayTransBean trade=new TodayTransBean();
        //成交数量
        Integer transQty = (int) response.getQuantity();
        //渠道订单号
        String channelOrderId = response.getOrderXtpId();
        //交易流水号
        String channelTransId = response.getExecId();
        //交易价格
        BigDecimal transPrice = new BigDecimal(response.getPrice()).setScale(6, RoundingMode.HALF_UP);;
        //交易时间
        Date transTime = QtDateUtils.convertToDate(response.getTradeTime());

        trade.setTransQty(transQty);
        trade.setChannelOrderId(channelOrderId);
        trade.setChannelTransId(channelTransId);
        trade.setTransPrice(transPrice);
        trade.setTransTime(transTime);
        trade.setIsWithdraw(IsWithdrawCode.NO.getCode());
        return trade;
    }
}
