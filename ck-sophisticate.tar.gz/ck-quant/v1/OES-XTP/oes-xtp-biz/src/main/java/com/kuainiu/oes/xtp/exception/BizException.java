package com.kuainiu.oes.xtp.exception;

import com.kuainiu.oes.xtp.facade.code.OesXtpRspCode;
import com.kuainiu.oes.xtp.facade.response.BaseOesXtpRsp;
import com.kuainiu.oes.xtp.common.util.CommonConstant;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.text.MessageFormat;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/29
 * Time: 5:09 PM
 */
@Data
public class BizException extends Exception {
    private OesXtpRspCode OesXtpRspCode;

    private String code;

    private String msg;

    public BizException(OesXtpRspCode OesXtpRspCode){
        this.OesXtpRspCode = OesXtpRspCode;
        this.code = OesXtpRspCode.getCode();
        this.msg = OesXtpRspCode.getMsg();
    }

    public BizException(OesXtpRspCode OesXtpRspCode, Throwable t){
        super(t);
        this.OesXtpRspCode = OesXtpRspCode;
        this.code = OesXtpRspCode.getCode();
        this.msg = OesXtpRspCode.getMsg();
    }

    public BizException(OesXtpRspCode OesXtpRspCode, String msg, Throwable t){
        super(t);
        this.OesXtpRspCode = OesXtpRspCode;
        this.code = OesXtpRspCode.getCode();
        this.msg = OesXtpRspCode.getMsg();
        if (StringUtils.isNotBlank(msg)) {
            this.msg += CommonConstant.COMMA + msg;
        }
    }

    public BizException(OesXtpRspCode OesXtpRspCode, String msg){
        this.OesXtpRspCode = OesXtpRspCode;
        this.code = OesXtpRspCode.getCode();
        this.msg = OesXtpRspCode.getMsg();
        if (StringUtils.isNotBlank(msg)) {
            this.msg += CommonConstant.COMMA + msg;
        }
    }
    public void exceptionToResponse(BaseOesXtpRsp response){
        response.setCode(this.getCode());
        response.setMsg(this.getMsg());
        response.setException(this);
    }

    public BizException(String pattern, Object... arguments){
        super(MessageFormat.format(pattern, arguments));
    }
}
