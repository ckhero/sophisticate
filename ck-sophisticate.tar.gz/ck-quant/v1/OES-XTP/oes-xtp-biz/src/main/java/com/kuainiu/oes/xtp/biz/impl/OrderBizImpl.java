package com.kuainiu.oes.xtp.biz.impl;

import com.kuainiu.oes.xtp.exception.ServiceException;
import com.kuainiu.oes.xtp.facade.bean.TodayOrderBean;
import com.kuainiu.oes.xtp.facade.bean.TodayTransBean;
import com.kuainiu.oes.xtp.service.OrderService;
import com.kuainiu.oes.xtp.biz.OrderBiz;
import com.kuainiu.oes.xtp.biz.bean.OrderInBean;
import com.kuainiu.oes.xtp.biz.bean.OrderOutBean;
import com.kuainiu.oes.xtp.exception.BizException;
import com.kuainiu.oes.xtp.facade.code.OesXtpRspCode;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.OrderCancelRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.OrderInsertRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.OrderQryRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.TradeQryRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.BaseResponseWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.OrderResponseWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.TradeResponseWrapper;
import com.kuainiu.oes.xtp.util.BizRspUtils;
import com.kuainiu.oes.xtp.util.XtpReqUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 2:39 PM
 */
@Service
public class OrderBizImpl implements OrderBiz {

    @Autowired
    OrderService orderService;

    @Override
    public OrderOutBean commitOrder(OrderInBean orderInBean) throws BizException {
        OrderOutBean outBean = new OrderOutBean();
        try {
            OrderInsertRequestWrapper request = XtpReqUtils.buildOrderInsertRequest(orderInBean);
            outBean.setChannelOrderId(orderService.commitOrder(request));
        } catch (ServiceException e) {
            throw new BizException(OesXtpRspCode.ERR_COMMIT_ORDER, e.getMsg());
        }
        return outBean;
    }

    @Override
    public OrderOutBean cancelOrder(OrderInBean orderInBean) throws BizException {
        OrderOutBean outBean = new OrderOutBean();
        try {
            OrderCancelRequestWrapper request = XtpReqUtils.buildOrderCancelRequest(orderInBean);
            orderService.cancelOrder(request);
        } catch (ServiceException e) {
            throw new BizException(OesXtpRspCode.ERR_CANCEL_ORDER, e.getMsg());
        }
        return outBean;
    }

    @Override
    public TodayOrderBean queryTodayOrder(TodayOrderBean inBean) throws BizException {
        TodayOrderBean outBean = new TodayOrderBean();
        try {
            OrderQryRequestWrapper request = XtpReqUtils.buildOrderQryRequestWrapper(inBean);
            List<OrderResponseWrapper> responseMsgs = orderService.qryTodayOrder(request);
            outBean = BizRspUtils.buildTodayOrderBean(responseMsgs);
        } catch (ServiceException e) {
            throw new BizException(OesXtpRspCode.ERR_COMMIT_ORDER, e.getMsg());
        }
        return outBean;
    }

    @Override
    public List<TodayTransBean> queryTodayTrans(TodayOrderBean inBean) throws BizException {
        List<TodayTransBean> outBean = new ArrayList<>();
        try {
            TradeQryRequestWrapper request = XtpReqUtils.buildTransQryRequestWrapper(inBean);
            List<TradeResponseWrapper> responseMsgs = orderService.qryTodayTrans(request);
            outBean = BizRspUtils.buildTodayTradeBean(responseMsgs);
        } catch (ServiceException e) {
            throw new BizException(OesXtpRspCode.ERR_COMMIT_ORDER, e.getMsg());
        }
        return outBean;
    }
}
