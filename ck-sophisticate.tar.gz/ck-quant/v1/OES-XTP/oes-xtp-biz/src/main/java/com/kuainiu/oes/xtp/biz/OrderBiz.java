package com.kuainiu.oes.xtp.biz;

import com.kuainiu.oes.xtp.biz.bean.OrderInBean;
import com.kuainiu.oes.xtp.biz.bean.OrderOutBean;
import com.kuainiu.oes.xtp.exception.BizException;
import com.kuainiu.oes.xtp.facade.bean.TodayOrderBean;
import com.kuainiu.oes.xtp.facade.bean.TodayTransBean;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 2:38 PM
 */
public interface OrderBiz {
    OrderOutBean commitOrder(OrderInBean orderInBean) throws BizException;

    OrderOutBean cancelOrder(OrderInBean orderInBean) throws BizException;

    TodayOrderBean queryTodayOrder(TodayOrderBean inBean) throws BizException;

    List<TodayTransBean> queryTodayTrans(TodayOrderBean inBean) throws BizException;
}
