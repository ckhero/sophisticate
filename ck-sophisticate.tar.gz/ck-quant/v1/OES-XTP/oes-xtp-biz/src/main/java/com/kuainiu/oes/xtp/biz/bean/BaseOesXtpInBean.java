package com.kuainiu.oes.xtp.biz.bean;

import lombok.Data;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/6
 * Time: 3:57 PM
 */
@Data
public class BaseOesXtpInBean extends BaseInBean {
    /**
     * 交易板块
     */
    private String transBoard;

    /**
     * 股票代码
     */
    private String assetNo;

    /**
     * 交易数量 单位/股
     */
    private Integer orderQty;

    /**
     * 交易方向
     */
    private String transSide;

    /**
     * 交易类型
     */
    private Integer transType;

    /**
     * 限价
     */
    private BigDecimal limitPrice;

    /**
     * 渠道id
     */
    private String channelOrderId;
}
