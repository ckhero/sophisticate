package com.kuainiu.oes.xtp.biz.bean;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/6
 * Time: 3:57 PM
 */
@Data
public class BaseOutBean {
}
