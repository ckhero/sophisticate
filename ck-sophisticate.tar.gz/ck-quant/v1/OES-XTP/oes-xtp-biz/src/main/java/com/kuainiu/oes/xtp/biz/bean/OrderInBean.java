package com.kuainiu.oes.xtp.biz.bean;

import lombok.Data;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 2:34 PM
 */
@Data
public class OrderInBean extends BaseOesXtpInBean {
    private String qtOrderId;

    /**
     * 交易板块
     */
    private String transBoard;

    /**
     * 股票代码
     */
    private String assetNo;

    /**
     * 交易数量 单位/股
     */
    private Integer orderQty;

    /**
     * 交易方向
     */
    private String transSide;

    /**
     * 交易类型
     */
    private Integer transType;

    private BigDecimal limitPrice;
}
