package com.kuainiu.oes.xtp.biz.bean;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 2:34 PM
 */
@Data
public class OrderOutBean extends BaseOesXtpOutBean {

    String channelOrderId;
}
