package com.kuainiu.oes.xtp.util;

import com.kuainiu.oes.xtp.exception.ServiceException;
import com.kuainiu.oes.xtp.exception.ServiceRuntimeException;
import com.kuainiu.oes.xtp.biz.bean.BaseOesXtpOutBean;
import com.kuainiu.oes.xtp.exception.BizException;
import com.kuainiu.oes.xtp.facade.code.OesXtpRspCode;
import com.kuainiu.oes.xtp.facade.response.BaseOesXtpRsp;
import com.kuainiu.oes.xtp.common.util.BeanMapUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.remoting.TimeoutException;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/19
 * Time: 4:13 PM
 */
@Slf4j
public class ResponseUtils {

    private ResponseUtils(){
    }

    public static final String SUCCESS_CDOE = OesXtpRspCode.SUCCESS.getCode();

    public static void sysError(BaseOesXtpRsp resp, Throwable e){
        if (e instanceof IllegalArgumentException) {
            resp.setCode(OesXtpRspCode.ERR_PARAM_ERROR.getCode());
            resp.setMsg(e.getMessage());
        } else if (e instanceof TimeoutException) {
            resp.setCode(OesXtpRspCode.SYS_TIMEOUT.getCode());
            resp.setMsg(OesXtpRspCode.SYS_TIMEOUT.getMsg());
        } else if (e instanceof ServiceException) {
            ServiceException se = (ServiceException) e;
            if (se.getCode() != null) {
                se.exceptionToResponse(resp);
            } else {
                resp.setErrorCodeAndException(OesXtpRspCode.ERR_BUSI_ERROR, e);
            }
        } else if (e instanceof ServiceRuntimeException) {
            ServiceRuntimeException se = (ServiceRuntimeException) e;
            if (se.getCode() != null) {
                se.exceptionToResponse(resp);
            } else {
                resp.setErrorCodeAndException(OesXtpRspCode.ERR_SYS_ERROR, e);
            }
        } else if (e instanceof BizException) {
            BizException be = (BizException) e;
            if (be.getCode() != null) {
                be.exceptionToResponse(resp);
            } else {
                resp.setErrorCodeAndException(OesXtpRspCode.ERR_BUSI_ERROR, e);
            }
        } else {
            resp.setCode(OesXtpRspCode.SYS_ERROR.getCode());
            resp.setMsg(OesXtpRspCode.SYS_ERROR.getMsg());
        }
        log.error("facade调用返回异常！code：{},msg:{}", resp.getCode(), resp.getMsg());
        log.error("facade调用返回异常！e", e);
    }

    public static void success(BaseOesXtpRsp resp){
        resp.setCode(SUCCESS_CDOE);
        resp.setMsg(OesXtpRspCode.SUCCESS.getMsg());
    }

    public static void success(BaseOesXtpRsp rsp, BaseOesXtpOutBean outBean){
        BeanMapUtils.map(outBean, rsp);
        rsp.setCode(SUCCESS_CDOE);
        rsp.setMsg(OesXtpRspCode.SUCCESS.getMsg());
    }
//
//    public static void sysError(StkOrderOutBean stkTransOutBean, Throwable e){
//        if (e instanceof IllegalArgumentException) {
//            stkTransOutBean.setCode(OesXtpRspCode.ERR_PARAM_ERROR.getCode());
//            stkTransOutBean.setMsg(e.getMsg());
//        } else if (e instanceof TimeoutException) {
//            stkTransOutBean.setCode(OesXtpRspCode.SYS_TIMEOUT.getCode());
//            stkTransOutBean.setMsg(OesXtpRspCode.SYS_TIMEOUT.getMsg());
//        } else if (e instanceof ServiceException) {
//            ServiceException se = (ServiceException) e;
//            if (se.getCode() != null) {
//                stkTransOutBean.setCode(se.getCode());
//                stkTransOutBean.setMsg(se.getMsg());
//            } else {
//                stkTransOutBean.setCode(OesXtpRspCode.ERR_BUSI_ERROR.getCode());
//                stkTransOutBean.setMsg(OesXtpRspCode.ERR_BUSI_ERROR.getMsg());
//            }
//            stkTransOutBean.setException(se);
//        } else if (e instanceof ServiceRuntimeException) {
//            ServiceRuntimeException se = (ServiceRuntimeException) e;
//            if (se.getCode() != null) {
//                stkTransOutBean.setCode(se.getCode());
//                stkTransOutBean.setMsg(se.getMsg());
//            } else {
//                stkTransOutBean.setCode(OesXtpRspCode.ERR_SYS_ERROR.getCode());
//                stkTransOutBean.setMsg(OesXtpRspCode.ERR_SYS_ERROR.getCode());
//            }
//            stkTransOutBean.setException(se);
//        } else if (e instanceof BizException) {
//            BizException be = (BizException) e;
//            if (be.getCode() != null) {
//                stkTransOutBean.setCode(be.getCode());
//                stkTransOutBean.setMsg(be.getMsg());
//            } else {
//                stkTransOutBean.setCode(OesXtpRspCode.ERR_BUSI_ERROR.getCode());
//                stkTransOutBean.setCode(OesXtpRspCode.ERR_BUSI_ERROR.getCode());
//            }
//            stkTransOutBean.setException(be);
//        } else {
//            stkTransOutBean.setCode(OesXtpRspCode.SYS_ERROR.getCode());
//            stkTransOutBean.setMsg(OesXtpRspCode.SYS_ERROR.getCode());
//            stkTransOutBean.setException(e);
//        }
//
//        LoggerUtils.error(logger, e, "业务错误 orderOutBean:{}", stkTransOutBean);
//    }
}
