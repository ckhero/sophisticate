package com.kuainiu.oes.xtp.param;

import com.kuainiu.oes.xtp.common.enums.XtpAssetTypeCode;
import com.kuainiu.oes.xtp.common.enums.XtpPriceTypeCode;
import com.kuainiu.oes.xtp.exception.BizException;
import com.kuainiu.oes.xtp.facade.code.OesXtpRspCode;
import com.kuainiu.oes.xtp.facade.request.OrderCancelReq;
import com.kuainiu.oes.xtp.facade.request.OrderCommitReq;
import com.kuainiu.oes.xtp.common.util.CommonConstant;
import com.kuainiu.oes.xtp.facade.request.TodayOrderQryReq;
import org.apache.commons.lang3.StringUtils;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 2:47 PM
 */
public class OrderParamCheckHandle {
    public static void checkOrderCommitReq(OrderCommitReq request) throws BizException {
        if (null == request) {
            throw new BizException(OesXtpRspCode.ERR_PARAM_ERROR);
        }

//        if (StringUtils.isBlank(request.getQtOrderId())) {
//            throw new BizException(OesXtpRspCode.ERR_PARAM_QT_ORDER_ID);
//        }

        if (StringUtils.isBlank(request.getAssetNo())) {
            throw new BizException(OesXtpRspCode.ERR_PARAM_ASSET_NO);
        }

        if (StringUtils.isBlank(request.getTransBoard())) {
            throw new BizException(OesXtpRspCode.ERR_PARAM_TRANS_BOARD);
        }

        if (StringUtils.isBlank(request.getTransSide())) {
            throw new BizException(OesXtpRspCode.ERR_PARAM_TRANS_SIDE);
        }

        if (request.getOrderQty() <= CommonConstant.ZERO) {
            throw new BizException(OesXtpRspCode.ERR_PARAM_ORDER_AMOUNT);
        }

        if (null == request.getTransType()) {
            throw new BizException(OesXtpRspCode.ERR_PARAM_TRANS_TYPE);
        }

        if (null == request.getAssetType()) {
            throw new BizException(OesXtpRspCode.ERR_PARAM_ASSET_TYPE);
        } else if (XtpAssetTypeCode.XTP_ASSET_TYPE_CV.getAssetType().equals(request.getAssetType())) {
            //可转债只支持限价操作
            if (XtpPriceTypeCode.MARKET_BUY.getCode().equals(request.getTransType()) ||
                    XtpPriceTypeCode.MARKET_SELL.getCode().equals(request.getTransType())){
                throw new BizException(OesXtpRspCode.ERR_PARAM_CV_NOT_SUPPORT_MARKET);
            }
        }

    }

    public static void checkOrderCancelReq(OrderCancelReq request) throws BizException {
        if (null == request) {
            throw new BizException(OesXtpRspCode.ERR_PARAM_ERROR);
        }

        if (StringUtils.isBlank(request.getChannelOrderId())) {
            throw new BizException(OesXtpRspCode.ERR_PARAM_CHANNEL_ORDER_ID);
        }
    }

    public static void checkTodayOrder(TodayOrderQryReq request) throws BizException {
        {
            if (null == request) {
                throw new BizException(OesXtpRspCode.ERR_PARAM_ERROR);
            }

//        if (StringUtils.isBlank(request.getChannelOrderId())) {
//            throw new BizException(OesXtpRspCode.ERR_PARAM_CHANNEL_ORDER_ID);
        }
    }
}
