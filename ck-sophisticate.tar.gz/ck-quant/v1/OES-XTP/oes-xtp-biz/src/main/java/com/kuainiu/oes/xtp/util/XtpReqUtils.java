package com.kuainiu.oes.xtp.util;

import com.kuainiu.oes.xtp.biz.bean.OrderInBean;
import com.kuainiu.oes.xtp.exception.BizException;
import com.kuainiu.oes.xtp.facade.bean.TodayOrderBean;
import com.kuainiu.oes.xtp.facade.code.OesXtpRspCode;
import com.kuainiu.oes.xtp.common.enums.*;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.OrderCancelRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.OrderInsertRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.OrderQryRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.TradeQryRequestWrapper;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 5:28 PM
 */
public class XtpReqUtils {

    public static OrderInsertRequestWrapper buildOrderInsertRequest(OrderInBean inBean) throws BizException {
        OrderInsertRequestWrapper request = new OrderInsertRequestWrapper();

        // TODO
        //将qt order id 转化成client id 从第三位之后，即第四位开始
        String qtOrderId = inBean.getQtOrderId();
        String clientId = qtOrderId.substring(3);

        request.setOrderClientId(Integer.parseInt(clientId));
        request.setPrice(inBean.getLimitPrice());
        request.setQuantity(inBean.getOrderQty().longValue());
        request.setTicker(inBean.getAssetNo());

        XtpMarketTypeCode xtpMarketTypeCode = XtpMarketTypeCode.getCodeByTransBoard(inBean.getTransBoard());
        if (null == xtpMarketTypeCode) {
            throw new BizException(OesXtpRspCode.ERR_TRANS_BORAD);
        }
        MarketType marketType = MarketType.forType(xtpMarketTypeCode.getType());
        request.setMarketType(marketType);

        XtpSideTypeCode xtpSideTypeCode = XtpSideTypeCode.getCodeByTransSide(inBean.getTransSide());
        if (null == xtpSideTypeCode) {
            throw new BizException(OesXtpRspCode.ERR_TRANS_SIDE);
        }
        SideType sideType = SideType.forType(xtpSideTypeCode.getType());
        request.setSideType(sideType);

        XtpPriceTypeCode xtpPriceTypeCode = XtpPriceTypeCode.getTransTypeByCode(inBean.getTransType());
        if (null == xtpPriceTypeCode) {
            throw new BizException(OesXtpRspCode.ERR_TRANS_TYPE);
        }
        PriceType priceType = PriceType.forType(xtpPriceTypeCode.getType());
        request.setPriceType(priceType);

        request.setBusinessType(BusinessType.XTP_BUSINESS_TYPE_CASH);

        return request;
    }

    public static OrderCancelRequestWrapper buildOrderCancelRequest(OrderInBean orderInBean) {
        OrderCancelRequestWrapper requestWrapper = new OrderCancelRequestWrapper();
        requestWrapper.setOrderXtpId(orderInBean.getChannelOrderId());
        return requestWrapper;
    }

    public static OrderQryRequestWrapper buildOrderQryRequestWrapper(TodayOrderBean inBean) {
        OrderQryRequestWrapper wrapper=new OrderQryRequestWrapper();
        wrapper.setOrderXtpId(inBean.getChannelOrderId());
        return wrapper;
    }

    public static TradeQryRequestWrapper buildTransQryRequestWrapper(TodayOrderBean inBean) {
        TradeQryRequestWrapper wrapper=new TradeQryRequestWrapper();
        wrapper.setOrderXtpId(inBean.getChannelOrderId());
        return wrapper;
    }
}
