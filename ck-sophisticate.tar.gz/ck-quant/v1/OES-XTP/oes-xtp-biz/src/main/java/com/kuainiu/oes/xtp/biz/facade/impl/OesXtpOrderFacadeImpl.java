package com.kuainiu.oes.xtp.biz.facade.impl;

import com.alibaba.fastjson.JSON;
import com.kuainiu.oes.xtp.biz.OrderBiz;
import com.kuainiu.oes.xtp.biz.bean.OrderInBean;
import com.kuainiu.oes.xtp.biz.bean.OrderOutBean;
import com.kuainiu.oes.xtp.facade.bean.TodayOrderBean;
import com.kuainiu.oes.xtp.facade.bean.TodayTransBean;
import com.kuainiu.oes.xtp.facade.request.TodayOrderQryReq;
import com.kuainiu.oes.xtp.facade.response.TodayOrderQryRsp;
import com.kuainiu.oes.xtp.util.BizInBeanUtils;
import com.kuainiu.oes.xtp.util.BizRspUtils;
import com.kuainiu.oes.xtp.util.ResponseUtils;
import com.kuainiu.oes.xtp.facade.request.OrderCancelReq;
import com.kuainiu.oes.xtp.facade.request.OrderCommitReq;
import com.kuainiu.oes.xtp.facade.response.OrderCancelRsp;
import com.kuainiu.oes.xtp.facade.response.OrderCommitRsp;
import com.kuainiu.oes.xtp.facade.xtp.OesXtpOrderFacade;
import com.kuainiu.oes.xtp.param.OrderParamCheckHandle;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 2:41 PM
 */
@Service
@Slf4j
public class OesXtpOrderFacadeImpl implements OesXtpOrderFacade {
    @Autowired
    OrderBiz orderBiz;

    @Override
    public OrderCommitRsp commitOrder(OrderCommitReq request) {
        log.info("[Biz]commit order,reqeust={}", JSON.toJSONString(request));
        OrderCommitRsp response = new OrderCommitRsp();
        try {
            OrderParamCheckHandle.checkOrderCommitReq(request);
            OrderInBean inBean = BizInBeanUtils.buildOrderInBean(request);
            OrderOutBean outBean = orderBiz.commitOrder(inBean);
            ResponseUtils.success(response, outBean);
            response.setQtOrderId(request.getQtOrderId());
            log.info("[Biz]commit order,response={}", JSON.toJSONString(response));
        } catch (Exception e) {
            log.error("[Biz]commit order fail");
            ResponseUtils.sysError(response, e);
        }
        return response;
    }

    @Override
    public OrderCancelRsp cancelOrder(OrderCancelReq request) {

        log.info("[Biz]cancel order,reqeust={}", JSON.toJSONString(request));
        OrderCancelRsp response = new OrderCancelRsp();
        try {
            OrderParamCheckHandle.checkOrderCancelReq(request);
            OrderInBean inBean = BizInBeanUtils.buildOrderInBean(request);
            OrderOutBean outBean = orderBiz.cancelOrder(inBean);
            ResponseUtils.success(response, outBean);
            response.setQtOrderId(request.getQtOrderId());
            log.info("[Biz]cancel order,response={}", JSON.toJSONString(response));
        } catch (Exception e) {
            log.error("[Biz]cancel order fail");
            ResponseUtils.sysError(response, e);
        }
        return response;
    }

    @Override
    public TodayOrderQryRsp qryTodayOrderAndTrans(TodayOrderQryReq request) {
        log.info("[qry today order request] {}", JSON.toJSONString(request));
        TodayOrderQryRsp response = new TodayOrderQryRsp();
        try {
            OrderParamCheckHandle.checkTodayOrder(request);
            TodayOrderBean inBean = BizInBeanUtils.buildTodayOrderBean(request);
            TodayOrderBean orderOutBean = orderBiz.queryTodayOrder(inBean);
            List<TodayTransBean> transOutBeans=new ArrayList<>();
            if(StringUtils.isNotEmpty(orderOutBean.getChannelOrderId())){
                transOutBeans = orderBiz.queryTodayTrans(inBean);
            }
            response = BizRspUtils.buildPATodayOrderQryResponse(orderOutBean,transOutBeans);
            ResponseUtils.success(response);
        } catch (Exception e) {
            ResponseUtils.sysError(response, e);
        }
        log.info("[qry today order response] {}", JSON.toJSONString(response));
        return response;
    }
}
