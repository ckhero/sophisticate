package com.kuainiu.oes.xtp.service.file.entity;

import com.kuainiu.oes.xtp.service.producer.bean.OrderProBean;
import com.kuainiu.oes.xtp.service.file.utils.KnGsonBuilder;

/**
 * @author danol
 * @Classname XtpOrderResponse
 * @Description TODO
 * @Date 10/16/2019 17:52
 */
public class XtpOrderNotify extends OrderProBean {
    public static XtpOrderNotify fromJson(String json) {
        return KnGsonBuilder.create().fromJson(json, XtpOrderNotify.class);
    }

    @Override
    public String toString() {
        return KnGsonBuilder.create().toJson(this);
    }
}
