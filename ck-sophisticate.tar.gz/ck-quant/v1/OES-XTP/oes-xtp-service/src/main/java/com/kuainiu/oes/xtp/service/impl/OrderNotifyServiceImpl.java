package com.kuainiu.oes.xtp.service.impl;

import com.alibaba.fastjson.JSON;
import com.kuainiu.oes.xtp.service.OrderNotifyService;
import com.kuainiu.oes.xtp.service.bean.CalcStatusBean;
import com.kuainiu.oes.xtp.service.file.utils.cache.CacheProviderService;
import com.kuainiu.oes.xtp.service.producer.OrderProducer;
import com.kuainiu.oes.xtp.service.producer.bean.OrderProBean;
import com.kuainiu.oes.xtp.service.file.entity.XtpOrderNotify;
import com.kuainiu.oes.xtp.service.xtpclient.response.OrderResponse;
import com.kuainiu.oes.xtp.common.enums.OrderStatusType;
import com.kuainiu.oes.xtp.common.enums.OrderSubmitStatusType;
import com.kuainiu.oes.xtp.common.util.QtDateUtils;
import com.kuainiu.qt.trans.facade.code.stk.StkOrderStatusCode;
import com.kuainiu.qt.trans.facade.code.stk.StkOrderSubmitStatusCode;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.Date;


/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 5:11 PM
 */
@Service
@Slf4j
public class OrderNotifyServiceImpl implements OrderNotifyService {
    @Autowired
    OrderProducer orderProducer;

    @Autowired
    @Qualifier("localCacheService")
    CacheProviderService cacheProviderService;

    @Override
    public void notifyOrder(OrderResponse response) {
        log.info("[Service]order notify,response={}", JSON.toJSONString(response));
        OrderProBean order = new OrderProBean();
        //String qtOrderId = String.valueOf(System.currentTimeMillis()).substring(1,3).concat(String.valueOf(response.getOrderClientId()));
        String channelOrderId = response.getOrderXtpId();
        if (response.getCancelTime() != 0) {
            Date cancelTime = QtDateUtils.convertToDate(response.getCancelTime());
            order.setOrderCancelTime(cancelTime);
        }

        if (response.getInsertTime() != 0) {
            Date confirmTime = QtDateUtils.convertToDate(response.getInsertTime());
            order.setOrderConfirmTime(confirmTime);

        }
        CalcStatusBean calcStatusBean = calcStatus(response);

        order.setChannelOrderId(channelOrderId);
        // order.setQtOrderId(qtOrderId);
        // 设置qt order id,  带回交易系统
        long startTime = System.currentTimeMillis();
        //做等待超过5秒继续
        while(cacheProviderService.get(channelOrderId)==null || "".equals(cacheProviderService.get(channelOrderId))){
            if ((System.currentTimeMillis() - startTime) > 1000 * 5) {
                break;
            }
        }
        if(cacheProviderService.get(channelOrderId)!=null && !"".equals(cacheProviderService.get(channelOrderId))){
            order.setQtOrderId(cacheProviderService.get(channelOrderId));
        }

        order.setStatus(calcStatusBean.getStatus());
        order.setSubmitStatus(calcStatusBean.getSubmitStatus());

        log.info("[Service]order notify,order={}", JSON.toJSONString(order));

        XtpOrderNotify orderNotify = new XtpOrderNotify();

        orderProducer.send(order);
    }

    public static CalcStatusBean calcStatus(OrderResponse response) {

        CalcStatusBean calcStatusBean = new CalcStatusBean();

        String qtTransOrderStatus = null;
        String qtTransOrderSubmitStatus = null;

        OrderStatusType xtpOrderStatus = response.getOrderStatusType();
        OrderSubmitStatusType xtpOrderSubmitStatus = response.getOrderSubmitStatusType();
        switch (xtpOrderSubmitStatus) {
            case XTP_ORDER_SUBMIT_STATUS_INSERT_ACCEPTED:
                qtTransOrderSubmitStatus = StkOrderSubmitStatusCode.CONFIRM.getCode();
                qtTransOrderStatus = StkOrderStatusCode.WAIT_TRANS.getCode();
                break;

            case XTP_ORDER_SUBMIT_STATUS_INSERT_REJECTED:
                qtTransOrderSubmitStatus = StkOrderSubmitStatusCode.VOID.getCode();
                qtTransOrderStatus = StkOrderStatusCode.VOID.getCode();
                break;

            default:
                break;
        }

        if (!xtpOrderSubmitStatus.equals(OrderSubmitStatusType.XTP_ORDER_SUBMIT_STATUS_INSERT_REJECTED)) {
            switch (xtpOrderStatus) {
                case XTP_ORDER_STATUS_ALLTRADED:
                    qtTransOrderSubmitStatus = StkOrderSubmitStatusCode.FINISH.getCode();
                    qtTransOrderStatus = StkOrderStatusCode.FINISH.getCode();
                    break;

                case XTP_ORDER_STATUS_PARTTRADEDQUEUEING:
                case XTP_ORDER_STATUS_PARTTRADEDNOTQUEUEING:
                    qtTransOrderSubmitStatus = StkOrderSubmitStatusCode.FINISH.getCode();
                    qtTransOrderStatus = StkOrderStatusCode.PART_CANCEL.getCode();
                    break;

                case XTP_ORDER_STATUS_CANCELED:
                    qtTransOrderSubmitStatus = StkOrderSubmitStatusCode.FINISH.getCode();
                    qtTransOrderStatus = StkOrderStatusCode.CANCEL.getCode();
                    break;

                case XTP_ORDER_STATUS_REJECTED:
                    qtTransOrderSubmitStatus = StkOrderSubmitStatusCode.VOID.getCode();
                    qtTransOrderStatus = StkOrderStatusCode.VOID.getCode();
                    break;

                default:
                    log.info("[Service]order notify, unknow xtp order status");
                    break;
            }
        }

        calcStatusBean.setStatus(qtTransOrderStatus);
        calcStatusBean.setSubmitStatus(qtTransOrderSubmitStatus);
        return calcStatusBean;
    }


}
