package com.kuainiu.oes.xtp.service.xtpclient.request;


import com.kuainiu.oes.xtp.common.enums.*;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of = {"orderXtpId"})
@Builder
public class OrderInsertRequest {

    /**XTP系统订单ID，无需用户填写，在XTP系统中唯一 */
    private String orderXtpId;
    /**报单引用，由客户自定义*/
    private int orderClientId;
    /**合约代码 客户端请求不带空格*/
    private String ticker;
    /**交易市场*/
    private MarketType marketType;
    /**价格*/
    private double price=0d;
    /**止损价*/
    private double stopPrice=0d;
    /**数量(股票单位为股，逆回购单位为张)*/
    private long quantity=0L;
    /**报单价格*/
    private PriceType priceType;
    /**买卖方向*/
    private SideType sideType;
    /**开平标志*/
    private PositionEffectType positionEffectType;
    /**业务类型*/
    private BusinessType businessType;

    public int getMarketType() {
        return marketType.ordinal();
    }

    public int getPriceType() {
        return priceType.getType();
    }

    public int getSideType() {
        return sideType.getType();
    }

    public int getPositionEffectType() {
        if(positionEffectType==null) return 0;//默认为初始化类型  现货适用
        else return positionEffectType.ordinal();
    }


    public int getBusinessType() {
        return businessType.ordinal();
    }

}
