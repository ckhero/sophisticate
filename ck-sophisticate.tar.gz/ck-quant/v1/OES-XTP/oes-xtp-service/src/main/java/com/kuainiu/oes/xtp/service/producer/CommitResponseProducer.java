package com.kuainiu.oes.xtp.service.producer;

import com.kuainiu.oes.xtp.service.config.KafkaConfig;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/17
 * Time: 5:50 PM
 */
public class CommitResponseProducer extends AbstractProducer {
    @Override
    protected void setTopicName() {
        this.topicName = KafkaConfig.TOPIC_QT_TRANS_STK_ORDER_COMMIT_RESPONSE;
    }
}
