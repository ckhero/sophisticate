package com.kuainiu.oes.xtp.service.xtpclient.handle;

import com.kuainiu.oes.xtp.exception.ServiceException;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.BaseRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.BaseResponseWrapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.locks.LockSupport;

@Slf4j
public class DataContextHandle {

    public static final ConcurrentMap<Integer, DataContext> applicationContext = new ConcurrentHashMap<>();

    /**
     * 添加上下文到map
     * @param requestId
     * @param request
     * @throws Exception
     */
    public static void putIfAbsent(Integer requestId, BaseRequestWrapper request) throws ServiceException {
        //存在requestId,抛异常
        if (applicationContext.containsKey(requestId)) {
//            throw new ServiceException("Request ID :"+requestId+"is executing");
        }
        DataContext context = new DataContext(requestId, request);
        context.start();
        applicationContext.putIfAbsent(requestId, context);
    }

    /**
     * 根据请求id获取上下文对象
     * @param requestId
     * @return
     * @throws Exception
     */
    public static DataContext get(Integer requestId) {
        return applicationContext.get(requestId);
    }

    /**
     * 回调数据写入上下文
     * @param requestId 请求id
     * @param response 处理过的回调数据
     * @throws Exception
     */
    public static void callBack(Integer requestId, BaseResponseWrapper response){
        if (applicationContext.containsKey(requestId)) {
            DataContext context = applicationContext.get(requestId);
            context.done(response);
        } else {
         log.warn("Callback request ID :{} does not exist or has expired",requestId);
        }
    }

    /**
     * 清楚当前${requestId}对应的上下文对象
     * @param requestId
     */
    public static void clear(Integer requestId) {
        applicationContext.remove(requestId);
        if(log.isDebugEnabled()){
            log.debug("Clear the request ID :{} successfully",requestId);
        }
    }

    /**
     *
     * @param thread 需要锁住的线程
     * @param timeOut 回调超时时间（秒）
     */
    public static void park(Integer requestId,Thread thread,Long timeOut) {
        if(timeOut==null || timeOut ==0l ){
            timeOut=5l;
        }
        if(timeOut >500l){
            timeOut=500l;
        }
        timeOut = timeOut *1000*1000*1000;//需转换为纳秒
        if(applicationContext.containsKey(requestId) && CollectionUtils.isEmpty(applicationContext.get(requestId).getResponseMsg())){
            applicationContext.get(requestId).setThread(thread);
            LockSupport.parkNanos(thread, timeOut);
        }
    }

    public static void unpark(Integer requestId)  {
        if (applicationContext.containsKey(requestId) && applicationContext.get(requestId).getThread() != null) {
            DataContext context = get(requestId);
            LockSupport.unpark(context.getThread());
            if(log.isDebugEnabled()){
                log.debug("A thread that wakes up request id :{}",requestId);
            }
        }
    }
}
