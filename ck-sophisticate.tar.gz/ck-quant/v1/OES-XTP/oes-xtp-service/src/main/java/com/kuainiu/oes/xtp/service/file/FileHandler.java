package com.kuainiu.oes.xtp.service.file;

import com.kuainiu.oes.xtp.service.file.utils.cache.XtpRequestCache;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @author danol
 * @Classname SftpHandler
 * @Description TODO
 * @Date 9/25/2019 15:55
 */
@Component
@EnableScheduling
@Slf4j
public class FileHandler {

    @Autowired
    KnFileService knFileService;

    @Autowired
    XtpRequestCache xtpRequestCache;

    //@Scheduled(fixedRate = 50)
    public void preHandleRequestFiles() {
        List<String> localRequestFileList = knFileService.getLocalRequestFileList();
        if (localRequestFileList != null) {
            localRequestFileList.forEach(f -> {
                knFileService.preLoadRequestFile(f);
            });
        }
    }
    //@Scheduled(fixedRate = 50)
    public void preHandleQueryFiles() {
        List<String> localRequestFileList = knFileService.getLocalQueryFileList();
        if (localRequestFileList != null) {
            localRequestFileList.forEach(f -> {
                knFileService.preLoadRequestFile(f);
            });
        }
    }
    @Scheduled(fixedRate = 50)
    public void preHandleAllRequestFiles() {
        List<String> localRequestFileList = knFileService.getLocalAllFileList();
        if (localRequestFileList != null) {
            localRequestFileList.forEach(f -> {
                knFileService.preLoadRequestFile(f);
            });
        }
    }

    @Scheduled(fixedRate = 50)
    public void handleRequestFiles() {
        Iterator<Map.Entry<String, Object>> entries = xtpRequestCache.getData().entrySet().iterator();
        while (entries.hasNext()) {
            Map.Entry<String, Object> entry = entries.next();
            knFileService.handleRequestFile(entry.getKey(),entry.getValue());
            // 处理完移除cache中的数据
            xtpRequestCache.getData().remove(entry.getKey());
        }
    }

}
