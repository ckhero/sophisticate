package com.kuainiu.oes.xtp.service.xtpclient.pre;

import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.BaseRequestWrapper;
import org.springframework.core.Ordered;


public interface PreEncode extends Ordered {

    Integer COMMON_FUNCTION = 0;

    /**
     * 适配的消息类型，参考function id
     *
     * @return
     */
    Integer function();

    /**
     * 具体的处理流程
     *
     * @param msg
     */
    void process(BaseRequestWrapper msg);

}
