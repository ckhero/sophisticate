package com.kuainiu.oes.xtp.service.xtpclient.pre;

import com.kuainiu.oes.xtp.common.consts.XtpConsts;
import com.kuainiu.oes.xtp.common.enums.BusinessType;
import com.kuainiu.oes.xtp.common.enums.PositionEffectType;
import com.kuainiu.oes.xtp.common.enums.PriceType;
import com.kuainiu.oes.xtp.service.xtpclient.XtpWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.BaseRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.OrderInsertRequestWrapper;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class OrderInsertPreEncode extends AbstractPreEncode {

    public OrderInsertPreEncode(XtpWrapper wrapper) {
        super(wrapper);
    }

    @Override
    public Integer function() {
        return XtpConsts.TransFunction.ORDER_INSERT;
    }

    @Override
    public void process(BaseRequestWrapper msg) {
        OrderInsertRequestWrapper request=(OrderInsertRequestWrapper)msg;
//        request.setPriceType(PriceType.XTP_PRICE_BEST5_OR_CANCEL);
        request.setBusinessType(BusinessType.XTP_BUSINESS_TYPE_CASH);
        request.setPositionEffectType(PositionEffectType.XTP_POSITION_EFFECT_INIT);
//        request.setOrderClientId(request.getRequestId());
        request.setOrderXtpId("");
    }

    @Override
    public int getOrder() {
        return 1;
    }

}
