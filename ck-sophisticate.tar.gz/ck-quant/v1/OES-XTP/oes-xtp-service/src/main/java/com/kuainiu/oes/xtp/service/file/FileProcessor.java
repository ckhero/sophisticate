package com.kuainiu.oes.xtp.service.file;

import com.kuainiu.oes.xtp.service.file.entity.XtpOrderReqQuery;
import com.kuainiu.oes.xtp.service.file.entity.XtpOrderReqCancel;
import com.kuainiu.oes.xtp.service.file.entity.XtpOrderReqCommit;

import java.io.IOException;

/**
 * @author danol
 * @Classname SftpFileHandler
 * @Description TODO
 * @Date 9/29/2019 11:06
 */
public interface FileProcessor {
    /**
     * covert file content to object T
     *
     * @param filename
     * @return
     */
    XtpOrderReqCommit readeReqCommitFromFile(String filename) throws IOException;

    /**
     *
     * @param filename
     * @return
     * @throws IOException
     */
    XtpOrderReqCancel readeReqCancelFromFile(String filename) throws IOException;

    /**
     *
     * @param filename
     * @return
     * @throws IOException
     */
    XtpOrderReqQuery readeOrderQryReqFromFile(String filename) throws IOException;

}
