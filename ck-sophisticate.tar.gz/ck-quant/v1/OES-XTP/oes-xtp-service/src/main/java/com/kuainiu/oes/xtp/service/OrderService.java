package com.kuainiu.oes.xtp.service;

import com.kuainiu.oes.xtp.exception.ServiceException;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.OrderCancelRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.OrderInsertRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.OrderQryRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.TradeQryRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.BaseResponseWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.OrderResponseWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.TradeResponseWrapper;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 7:14 PM
 */
public interface OrderService {

    /**
     * 下单服务
     * @param request
     * @return 返回渠道订单号
     */
    String commitOrder(OrderInsertRequestWrapper request) throws ServiceException;

    /**
     * 撤单服务
     */
    void cancelOrder(OrderCancelRequestWrapper request) throws ServiceException;

    List<OrderResponseWrapper> qryTodayOrder(OrderQryRequestWrapper request) throws ServiceException;

    List<TradeResponseWrapper> qryTodayTrans(TradeQryRequestWrapper request) throws ServiceException;
}
