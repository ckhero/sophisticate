package com.kuainiu.oes.xtp.service.xtpclient.pre;

import com.kuainiu.oes.xtp.service.xtpclient.XtpWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.BaseRequestWrapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * 消息id生成器
 */
@Order(value = Ordered.HIGHEST_PRECEDENCE)
@Slf4j
public class MsgIdGenerator extends AbstractPreEncode {

    public MsgIdGenerator(XtpWrapper wrapper) {
        super(wrapper);
    }

    private static AtomicInteger counter = new AtomicInteger(0);

    @Override
    public Integer function() {
        return COMMON_FUNCTION;
    }

    @Override
    public void process(BaseRequestWrapper msg) {
        if (null==msg.getRequestId()||
                msg.getRequestId()==0) {
            int msgId=XtpWrapper.baseMsgId+getAtomicCounter().incrementAndGet();
            msg.setRequestId(msgId);
            msg.setSessionId(wrapper.getSessionId());
        }
    }

    @Override
    public int getOrder() {
        return 0;
    }

    private static AtomicInteger getAtomicCounter() {
        if (counter.get() > 999999) {
            counter.set(1);
        }
        return counter;
    }

}
