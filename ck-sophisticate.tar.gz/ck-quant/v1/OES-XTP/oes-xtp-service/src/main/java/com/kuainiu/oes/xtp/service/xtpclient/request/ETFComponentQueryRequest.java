package com.kuainiu.oes.xtp.service.xtpclient.request;

import com.kuainiu.oes.xtp.common.enums.MarketType;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of = {"marketType", "ticker"})
@Builder
public class ETFComponentQueryRequest {

    /**交易市场*/
    private MarketType marketType;
    /**ETF买卖代码*/
    private String ticker;

    public int getMarketType() {
        return marketType.ordinal();
    }

}