package com.kuainiu.oes.xtp.service.file.utils;

import java.util.regex.Pattern;

/**
 * @author danol
 * @Classname StringMatcher
 * @Description TODO
 * @Date 10/8/2019 20:02
 */
public class StringMatcher {
    public static boolean matches(String pattern, String name) {
        String tmpP = pattern.replaceAll("\\*", "\\.*");
        return Pattern.compile(tmpP).matcher(name).matches();
    }
}
