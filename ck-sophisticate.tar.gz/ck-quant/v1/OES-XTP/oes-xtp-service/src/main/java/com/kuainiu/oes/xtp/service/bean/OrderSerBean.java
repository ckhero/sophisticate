package com.kuainiu.oes.xtp.service.bean;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 4:55 PM
 */
@Data
public class OrderSerBean extends BaseReqSerBean {
}
