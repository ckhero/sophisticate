package com.kuainiu.oes.xtp.service.xtpclient.callback.impl;

import com.kuainiu.oes.xtp.common.util.BeanMapUtils;
import com.kuainiu.oes.xtp.service.xtpclient.callback.AbstractCallbackHandle;
import com.kuainiu.oes.xtp.service.xtpclient.response.TradeResponse;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.BaseResponseWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.TradeResponseWrapper;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class OnRspQryTradeHandler extends AbstractCallbackHandle<TradeResponse> {
    @Override
    protected BaseResponseWrapper handleResponse(TradeResponse response) throws Exception {
        TradeResponseWrapper requestWrapper=new TradeResponseWrapper();
        BeanMapUtils.map(response,requestWrapper);
        requestWrapper.setPositionEffectType(response.getPositionEffectType().ordinal());
        requestWrapper.setMarketType(response.getMarketType().type);
        requestWrapper.setSideType(response.getMarketType().type);
        response.setTradeType(response.getTradeType());
        return requestWrapper;
    }
}