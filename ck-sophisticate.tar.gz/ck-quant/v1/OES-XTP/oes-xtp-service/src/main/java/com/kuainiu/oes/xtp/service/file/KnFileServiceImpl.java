package com.kuainiu.oes.xtp.service.file;

import com.kuainiu.oes.xtp.common.util.BeanMapUtils;
import com.kuainiu.oes.xtp.facade.response.OrderCommitRsp;
import com.kuainiu.oes.xtp.facade.response.TodayOrderQryRsp;
import com.kuainiu.oes.xtp.facade.xtp.OesXtpOrderFacade;
import com.kuainiu.oes.xtp.service.file.entity.XtpOrderReqCancel;
import com.kuainiu.oes.xtp.service.file.entity.XtpOrderReqCommit;
import com.kuainiu.oes.xtp.service.file.entity.XtpOrderReqQuery;
import com.kuainiu.oes.xtp.service.file.utils.StringMatcher;
import com.kuainiu.oes.xtp.service.file.utils.cache.CacheProviderService;
import com.kuainiu.oes.xtp.service.file.utils.cache.XtpRequestCache;
import com.kuainiu.oes.xtp.service.producer.OrderProducer;
import com.kuainiu.oes.xtp.service.producer.QueryProducer;
import com.kuainiu.oes.xtp.service.producer.bean.OrderProBean;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author danol
 * @Classname AsyncSftpServiceImpl
 * @Description TODO
 * @Date 9/24/2019 17:48
 */
@Slf4j
@Service
public class KnFileServiceImpl implements KnFileService {

    @Autowired
    FileProcessor fileProcessor;

    @Value("${file.local.path.request}")
    private String localRequestPath;

    @Value("${file.local.path.archive.request}")
    private String localArchiveRequestPath;

    @Resource
    OesXtpOrderFacade oesXtpOrderFacade;

    @Autowired
    XtpRequestCache xtpRequestCache;

    @Autowired
    @Qualifier("localCacheService")
    CacheProviderService cacheProviderService;

    @Autowired
    OrderProducer orderProducer;

    @Autowired
    QueryProducer queryProducer;

    private Lock lock = new ReentrantLock();

    @Override
    public void handleRequestFile(String fileName, Object data) {
        //处理commit request 文件
        if (data instanceof XtpOrderReqCommit) {
            log.info("Start to handle commit requests orders:[{}]", data.toString());
            OrderCommitRsp commitRsp = oesXtpOrderFacade.commitOrder((XtpOrderReqCommit) data);
            //带回qt order id
            cacheProviderService.set(commitRsp.getChannelOrderId(), commitRsp.getQtOrderId());

            OrderProBean order = new OrderProBean();
            BeanMapUtils.map(commitRsp, order);
            order.setQtOrderId(((XtpOrderReqCommit) data).getQtOrderId());
            log.info("Send back mapping relationship:[{}]", order.toString());
            orderProducer.send(order);
        }
        //处理 cancel request 文件
        else if (data instanceof XtpOrderReqCancel) {
            log.info("Start to handle cancel requests orders:[{}]", data.toString());
            oesXtpOrderFacade.cancelOrder((XtpOrderReqCancel) data);
        } else if (data instanceof XtpOrderReqQuery) {
            log.info("Start to query requests orders:[{}]", data.toString());
            TodayOrderQryRsp todayOrderQryRsp = oesXtpOrderFacade.qryTodayOrderAndTrans((XtpOrderReqQuery) data);
            queryProducer.send(todayOrderQryRsp);
        }
        this.moveLocalRequestFile(fileName);
    }

    @Override
    public synchronized void preLoadRequestFile(String fileName) {
        //已经处理问委托将不再进行重复处理
        if (this.fileHandledDetect(fileName)) {
            log.info("Request has been handle already, will  not try again. Request file: [{}]", fileName);
            this.moveLocalRequestFile(fileName);
            return;
        }
        // 待处理的Request文件放在map里面, 同时加入当天的已处理的缓存中

                if (!xtpRequestCache.getData().containsKey(fileName)) {
                    Object data = null;
                    if (fileName.contains("commit")) {
                        data = this.readCommitRequestFile(fileName);
                        String seriesNum = fileName.split("_")[2];
                        cacheProviderService.set(seriesNum, data);
                    } else if (fileName.contains("cancel")) {
                        data = this.readCancelRequestFile(fileName);
                    } else if (fileName.contains("query")) {
                        data = this.readQueryRequestFile(fileName);
                    }
                    if (data != null) {
                        log.info("Thread-" + Thread.currentThread().getId() + " executing put data[{}] to cache map...", fileName);
                        xtpRequestCache.getData().put(fileName, data);
                        this.moveLocalRequestFile(fileName);
                    }
                }
    }

    private boolean fileHandledDetect(String fileName) {
        String seriesNum = fileName.split("_")[2];
        return (cacheProviderService.contains(seriesNum) || Files.exists(Paths.get(this.fileAbsolutePathBuilder(localArchiveRequestPath, fileName))));
    }

    private XtpOrderReqQuery readQueryRequestFile(String fileName) {
        try {
            XtpOrderReqQuery request = fileProcessor.readeOrderQryReqFromFile(this.fileAbsolutePathBuilder(localRequestPath, fileName));
            if (request != null) {
                return request;
            } else {
                //this.deleteLocalFile(this.fileAbsolutePathBuilder(localRequestPath, fileName));
                return null;
            }
        } catch (IOException e) {
            log.error("Read response cancel file:[{}] error: {}", e);
            //this.deleteLocalFile(this.fileAbsolutePathBuilder(localRequestPath, fileName));
            return null;
        }
    }

    private XtpOrderReqCommit readCommitRequestFile(String fileName) {
        try {
            XtpOrderReqCommit request = fileProcessor.readeReqCommitFromFile(this.fileAbsolutePathBuilder(localRequestPath, fileName));
            if (request != null) {
                return request;
            } else {
                //this.deleteLocalFile(this.fileAbsolutePathBuilder(localRequestPath, fileName));
                return null;
            }
        } catch (IOException e) {
            log.error("Read response cancel file:[{}] error: {}", e);
            //this.deleteLocalFile(this.fileAbsolutePathBuilder(localRequestPath, fileName));
            return null;
        }
    }

    private XtpOrderReqCancel readCancelRequestFile(String fileName) {
        try {
            XtpOrderReqCancel request = fileProcessor.readeReqCancelFromFile(this.fileAbsolutePathBuilder(localRequestPath, fileName));
            if (request != null) {
                return request;
            } else {
                //this.deleteLocalFile(this.fileAbsolutePathBuilder(localRequestPath, fileName));
                return null;
            }

        } catch (IOException e) {
            log.error("Read response cancel file:[{}] error: {}", e);
//            this.deleteLocalFile(this.fileAbsolutePathBuilder(localRequestPath, fileName));
            return null;
        }
    }

    @Override
    public void moveLocalRequestFile(String fileName) {
        if (Files.exists(Paths.get(this.fileAbsolutePathBuilder(localRequestPath, fileName)))) {
            lock.lock();
            try {
                if (Files.exists(Paths.get(this.fileAbsolutePathBuilder(localRequestPath, fileName)))) {
                    log.info("Move request file:[{}] to archive", fileName);
                    Files.move(Paths.get(this.fileAbsolutePathBuilder(localRequestPath, fileName)), Paths.get(this.fileAbsolutePathBuilder(localArchiveRequestPath, fileName)), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
                    log.info("Move request file:[{}] success", fileName);
                }
            } catch (IOException e) {
                log.error("Move request file error: {}", e);
            } finally {
                lock.unlock();
            }
        }
    }

    @Override
    public List<String> getLocalRequestFileList() {
        return this.getLocalFileList(localRequestPath, "xtp_request*.dat.*");
    }

    @Override
    public List<String> getLocalQueryFileList() {
        return this.getLocalFileList(localRequestPath, "xtp_query*.dat.*");
    }

    @Override
    public List<String> getLocalAllFileList() {
        return this.getLocalFileList(localRequestPath, "xtp_*.dat.*");
    }

    private List<String> getLocalFileList(String localPath, String pattern) {
        this.detectDerectory(localPath);
        try (
                Stream<Path> stream = Files.list(Paths.get(localPath));
        ) {
            return stream.filter(f -> {
                return StringMatcher.matches(pattern, f.getFileName().toString());
            }).map(f -> f.getFileName().toString()).collect(Collectors.toList());
        } catch (IOException e) {
            log.error("Get local file list in {} error: {}", localPath, e);
            return null;
        }
    }

    private String fileAbsolutePathBuilder(String filePath, String fileName) {
        if (filePath.endsWith("/")) {
            return filePath.concat(fileName);
        } else {
            return filePath.concat("/").concat(fileName);
        }
    }

    private void deleteLocalFile(String fullName) {
        try {
            Files.deleteIfExists(Paths.get(fullName));
        } catch (IOException e) {
            log.error("Move response file error: {}", e);
        }
    }

    private void detectDerectory(String path) {
        if (!Files.exists(Paths.get(path))) {
            try {
                Files.createDirectories(Paths.get(path));
            } catch (IOException e) {
                log.error("创建文件夹:[{}]失败：", path, e);
            }
        }
    }
}
