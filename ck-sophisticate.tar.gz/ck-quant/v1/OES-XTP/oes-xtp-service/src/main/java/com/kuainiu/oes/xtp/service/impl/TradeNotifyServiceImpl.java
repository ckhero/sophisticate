package com.kuainiu.oes.xtp.service.impl;

import com.alibaba.fastjson.JSON;
import com.kuainiu.oes.xtp.common.enums.IsWithdrawCode;
import com.kuainiu.oes.xtp.common.util.BeanMapUtils;
import com.kuainiu.oes.xtp.service.TradeNotifyService;
import com.kuainiu.oes.xtp.service.file.utils.cache.CacheProviderService;
import com.kuainiu.oes.xtp.service.producer.TradeProducer;
import com.kuainiu.oes.xtp.service.producer.bean.TradeProBean;
import com.kuainiu.oes.xtp.service.file.entity.XtpTradeNotify;
import com.kuainiu.oes.xtp.service.xtpclient.response.TradeResponse;
import com.kuainiu.oes.xtp.common.util.QtDateUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 6:37 PM
 */
@Service
@Slf4j
public class TradeNotifyServiceImpl implements TradeNotifyService {
    @Autowired
    TradeProducer tradeProducer;

    @Autowired
    @Qualifier("localCacheService")
    CacheProviderService cacheProviderService;


    @Override
    public void notifyTrade(TradeResponse response) {
        log.info("[Service]trade notify response={}", JSON.toJSONString(response));
        TradeProBean trade = new TradeProBean();
        //String qtOrderId = String.valueOf(System.currentTimeMillis()).substring(1,3).concat(String.valueOf(response.getOrderClientId()));
        //成交数量
        Integer transQty = (int) response.getQuantity();
        //渠道订单号
        String channelOrderId = response.getOrderXtpId();
        //交易流水号
        String channelTransId = response.getExecId();
        //交易价格
        BigDecimal transPrice = new BigDecimal(response.getPrice()).setScale(6, RoundingMode.HALF_UP);;
        //交易时间
        Date transTime = QtDateUtils.convertToDate(response.getTradeTime());

        trade.setTransQty(transQty);
        trade.setChannelOrderId(channelOrderId);
        trade.setChannelTransId(channelTransId);
        trade.setTransPrice(transPrice);
        trade.setTransTime(transTime);
        trade.setIsWithdraw(IsWithdrawCode.NO.getCode());
        //trade.setQtOrderId(qtOrderId);

        // order.setQtOrderId(qtOrderId);
        // 设置qt order id,  带回交易系统
        long startTime = System.currentTimeMillis();
        //做等待超过5秒继续
        while(cacheProviderService.get(channelOrderId)==null || "".equals(cacheProviderService.get(channelOrderId))){
            if ((System.currentTimeMillis() - startTime) > 1000 * 5) {
                break;
            }
        }
        if(cacheProviderService.get(channelOrderId)!=null && !"".equals(cacheProviderService.get(channelOrderId))){
            trade.setQtOrderId(cacheProviderService.get(channelOrderId));
        }

        log.info("[Service]trade notify trade={}", JSON.toJSONString(trade));
        XtpTradeNotify tradeNotify = new XtpTradeNotify();
        BeanMapUtils.map(trade,tradeNotify);

        tradeProducer.send(trade);
    }
}
