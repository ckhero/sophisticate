package com.kuainiu.oes.xtp.service.xtpclient.request;

public class BaseRequest {
}
