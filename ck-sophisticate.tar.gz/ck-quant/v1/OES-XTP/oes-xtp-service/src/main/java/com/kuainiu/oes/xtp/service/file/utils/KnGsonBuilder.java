package com.kuainiu.oes.xtp.service.file.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kuainiu.oes.xtp.service.file.*;
import com.kuainiu.oes.xtp.service.file.entity.*;

import java.text.DateFormat;

/**
 * @Classname KnGsonBuilder
 * @Description TODO
 * @Date 2019-08-30 15:30
 * @Created by chengqiang
 */
public class KnGsonBuilder {
    private static final GsonBuilder INSTANCE = new GsonBuilder();
    static{
        INSTANCE.registerTypeAdapter(java.util.Date.class, new DateSerializer()).setDateFormat(DateFormat.LONG);
        INSTANCE.registerTypeAdapter(java.util.Date.class, new DateSerializer()).setDateFormat(DateFormat.LONG);
        INSTANCE.registerTypeAdapter(XtpOrderReqCommit.class, new XtpOrderReqCommitAdapter());
        INSTANCE.registerTypeAdapter(XtpOrderReqCancel.class, new XtpOrderReqCanelAdapter());
    }

    /**
     * create instance
     * @return
     */
    public static Gson create() {
        return INSTANCE.create();
    }
}
