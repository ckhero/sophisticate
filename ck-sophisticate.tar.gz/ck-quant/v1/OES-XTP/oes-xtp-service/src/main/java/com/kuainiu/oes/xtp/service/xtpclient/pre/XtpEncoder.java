package com.kuainiu.oes.xtp.service.xtpclient.pre;

import com.kuainiu.oes.xtp.service.xtpclient.XtpWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.BaseRequestWrapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.OrderComparator;

import java.util.*;

/**
 * 编码器
 */
@Slf4j
public class XtpEncoder {

    XtpWrapper wrapper;

    Map<Integer, List<PreEncode>> preEncodeMap = new HashMap<>();

    public XtpEncoder(XtpWrapper wrapper, PreEncode[] preEncodes) {
        this.wrapper = wrapper;
        //先将非通用的预处理放入
        Arrays.stream(preEncodes)
                .filter(preEncode -> !PreEncode.COMMON_FUNCTION.equals(preEncode.function()))
                .forEach(preEncode -> {
                    if (!preEncodeMap.containsKey(preEncode.function())) {
                        preEncodeMap.put(preEncode.function(), new ArrayList<>());
                    }
                    preEncodeMap.get(preEncode.function()).add(preEncode);
                });
        //再补充通用处理器
        Arrays.stream(preEncodes)
                .filter(preEncode -> PreEncode.COMMON_FUNCTION.equals(preEncode.function()))
                .forEach(preEncode -> {
                    if (!preEncodeMap.containsKey(preEncode.function())) {
                        preEncodeMap.put(preEncode.function(), new ArrayList<>());
                    }
                    preEncodeMap.values().forEach(list -> list.add(preEncode));
                });
        //处理器排序
        preEncodeMap.values().forEach(list -> OrderComparator.sort(list));
    }

    public void preEncode(BaseRequestWrapper requestBase){
        List<PreEncode> preEncodeList = Optional.ofNullable(preEncodeMap.get(requestBase.getFunctionId()))
                .orElse(preEncodeMap.get(PreEncode.COMMON_FUNCTION));
        Optional.ofNullable(preEncodeList)
                .ifPresent(list -> list.forEach(preEncode -> preEncode.process(requestBase)));
    }

}
