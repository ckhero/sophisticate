package com.kuainiu.oes.xtp.service.xtpclient;

import com.alibaba.fastjson.JSONObject;
import com.kuainiu.oes.xtp.exception.ServiceException;
import com.kuainiu.oes.xtp.exception.ServiceRuntimeException;
import com.kuainiu.oes.xtp.service.annotation.RequestData;
import com.kuainiu.oes.xtp.service.xtpclient.handle.DataContext;
import com.kuainiu.oes.xtp.service.xtpclient.handle.DataContextHandle;
import com.kuainiu.oes.xtp.service.xtpclient.impl.TradeRequestServiceImpl;
import com.kuainiu.oes.xtp.service.xtpclient.pre.XtpEncoder;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.BaseRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.BaseResponseWrapper;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;


@Slf4j
public class TradeApiTemplate extends TradeApiOperations implements InitializingBean {

    private TradeRequestService tradeRequestService;

    //反射缓存
    Map<Class<?>, List<Field>> fieldCache = new ConcurrentHashMap<>();


    @Autowired
    XtpEncoder encoder;

    @Setter
    @Getter
    private XtpWrapper wrapper;

    public TradeApiTemplate(XtpWrapper wrapper) {
        this.wrapper = wrapper;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        tradeRequestService = new TradeRequestServiceImpl(wrapper.getTradeApi());
    }


    @Override
    protected BaseResponseWrapper handle(BaseRequestWrapper request, Object ob) throws ServiceException {
        DataContextHandle.putIfAbsent(request.getRequestId(), request);
        request.setTarget(ob);
        return tradeRequestService.handle(request);
    }

    @Override
    protected List after(Integer requestId, int requestStatus) throws ServiceException {

        if (requestStatus != 1) {
//            throw new ServiceRuntimeException("Interface response failed");
            //TODO
            return null;
        }
        Long timeOut = 15L;

        DataContextHandle.park(requestId, Thread.currentThread(), timeOut);
        DataContext context = DataContextHandle.get(requestId);
        if (null == context) {
            throw new ServiceException("Context objects that do not get requestId :" + requestId);
        } else if (context.getResponseMsg() == null) {
            if (context.getEnd() == 0) {
                context.end();
                throw new ServiceException("Waiting for callback time out, timeout time is " + timeOut + " second");
            } else {
                throw new ServiceException("Request id " + requestId + " CallBack Exception");
            }

        } else {
            return context.getResponseMsg();
        }
    }

    @Override
    protected void pre(BaseRequestWrapper request) throws ServiceException {
        encoder.preEncode(request);
    }

    @Override
    protected Object invoke(BaseRequestWrapper request) throws ServiceException {
        log.info("{} invoke:{}", request.getClass().getSimpleName(), JSONObject.toJSONString(request));
        RequestData metaData = request.getClass().getAnnotation(RequestData.class);
        Class<?> targetClazz = metaData.clazz();
        Object targetObject = null;
        try {
            targetObject = targetClazz.newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        List<Field> originFieldList = getFields(request.getClass());
        List<Field> targetFieldList = getFields(targetObject.getClass());
        {
            Map<String, Field> targetFieldMap = targetFieldList.stream()
                    .collect(Collectors.toMap(item -> item.getName(), item -> item));
            for (Field field : originFieldList) {
                Field targetField = targetFieldMap.get(field.getName());
                if (targetField == null) {
                    continue;
                }
                fillField(request, field, targetObject, targetField);
            }
        }
        return targetObject;
    }


    protected List<Field> getFields(Class<?> clazz) {
        List<Field> result = fieldCache.get(clazz);
        if (result == null) {
            synchronized (fieldCache) {
                result = fieldCache.get(clazz);
                if (result == null) {
                    List<Field> _list = new ArrayList<>();
                    ReflectionUtils.doWithFields(clazz, field -> {
                        field.setAccessible(true);
                        _list.add(field);
                    });
                    fieldCache.put(clazz, _list);
                    result = _list;
                }
            }
        }
        return result;
    }

    protected void fillField(Object originObject, Field originField, Object targetObject, Field targetField) {
        try {
            Object value = originField.get(originObject);
            if (value == null) {
                return;
            }
            //不需要转换
            if (originField.getType().equals(targetField.getType())) {
                targetField.set(targetObject, value);
                return;
            }
            //转换
            if (originField.getType().equals(BigDecimal.class)) {
                //double转换
                targetField.set(targetObject,((BigDecimal)value).doubleValue());
            } else if (originField.getType().equals(Long.class)) {
                //long转换
                targetField.setLong(targetObject,(long)value);
            }else if (originField.getType().equals(Integer.class)) {
                //int转换
                targetField.setInt(targetObject,(int)value);
            }

        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
}