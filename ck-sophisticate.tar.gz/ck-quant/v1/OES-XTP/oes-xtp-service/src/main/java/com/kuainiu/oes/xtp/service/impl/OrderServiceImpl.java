package com.kuainiu.oes.xtp.service.impl;

import com.kuainiu.oes.xtp.exception.ServiceException;
import com.kuainiu.oes.xtp.facade.code.OesXtpRspCode;
import com.kuainiu.oes.xtp.service.OrderService;
import com.kuainiu.oes.xtp.service.xtpclient.TradeApiTemplate;
import com.kuainiu.oes.xtp.service.xtpclient.XtpWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.OrderCancelRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.OrderInsertRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.OrderQryRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.TradeQryRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.BaseResponseWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.OrderResponseWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.TradeResponseWrapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 7:15 PM
 */
@Slf4j
@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private TradeApiTemplate tradeApiTemplate;
    private XtpWrapper wrapper;

    public OrderServiceImpl(XtpWrapper wrapper){
        this.wrapper=wrapper;
    }

    @Override
    public String commitOrder(OrderInsertRequestWrapper request) throws ServiceException {
        List<BaseResponseWrapper> objs = tradeApiTemplate.call(request);
        if(CollectionUtils.isNotEmpty(objs)){
            String channelOrderId=objs.get(0).getSyncReturnStr().trim();
            if("0".equals(channelOrderId)){
                String errMsg=wrapper.getTradeApi().getApiLastError();
                log.error("commit order error:{}",errMsg);
            }
            return channelOrderId;
        }
        throw new ServiceException(OesXtpRspCode.ERR_XTP_COMMIT_ORDER);
    }

    @Override
    public void cancelOrder(OrderCancelRequestWrapper request) throws ServiceException {
        List<BaseResponseWrapper> objs = tradeApiTemplate.call(request);
    }

    @Override
    public List<OrderResponseWrapper> qryTodayOrder(OrderQryRequestWrapper request) throws ServiceException {
        List<OrderResponseWrapper> objs = tradeApiTemplate.call(request);
        if(CollectionUtils.isNotEmpty(objs)){
            return objs;
        }
        throw new ServiceException(OesXtpRspCode.ERR_XTP_QRY_ORDER);
    }

    @Override
    public List<TradeResponseWrapper> qryTodayTrans(TradeQryRequestWrapper request) throws ServiceException {
        List<TradeResponseWrapper> objs = tradeApiTemplate.call(request);
        if(CollectionUtils.isNotEmpty(objs)){
            return objs;
        }
        throw new ServiceException(OesXtpRspCode.ERR_XTP_QRY_ORDER);
    }
}
