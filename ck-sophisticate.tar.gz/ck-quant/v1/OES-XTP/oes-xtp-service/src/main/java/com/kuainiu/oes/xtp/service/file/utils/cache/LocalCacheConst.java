package com.kuainiu.oes.xtp.service.file.utils.cache;

/**
 * @author danol
 * @Classname LocalCacheConst
 * @Description TODO
 * @Date 11/5/2019 14:42
 */
public class LocalCacheConst {
    public static long CACHE_MINUTE = 60 * 60 * 24;
    public static long CACHE_MAXIMUM_SIZE = 1024 * 32;
}
