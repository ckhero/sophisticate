package com.kuainiu.oes.xtp.service.file.entity;

import com.kuainiu.oes.xtp.service.producer.bean.TradeProBean;
import com.kuainiu.oes.xtp.service.file.utils.KnGsonBuilder;

/**
 * @author danol
 * @Classname XtpTradePro
 * @Description TODO
 * @Date 10/16/2019 17:50
 */
public class XtpTradeNotify extends TradeProBean {

    public static XtpTradeNotify fromJson(String json) {
        return KnGsonBuilder.create().fromJson(json, XtpTradeNotify.class);
    }

    @Override
    public String toString() {
        return KnGsonBuilder.create().toJson(this);
    }
}
