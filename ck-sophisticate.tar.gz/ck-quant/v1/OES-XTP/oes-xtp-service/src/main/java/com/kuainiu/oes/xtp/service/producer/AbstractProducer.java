package com.kuainiu.oes.xtp.service.producer;

import com.alibaba.fastjson.JSON;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/17
 * Time: 5:44 PM
 */
@Slf4j
public abstract class AbstractProducer {
    AbstractProducer() {
        setTopicName();
    }
    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;

    @Getter
    protected String topicName;

    public <T> void send(T t) {
        String bodyMsg = JSON.toJSONString(t);
        log.info("[kafka send begin] toppic {} body {}", topicName, bodyMsg);
        kafkaTemplate.send(topicName, bodyMsg);
    }

    protected abstract void setTopicName();
}
