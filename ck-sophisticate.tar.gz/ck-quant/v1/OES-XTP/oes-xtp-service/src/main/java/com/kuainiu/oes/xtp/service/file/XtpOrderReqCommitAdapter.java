package com.kuainiu.oes.xtp.service.file;

import com.google.gson.*;
import com.kuainiu.oes.xtp.service.file.entity.XtpOrderReqCommit;
import com.kuainiu.oes.xtp.service.file.utils.GsonHelper;

import java.lang.reflect.Type;

/**
 * @author danol
 * @Classname XtpOrderRequestAdapter
 * @Description TODO
 * @Date 9/29/2019 12:00
 */
public class XtpOrderReqCommitAdapter implements JsonDeserializer<XtpOrderReqCommit> {

    @Override
    public XtpOrderReqCommit deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
        XtpOrderReqCommit xtpOrderReqCommit = new XtpOrderReqCommit();
        JsonObject jsonObject = jsonElement.getAsJsonObject();
        if (GsonHelper.isNull(jsonElement)) {
            return null;
        }
//        if (GsonHelper.isNotNull(jsonObject.get("excuteStatus"))) {
//            xtpOrderRequest.setExcuteStatus(GsonHelper.getAsString(jsonObject.get("excuteStatus")));
//        }
        if(GsonHelper.isNotNull(jsonObject.get("qtOrderId"))){
            xtpOrderReqCommit.setQtOrderId(GsonHelper.getAsString(jsonObject.get("qtOrderId")));
        }
        if (GsonHelper.isNotNull(jsonObject.get("transBoard"))){
            xtpOrderReqCommit.setTransBoard(GsonHelper.getAsString(jsonObject.get("transBoard")));
        }
        if (GsonHelper.isNotNull(jsonObject.get("assetNo"))){
            xtpOrderReqCommit.setAssetNo(GsonHelper.getAsString(jsonObject.get("assetNo")));
        }
        if (GsonHelper.isNotNull(jsonObject.get("orderQty"))){
            xtpOrderReqCommit.setOrderQty(GsonHelper.getAsInteger(jsonObject.get("orderQty")));
        }else {
            xtpOrderReqCommit.setOrderQty(0);
        }
        if (GsonHelper.isNotNull(jsonObject.get("transSide"))){
            xtpOrderReqCommit.setTransSide(GsonHelper.getAsString(jsonObject.get("transSide")));
        }
        if (GsonHelper.isNotNull(jsonObject.get("transType"))){
            xtpOrderReqCommit.setTransType(GsonHelper.getAsInteger(jsonObject.get("transType")));
        }
        if (GsonHelper.isNotNull(jsonObject.get("limitPrice"))){
            xtpOrderReqCommit.setLimitPrice(GsonHelper.getAsBigDecimal(jsonObject.get("limitPrice")));
        }
        if (GsonHelper.isNotNull(jsonObject.get("assetType"))){
            xtpOrderReqCommit.setAssetType(GsonHelper.getAsString(jsonObject.get("assetType")));
        }
        return xtpOrderReqCommit;
    }
}
