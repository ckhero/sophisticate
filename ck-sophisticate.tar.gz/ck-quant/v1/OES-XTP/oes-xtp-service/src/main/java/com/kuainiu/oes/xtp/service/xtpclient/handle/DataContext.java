package com.kuainiu.oes.xtp.service.xtpclient.handle;



import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.BaseRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.BaseResponseWrapper;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

public class DataContext {

    @Getter
    @Setter
    private Boolean isLast;

    @Setter
    @Getter
    private Integer requestId;

    @Setter
    @Getter
    private BaseRequestWrapper requestMsg;

    @Setter
    @Getter
    private List<BaseResponseWrapper> responseMsg=new ArrayList<>();

    @Setter
    @Getter
    private Throwable throwable;

    @Setter
    @Getter
    private Thread thread;

    @Setter
    @Getter
    private long start=0;

    @Setter
    @Getter
    private long end=0;


    public DataContext(Integer requestId, BaseRequestWrapper requestMsg) {
        this.requestId = requestId;
        this.requestMsg = requestMsg;
    }

    public void start(){
        start=System.currentTimeMillis();
    }

    public void end(){
        end=System.currentTimeMillis();
    }

    public long getTimeCost(){
        long result= end-start;
        if(result<0){
            return 0;
        }
        return result;
    }

    public void done(){
        setEnd(System.currentTimeMillis());
    }

    public void done(BaseResponseWrapper message){
        responseMsg.add(message);
    }

}