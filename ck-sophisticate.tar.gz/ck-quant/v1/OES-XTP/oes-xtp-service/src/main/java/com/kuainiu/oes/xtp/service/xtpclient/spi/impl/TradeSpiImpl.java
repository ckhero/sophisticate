package com.kuainiu.oes.xtp.service.xtpclient.spi.impl;


import com.kuainiu.oes.xtp.common.enums.TransferProtocol;
import com.kuainiu.oes.xtp.service.OrderNotifyService;
import com.kuainiu.oes.xtp.service.TradeNotifyService;
import com.kuainiu.oes.xtp.service.xtpclient.XtpWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.api.TradeApi;
import com.kuainiu.oes.xtp.service.xtpclient.callback.AbstractCallbackHandle;
import com.kuainiu.oes.xtp.service.xtpclient.callback.impl.OnRspQryOrderHandler;
import com.kuainiu.oes.xtp.service.xtpclient.callback.impl.OnRspQryTradeHandler;
import com.kuainiu.oes.xtp.service.xtpclient.model.ErrorMessage;
import com.kuainiu.oes.xtp.service.xtpclient.response.*;
import com.kuainiu.oes.xtp.service.xtpclient.spi.TradeSpi;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;


@Slf4j
public class TradeSpiImpl implements TradeSpi {
    @Autowired
    TradeNotifyService tradeNotifyService;

    @Autowired
    OrderNotifyService orderNotifyService;

    @Autowired
    XtpWrapper wrapper;

    @Autowired
    TradeApi tradeApi;

    @Override
    public void onOrderEvent(OrderResponse orderInfo, ErrorMessage errorMessage,
                             String sessionId) {
        log.info("onOrderEvent orderInfo: " + orderInfo.toString());
        log.info("onOrderEvent errMsg: " + errorMessage.getErrorMsg());
        orderNotifyService.notifyOrder(orderInfo);
    }

    @Override
    public void onDisconnect(String sessionId, int reason) {
        log.info("onDisconnect");
        String newSessionId=tradeApi.login(wrapper.getTradeServerIP(), wrapper.getTradeServerPort(),
                wrapper.getUserName(), wrapper.getUserPwd(), TransferProtocol.XTP_PROTOCOL_TCP);
        wrapper.setSessionId(newSessionId);
        log.info("login reconnect new sessionId:{}",sessionId);
    }

    @Override
    public void onError(ErrorMessage errorMessage) {
        log.info("onError: " + errorMessage.toString());
    }

    @Override
    public void onFundTransfer(FundTransferResponse fundTransferInfo, ErrorMessage errorMessage,
        String sessionId) {
        if (fundTransferInfo != null) {
            log.info("onFundTransfer: " + fundTransferInfo.toString());
        } else {
            log.info("onFundTransfer error: " + errorMessage.toString());
        }
    }

    @Override
    public void onQueryAsset(AssetResponse assetInfo, ErrorMessage errorMessage, String sessionId) {
        log.info("onQueryAsset: " + assetInfo.toString());
    }

    @Override
    public void onQueryETF(ETFBaseResponse etfBaseInfo, ErrorMessage errorMessage, String sessionId) {
        if (etfBaseInfo != null) {
            log.info("onQueryETF: " + etfBaseInfo.toString());
        } else {
            log.info("onQueryETF error: " + errorMessage.toString());
        }
    }

    @Override
    public void onQueryETFBasket(ETFComponentResponse etfComponentInfo, ErrorMessage errorMessage,
        String sessionId) {
        log.info("onQueryETFBasket: " + etfComponentInfo.toString());
    }

    @Override
    public void onQueryFundTransfer(FundTransferResponse fundTransferInfo, ErrorMessage errorMessage,
        String sessionId) {
        if (fundTransferInfo != null) {
            log.info("onQueryFundTransfer: " + fundTransferInfo.toString());
        } else {
            log.info("onQueryFundTransfer error: " + errorMessage.toString());
        }
    }

    @Override
    public void onQueryIPOInfoList(IPOTickerResponse ipoTickerInfo, ErrorMessage errorMessage,
        String sessionId) {
        if (ipoTickerInfo != null) {
            log.info("onQueryIPOInfoList: " + ipoTickerInfo.toString());
        } else {
            log.info("onQueryIPOInfoList error: " + errorMessage.toString());
        }

    }

    @Override
    public void onQueryIPOQuotaInfo(IPOQuotaResponse ipoQuotaInfo, ErrorMessage errorMessage,
        String sessionId) {
        log.info("onQueryIPOQuotaInfo: " + ipoQuotaInfo.toString());
    }

    @Override
    public void onQueryOrder(OrderResponse orderInfo, ErrorMessage errorMessage, String sessionId) {
        if (orderInfo != null) {
            log.info("onQueryOrder: " + orderInfo.toString());
            AbstractCallbackHandle abstractCallbackHandle = new OnRspQryOrderHandler();
            abstractCallbackHandle.callbackHandle(orderInfo.isLastResp(), orderInfo.getRequestId(), orderInfo);
        } else {
            log.info("onQueryOrder error: " + errorMessage.toString());
        }
    }

    @Override
    public void onQueryOrderByPage(OrderResponse orderInfo, long reqCount, long orderSequence, long queryReference, String sessionId) {
        if (orderInfo != null) {
            log.info("onQueryOrderByPage: " + orderInfo.toString() + "  reqCount="+reqCount+"  orderSequence="+orderSequence+"  queryReference="+queryReference+"  sessionId="+sessionId);
        } else {
            System.err.println("onQueryOrderByPage error");
        }
    }

    @Override
    public void onQueryTradeByPage(TradeResponse tradeInfo, long reqCount, long tradeSequence, long queryReference, String sessionId) {
        if (tradeInfo != null) {
            log.info("onQueryTradeByPage: " + tradeInfo.toString() + "  reqCount="+reqCount+"  tradeSequence="+tradeSequence+"  queryReference="+queryReference+"  sessionId="+sessionId);
        } else {
            System.err.println("onQueryTradeByPage error");
        }
    }

    @Override
    public void onQueryPosition(StockPositionResponse stockPositionInfo, ErrorMessage errorMessage,
        String sessionId) {
        log.info("onQueryPosition: " + stockPositionInfo.toString());
    }

    @Override
    public void onQueryStructuredFund(StructuredFundResponse structuredFundInfo,
        ErrorMessage errorMessage, String sessionId) {
        if (structuredFundInfo != null ) {
            log.info("onQueryStructuredFund: " + structuredFundInfo.toString());
        } else {
            log.info("onQueryStructuredFund error: " + errorMessage.toString());
        }
    }

    @Override
    public void onQueryTrade(TradeResponse tradeInfo, ErrorMessage errorMessage, String sessionId) {
        AbstractCallbackHandle abstractCallbackHandle = new OnRspQryTradeHandler();
        if (tradeInfo != null) {
            log.info("onQueryTrade: " + tradeInfo.toString());
            abstractCallbackHandle.callbackHandle(tradeInfo.isLastResp(), tradeInfo.getRequestId(), tradeInfo);
        } else {
            log.info("onQueryTrade error: " + errorMessage.toString());
            abstractCallbackHandle.callbackHandle(true, errorMessage.getRequestId(), null);
        }
    }

    @Override
    public void onTradeEvent(TradeResponse tradeInfo, String sessionId) {
        log.info("onTradeEvent: " + tradeInfo.toString());
        tradeNotifyService.notifyTrade(tradeInfo);
    }

    @Override
    public void onCancelOrderError(OrderCancelResponse orderCancelInfo, ErrorMessage errorMessage,
        String sessionId) {
        log.info("onCancelOrderError: " + orderCancelInfo.toString());
    }

    @Override
    public void OnQueryOptionAuctionInfo(OptionAuctionInfoResponse optionAuctionInfoResponse, ErrorMessage errorMessage, String sessionId){
        log.info("OnQueryOptionAuctionInfo: " + optionAuctionInfoResponse.toString());
    }
}
