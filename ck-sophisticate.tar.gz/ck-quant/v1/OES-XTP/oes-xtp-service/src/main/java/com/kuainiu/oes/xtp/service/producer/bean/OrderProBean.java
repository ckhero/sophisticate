package com.kuainiu.oes.xtp.service.producer.bean;

import lombok.Data;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/17
 * Time: 7:32 PM
 */
@Data
public class OrderProBean {
    private String channelOrderId;

    private String qtOrderId;

    private String status;

    private String submitStatus;

    private Date orderConfirmTime;

    private Date orderCancelTime;
}
