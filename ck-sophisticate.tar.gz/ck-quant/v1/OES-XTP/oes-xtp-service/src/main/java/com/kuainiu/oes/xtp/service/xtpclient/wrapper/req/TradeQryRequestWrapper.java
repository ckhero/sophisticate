package com.kuainiu.oes.xtp.service.xtpclient.wrapper.req;


import com.kuainiu.oes.xtp.common.consts.XtpConsts;
import com.kuainiu.oes.xtp.service.annotation.RequestData;
import com.kuainiu.oes.xtp.service.xtpclient.request.OrderAndTradeQryRequest;
import com.kuainiu.oes.xtp.service.xtpclient.request.OrderQueryRequest;
import lombok.Data;

/**
 * authored by lucaszhuang
 * 委托查询请求包装类
 */
@Data
@RequestData(clazz = OrderAndTradeQryRequest.class,hasResponse = true)
public class TradeQryRequestWrapper extends BaseRequestWrapper{
    public TradeQryRequestWrapper() {
        setFunctionId(XtpConsts.QueryFunction.QRY_TRADE_BY_CHANNEL_ID);
    }
    private String orderXtpId;

}
