package com.kuainiu.oes.xtp.service.bean;

import lombok.Data;

@Data
public class CalcStatusBean {

    private String status;

    private String submitStatus;
}