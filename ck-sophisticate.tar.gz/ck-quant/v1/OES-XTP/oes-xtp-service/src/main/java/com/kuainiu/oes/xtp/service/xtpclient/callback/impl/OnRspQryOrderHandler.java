package com.kuainiu.oes.xtp.service.xtpclient.callback.impl;

import com.kuainiu.oes.xtp.common.util.BeanMapUtils;
import com.kuainiu.oes.xtp.service.xtpclient.callback.AbstractCallbackHandle;
import com.kuainiu.oes.xtp.service.xtpclient.response.OrderResponse;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.BaseResponseWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.OrderResponseWrapper;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class OnRspQryOrderHandler extends AbstractCallbackHandle<OrderResponse> {


    @Override
    protected BaseResponseWrapper handleResponse(OrderResponse response) throws Exception {
        OrderResponseWrapper requestWrapper=new OrderResponseWrapper();
        BeanMapUtils.map(response,requestWrapper);
        requestWrapper.setBusinessType(response.getBusinessType().ordinal());
        requestWrapper.setOrderStatusType(response.getOrderStatusType().type);
        requestWrapper.setOrderSubmitStatusType(response.getOrderSubmitStatusType().type);
        requestWrapper.setPositionEffectType(response.getPositionEffectType().ordinal());
        return requestWrapper;
    }
}
