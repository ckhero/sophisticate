package com.kuainiu.oes.xtp.service.xtpclient.pre;


import com.kuainiu.oes.xtp.service.xtpclient.XtpWrapper;
import lombok.extern.slf4j.Slf4j;

/**
 * 预处理抽象类
 * authored by lucaszhuang
 */
@Slf4j
public abstract class AbstractPreEncode implements PreEncode {

    protected XtpWrapper wrapper;

    public AbstractPreEncode(XtpWrapper wrapper) {
        this.wrapper = wrapper;
    }

}
