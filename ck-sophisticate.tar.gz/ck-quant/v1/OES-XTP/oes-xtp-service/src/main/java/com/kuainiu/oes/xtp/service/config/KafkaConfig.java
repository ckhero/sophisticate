package com.kuainiu.oes.xtp.service.config;

import com.kuainiu.oes.xtp.service.producer.*;
import lombok.Data;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/17
 * Time: 5:48 PM
 */
@Data
@Configuration
public class KafkaConfig
{
    public final static String TOPIC_QT_TRANS_STK_ORDER_NOTIFY = "qt-trans-stk-order-notify";

    public final static String TOPIC_QT_TRANS_STK_TRANS_NOTIFY = "qt-trans-stk-trans-notify";

    public final static String TOPIC_QT_TRANS_STK_QUERY_NOTIFY = "qt-trans-stk-query-notify";

    public final static String TOPIC_QT_TRANS_STK_ORDER_COMMIT_RESPONSE = "qt-trans-stk-order-commit-response";

    public final static String TOPIC_QT_TRANS_STK_ORDER_CANCEL_RESPONSE = "qt-trans-stk-order-cancel-response";

    @Bean
    OrderProducer orderProducer() {
        return new OrderProducer();
    }

    @Bean
    TradeProducer tradeProducer() {
        return new TradeProducer();
    }

    @Bean
    QueryProducer queryProducer() {
        return new QueryProducer();
    }

    @Bean
    CommitResponseProducer commitResponseProducer() {
        return new CommitResponseProducer();
    }

    @Bean
    CancelResponseProducer cancelResponseProducer() {
        return new CancelResponseProducer();
    }
}
