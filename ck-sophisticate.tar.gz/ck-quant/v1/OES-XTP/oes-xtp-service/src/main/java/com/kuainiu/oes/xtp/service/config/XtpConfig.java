package com.kuainiu.oes.xtp.service.config;


import com.kuainiu.oes.xtp.service.OrderService;
import com.kuainiu.oes.xtp.service.impl.OrderServiceImpl;
import com.kuainiu.oes.xtp.service.xtpclient.TradeApiTemplate;
import com.kuainiu.oes.xtp.service.xtpclient.XtpWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.api.TradeApi;
import com.kuainiu.oes.xtp.service.xtpclient.pre.MsgIdGenerator;
import com.kuainiu.oes.xtp.service.xtpclient.pre.OrderInsertPreEncode;
import com.kuainiu.oes.xtp.service.xtpclient.pre.PreEncode;
import com.kuainiu.oes.xtp.service.xtpclient.pre.XtpEncoder;
import com.kuainiu.oes.xtp.service.xtpclient.spi.TradeSpi;
import com.kuainiu.oes.xtp.service.xtpclient.spi.impl.TradeSpiImpl;
import lombok.Data;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

/**
 * authored by lucas.zhuang
 * xtp项目配置
 */
@Configuration
@Data
public class XtpConfig {

    @Bean(initMethod = "init")
    @DependsOn(value = "tradeApi")
    public XtpWrapper wrapper(TradeApi tradeApi, TradeSpi tradeSpi) {
        return new XtpWrapper(tradeApi,tradeSpi);
    }

    @Bean
    @DependsOn(value = "tradeSpi")
    public TradeApi tradeApi(TradeSpi tradeSpi){
        return new TradeApi(tradeSpi);
    }

    @Bean
    public TradeSpi tradeSpi(){
        return new TradeSpiImpl();
    }

    @Bean("orderService")
    @DependsOn(value = "wrapper")
    public OrderService orderService(XtpWrapper wrapper){
        return new OrderServiceImpl(wrapper);
    }

    @Bean("tradeApiTemplate")
    public TradeApiTemplate tradeApiTemplate(XtpWrapper wrapper) {
        TradeApiTemplate tradeApiTemplate = new TradeApiTemplate(wrapper);
        return tradeApiTemplate;
    }

    @Bean
    public XtpEncoder encoder(XtpWrapper wrapper, PreEncode[] preEncodes) {
        return new XtpEncoder(wrapper, preEncodes);
    }

    @Bean
    public MsgIdGenerator msgIdGenerator(XtpWrapper wrapper) {
        return new MsgIdGenerator(wrapper);
    }

    @Bean
    public OrderInsertPreEncode orderInsertPareEncode(XtpWrapper wrapper) {
        return new OrderInsertPreEncode(wrapper);
    }

}
