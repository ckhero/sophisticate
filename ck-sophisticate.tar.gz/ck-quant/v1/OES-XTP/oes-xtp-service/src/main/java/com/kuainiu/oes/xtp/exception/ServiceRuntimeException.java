package com.kuainiu.oes.xtp.exception;


import com.kuainiu.oes.xtp.facade.code.OesXtpRspCode;
import com.kuainiu.oes.xtp.facade.response.BaseOesXtpRsp;
import com.kuainiu.oes.xtp.common.util.CommonConstant;
import org.apache.commons.lang3.StringUtils;

import java.text.MessageFormat;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/19
 * Time: 10:10 AM
 */
public class ServiceRuntimeException extends RuntimeException{
    private OesXtpRspCode OesXtpRspCode;

    private String code;

    private String msg;

    public ServiceRuntimeException(OesXtpRspCode OesXtpRspCode){
        this.OesXtpRspCode = OesXtpRspCode;
        this.code = OesXtpRspCode.getCode();
        this.msg = OesXtpRspCode.getMsg();
    }

    public ServiceRuntimeException(OesXtpRspCode OesXtpRspCode, Throwable t){
        super(t);
        this.OesXtpRspCode = OesXtpRspCode;
        this.code = OesXtpRspCode.getCode();
        this.msg = OesXtpRspCode.getMsg();
    }

    public ServiceRuntimeException(OesXtpRspCode OesXtpRspCode, String msg, Throwable t){
        super(t);
        this.OesXtpRspCode = OesXtpRspCode;
        this.code = OesXtpRspCode.getCode();
        this.msg = OesXtpRspCode.getMsg();
        if (null != msg) {
            this.msg += CommonConstant.COMMA + msg;
        }
    }

    public ServiceRuntimeException(OesXtpRspCode OesXtpRspCode, String msg){
        this.OesXtpRspCode = OesXtpRspCode;
        this.code = OesXtpRspCode.getCode();
        this.msg = OesXtpRspCode.getMsg();
        if (StringUtils.isNotBlank(msg)) {
            this.msg += CommonConstant.COMMA + msg;
        }
    }

    public void setCode(String code){
        this.code = code;
    }

    public String getCode(){
        return code;
    }

    public String getMsg(){
        return msg;
    }

    public void setMsg(String msg){
        this.msg = msg;
    }

    public void exceptionToResponse(BaseOesXtpRsp response){
        response.setCode(this.getCode());
        response.setMsg(this.getMsg());
    }

    public ServiceRuntimeException(String pattern, Object... arguments){
        super(MessageFormat.format(pattern, arguments));
    }
}
