package com.kuainiu.oes.xtp.service.file;

import com.kuainiu.oes.xtp.service.file.entity.XtpOrderReqQuery;
import com.kuainiu.oes.xtp.service.file.entity.XtpOrderReqCancel;
import com.kuainiu.oes.xtp.service.file.entity.XtpOrderReqCommit;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * @author danol
 * @Classname SftpFileProcessorImpl
 * @Description TODO
 * @Date 9/29/2019 14:51
 */
@Component
@Slf4j
public class FileProcessorImpl implements FileProcessor{

    @Override
    public XtpOrderReqCommit readeReqCommitFromFile(String filename) throws IOException {
        return XtpOrderReqCommit.fromJson(new String(Files.readAllBytes(Paths.get(filename))));
    }

    @Override
    public XtpOrderReqCancel readeReqCancelFromFile(String filename) throws IOException {
        return XtpOrderReqCancel.fromJson(new String(Files.readAllBytes(Paths.get(filename))));
    }

    @Override
    public XtpOrderReqQuery readeOrderQryReqFromFile(String filename) throws IOException {
        return XtpOrderReqQuery.fromJson(new String(Files.readAllBytes(Paths.get(filename))));
    }
}
