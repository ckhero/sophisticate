package com.kuainiu.oes.xtp.service.xtpclient.wrapper.req;


import com.kuainiu.oes.xtp.common.consts.XtpConsts;
import com.kuainiu.oes.xtp.service.annotation.RequestData;
import com.kuainiu.oes.xtp.service.xtpclient.request.OrderAndTradeQryRequest;
import com.kuainiu.oes.xtp.service.xtpclient.request.OrderCancelRequest;
import com.kuainiu.oes.xtp.service.xtpclient.request.OrderQueryRequest;
import lombok.Data;

/**
 * authored by lucaszhuang
 * 委托查询请求包装类
 */
@Data
@RequestData(clazz = OrderAndTradeQryRequest.class,hasResponse = true)
public class OrderQryRequestWrapper extends BaseRequestWrapper{
    public OrderQryRequestWrapper() {
        setFunctionId(XtpConsts.QueryFunction.QRY_ORDER_BY_CHANNEL_ID);
    }
    private String orderXtpId;

}
