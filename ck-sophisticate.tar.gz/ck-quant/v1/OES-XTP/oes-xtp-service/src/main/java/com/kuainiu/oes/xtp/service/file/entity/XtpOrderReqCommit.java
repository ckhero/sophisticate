package com.kuainiu.oes.xtp.service.file.entity;

import com.kuainiu.oes.xtp.facade.request.OrderCommitReq;
import com.kuainiu.oes.xtp.service.file.utils.KnGsonBuilder;
import lombok.Data;

/**
 * @author danol
 * @Classname XtpOrderRequest
 * @Description TODO
 * @Date 9/29/2019 11:55
 */
@Data
public class XtpOrderReqCommit extends OrderCommitReq {
    /**
     * 文件处理状态
     */
    //private String excuteStatus;

    public static XtpOrderReqCommit fromJson(String json) {
        return KnGsonBuilder.create().fromJson(json, XtpOrderReqCommit.class);
    }

    @Override
    public String toString() {
        return KnGsonBuilder.create().toJson(this);
    }
}
