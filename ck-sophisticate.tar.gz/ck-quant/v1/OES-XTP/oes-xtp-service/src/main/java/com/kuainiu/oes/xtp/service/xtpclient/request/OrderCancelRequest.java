package com.kuainiu.oes.xtp.service.xtpclient.request;


import lombok.*;

@Data
public class OrderCancelRequest {

    private String orderXtpId;

}
