package com.kuainiu.oes.xtp.service.xtpclient.wrapper.req;


import com.kuainiu.oes.xtp.common.consts.XtpConsts;
import com.kuainiu.oes.xtp.common.enums.*;
import com.kuainiu.oes.xtp.service.annotation.RequestData;
import com.kuainiu.oes.xtp.service.xtpclient.request.OrderCancelRequest;
import com.kuainiu.oes.xtp.service.xtpclient.request.OrderInsertRequest;
import lombok.Data;

import java.math.BigDecimal;

/**
 * authored by lucaszhuang
 * 撤单请求包装类
 */
@Data
@RequestData(clazz = OrderCancelRequest.class)
public class OrderCancelRequestWrapper extends BaseRequestWrapper{
    public OrderCancelRequestWrapper() {
        setFunctionId(XtpConsts.TransFunction.ORDER_CANCEL);
    }
    private String orderXtpId;

}
