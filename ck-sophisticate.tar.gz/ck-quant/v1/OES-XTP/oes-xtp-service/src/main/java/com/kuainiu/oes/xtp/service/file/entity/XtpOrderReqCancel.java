package com.kuainiu.oes.xtp.service.file.entity;

import com.kuainiu.oes.xtp.facade.request.OrderCancelReq;
import com.kuainiu.oes.xtp.service.file.utils.KnGsonBuilder;
import lombok.Data;

/**
 * @author danol
 * @Classname XtpOrderRequest
 * @Description TODO
 * @Date 9/29/2019 11:55
 */
@Data
public class XtpOrderReqCancel extends OrderCancelReq {

    public static XtpOrderReqCancel fromJson(String json) {
        return KnGsonBuilder.create().fromJson(json, XtpOrderReqCancel.class);
    }

    @Override
    public String toString() {
        return KnGsonBuilder.create().toJson(this);
    }
}
