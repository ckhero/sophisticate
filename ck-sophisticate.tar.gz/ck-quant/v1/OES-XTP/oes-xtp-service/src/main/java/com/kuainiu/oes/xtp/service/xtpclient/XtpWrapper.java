package com.kuainiu.oes.xtp.service.xtpclient;

import com.kuainiu.oes.xtp.common.enums.*;
import com.kuainiu.oes.xtp.service.xtpclient.api.TradeApi;
import com.kuainiu.oes.xtp.service.xtpclient.request.OrderInsertRequest;
import com.kuainiu.oes.xtp.service.xtpclient.spi.TradeSpi;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;

import java.util.List;


/**
 * authored by lucas.zhuang
 * xtp项目包装类
 */
@Slf4j
public class XtpWrapper {

    public XtpWrapper(TradeApi tradeApi, TradeSpi tradeSpi){
        this.tradeApi=tradeApi;
        this.tradeSpi=tradeSpi;
    }
    @Getter
    @Value("${xtp.config.clientId:18}")
    Short clientId;
    @Getter
    @Value("${xtp.config.serverKey:18}")
    String serverKey;
    @Getter
    @Value("${xtp.config.tradeServerIP:18}")
    String tradeServerIP;
    @Getter
    @Value("${xtp.config.tradeServerPort:18}")
    Integer tradeServerPort;
    @Getter
    @Value("${xtp.config.userName:18}")
    String userName;
    @Getter
    @Value("${xtp.config.userPwd:18}")
    String userPwd;
    @Getter
    @Value("${xtp.config.quoteServerPort:18}")
    Integer quoteServerPort;
    @Getter
    @Value("${xtp.config.quoteServerIP:18}")
    String quoteServerIP;
    @Getter
    @Value("${xtp.config.udpBufferSize:512}")
    Integer udpBufferSize;

    @Value("${xtp.config.logPath:c:\\oes-xtp}")
    String logPath;


    @Getter
    @Setter
    TradeApi tradeApi;
    @Getter
    @Setter
    TradeSpi tradeSpi;
    @Getter
    @Setter
    String sessionId;

    public static int baseMsgId=(int)System.currentTimeMillis();

    public void init(){
        //加载动态链接库
        JNILoadLibrary.loadLibrary();
        //初始化API
        tradeApi.init(clientId, serverKey,
                logPath, XtpLogLevel.XTP_LOG_LEVEL_TRACE, JniLogLevel.JNI_LOG_LEVEL_INFO, XtpTeResumeType.XTP_TERT_RESTART);
        tradeApi.subscribePublicTopic(XtpTeResumeType.XTP_TERT_QUICK);
        tradeApi.setHeartBeatInterval(30);
        String sessionId=tradeApi.login(tradeServerIP, tradeServerPort,
                userName, userPwd, TransferProtocol.XTP_PROTOCOL_TCP);
        log.info("login sessionId:{}",sessionId);
        if(StringUtils.isEmpty(sessionId)||"0".equals(sessionId.trim())){
            tradeApi.init((short)(clientId+1), serverKey,
                    logPath, XtpLogLevel.XTP_LOG_LEVEL_TRACE, JniLogLevel.JNI_LOG_LEVEL_INFO, XtpTeResumeType.XTP_TERT_RESTART);
            tradeApi.subscribePublicTopic(XtpTeResumeType.XTP_TERT_QUICK);
            tradeApi.setHeartBeatInterval(30);
            sessionId=tradeApi.login(tradeServerIP, tradeServerPort,
                    userName, userPwd, TransferProtocol.XTP_PROTOCOL_TCP);
            log.info("login retry sessionId:{}",sessionId);
        }
        this.setSessionId(sessionId);


    }

    private String testOrderInsert(){
        //现货
        OrderInsertRequest req = OrderInsertRequest.builder()
                .orderXtpId("0").orderClientId(3).ticker("600010").marketType(MarketType.XTP_MKT_SH_A)
//                .price(26d)
                .stopPrice(0d).quantity(100L).priceType(PriceType.XTP_PRICE_BEST5_OR_CANCEL)
                .sideType(SideType.XTP_SIDE_BUY).businessType(BusinessType.XTP_BUSINESS_TYPE_CASH)
                .positionEffectType(PositionEffectType.XTP_POSITION_EFFECT_INIT).build();
        String s = tradeApi.insertOrder(req, sessionId);
        return s;
    }
}
