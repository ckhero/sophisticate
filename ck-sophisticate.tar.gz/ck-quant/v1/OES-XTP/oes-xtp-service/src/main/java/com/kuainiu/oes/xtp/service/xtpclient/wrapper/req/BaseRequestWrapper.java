package com.kuainiu.oes.xtp.service.xtpclient.wrapper.req;

import lombok.Data;

/**
 * authored by lucaszhuang
 * 基础请求包装类
 */
@Data
public class BaseRequestWrapper {

    /**
     * 功能号
     */
    private Integer functionId;

    /**
     * 请求号
     */
    private Integer requestId;
    /**
     * 登录session号
     */
    private String sessionId;
    /**
     * 转完对象
     */
    private Object target;
}
