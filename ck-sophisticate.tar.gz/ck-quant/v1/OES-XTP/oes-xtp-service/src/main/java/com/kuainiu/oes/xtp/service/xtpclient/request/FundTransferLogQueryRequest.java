package com.kuainiu.oes.xtp.service.xtpclient.request;


import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of = {"serialId"})
@Builder
public class FundTransferLogQueryRequest {

    /**资金内转编号*/
    private String serialId;
}