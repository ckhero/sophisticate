package com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * authored by lucaszhuang
 * 基础返回包装类
 */
@Data
public class BaseResponseWrapper<T> {
    /**
     * 请求号
     */
    private Integer requestId;

    /**
     * 返回码
     */
    private Integer returnCode=0;
    /**
     * 同步返回的字符串
     */
    private String syncReturnStr;

    @Getter
    @Setter
    private Boolean isLast;

    @Getter
    @Setter
    private String code;

    @Getter
    @Setter
    private String message;

    public static BaseResponseWrapper<Void> of(String code, String message) {
        BaseResponseWrapper<Void> inst = new BaseResponseWrapper<>();
        inst.code = code;
        inst.message = message;
        return inst;
    }
}
