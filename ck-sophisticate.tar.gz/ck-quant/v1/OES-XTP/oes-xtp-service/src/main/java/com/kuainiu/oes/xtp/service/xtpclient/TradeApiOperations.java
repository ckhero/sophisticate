package com.kuainiu.oes.xtp.service.xtpclient;


import com.kuainiu.oes.xtp.exception.ServiceException;
import com.kuainiu.oes.xtp.service.annotation.RequestData;
import com.kuainiu.oes.xtp.service.xtpclient.handle.DataContextHandle;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.BaseRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.BaseResponseWrapper;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;
import java.util.List;

@Slf4j
public abstract class TradeApiOperations {

    protected abstract BaseResponseWrapper handle(BaseRequestWrapper request, Object ob) throws ServiceException;

    protected abstract List<BaseResponseWrapper> after(Integer requestId, int requestStatus) throws ServiceException;

    protected abstract void pre(BaseRequestWrapper request) throws ServiceException;

    protected abstract Object invoke(BaseRequestWrapper request) throws ServiceException;

    public List call(BaseRequestWrapper request) throws ServiceException {
        pre(request);
        Integer requestId = request.getRequestId();
        try {
            BaseResponseWrapper syncResp = handle(request, invoke(request));
            int requestStatus=syncResp.getReturnCode();
//            if (requestStatus ==0 ) {
//                Thread.sleep(1000);
//                log.info("{} return status:{},retry", request.getClass().getSimpleName(), requestStatus);
//                requestStatus = handle(request, invoke(request));
//            }
            log.info("{} return status:{}", request.getClass().getSimpleName(), requestStatus);
            if (hasResponse(request)) {
                return after(requestId, requestStatus);
            } else {
                return Arrays.asList(syncResp);
            }
        } catch (ServiceException e) {
            throw e;
        }  finally {
            DataContextHandle.clear(requestId);//清除上下文对象
        }

    }

    /**
     * 判断是否是同步返回
     * @param base
     * @return
     */
    private boolean hasResponse(BaseRequestWrapper base) {
        RequestData metaData = base.getClass().getAnnotation(RequestData.class);
        return metaData.hasResponse();
    }
}
