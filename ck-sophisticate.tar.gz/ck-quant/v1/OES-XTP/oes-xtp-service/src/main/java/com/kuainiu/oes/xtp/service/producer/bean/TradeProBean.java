package com.kuainiu.oes.xtp.service.producer.bean;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/17
 * Time: 7:32 PM
 */
@Data
public class TradeProBean {
    private String channelOrderId;

    private String qtOrderId;

    private String channelTransId;

    private Integer transQty;

    private BigDecimal transPrice;

    private Date transTime;

    private String isWithdraw;
}
