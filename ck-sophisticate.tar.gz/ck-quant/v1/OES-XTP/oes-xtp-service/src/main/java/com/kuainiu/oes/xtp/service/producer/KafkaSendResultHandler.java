package com.kuainiu.oes.xtp.service.producer;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.kafka.support.ProducerListener;
import org.springframework.stereotype.Component;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/10
 * Time: 10:58 AM
 */
@Slf4j
@Component
public class KafkaSendResultHandler implements ProducerListener {
    @Override
    public void onSuccess(ProducerRecord producerRecord, RecordMetadata recordMetadata) {
        log.info("[kafka send succ]topic={};partition={};offset={};data={};", producerRecord.topic(), recordMetadata.partition(), recordMetadata.offset(), producerRecord.value());
    }

    @Override
    public void onError(ProducerRecord producerRecord, Exception exception) {
        log.error("[kafka send fail]", exception);
        log.error("[kafka send fail]", producerRecord.value());
    }
}
