package com.kuainiu.oes.xtp.service.xtpclient;


import com.kuainiu.oes.xtp.exception.ServiceException;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.BaseRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.BaseResponseWrapper;

public interface TradeRequestService {

     BaseResponseWrapper handle(BaseRequestWrapper request) throws ServiceException;

}
