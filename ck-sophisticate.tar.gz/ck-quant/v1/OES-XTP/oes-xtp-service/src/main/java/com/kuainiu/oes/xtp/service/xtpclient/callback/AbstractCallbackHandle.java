package com.kuainiu.oes.xtp.service.xtpclient.callback;

import com.kuainiu.oes.xtp.facade.code.OesXtpRspCode;
import com.kuainiu.oes.xtp.service.xtpclient.handle.DataContextHandle;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.BaseResponseWrapper;
import lombok.extern.slf4j.Slf4j;


@Slf4j
public abstract class AbstractCallbackHandle<T extends Object> {

    public void callbackHandle(boolean isLast, Integer requestId, T t) {
        BaseResponseWrapper responseMsg = null;
        try {
            if (null != t) {
                responseMsg = handleResponse(t);
            }
        } catch (Exception e) {
            log.error("Callback exception，the reason is ", e.getMessage());
            responseMsg = BaseResponseWrapper.of(OesXtpRspCode.ERR_XTP_CALLBACK.getCode(), OesXtpRspCode.ERR_XTP_CALLBACK.getMsg());
        } finally {
//            if (null != t) {
                DataContextHandle.callBack(requestId, responseMsg);
//            }
            if (isLast) {
                DataContextHandle.unpark(requestId);//释放线程
            }
        }

    }

    protected abstract BaseResponseWrapper handleResponse(T response) throws Exception;
}
