package com.kuainiu.oes.xtp.service.file;

import java.util.List;

/**
 * @author danol
 * @Classname AsyncSftpService
 * @Description TODO
 * @Date 9/24/2019 17:46
 */
public interface KnFileService {
    void handleRequestFile(String fileName, Object data);
    void preLoadRequestFile(String fileName);
    List<String> getLocalRequestFileList();
    List<String> getLocalQueryFileList();
    List<String> getLocalAllFileList();
    void moveLocalRequestFile(String fileName);
}
