package com.kuainiu.oes.xtp.service;

import com.kuainiu.oes.xtp.service.xtpclient.response.TradeResponse;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 4:53 PM
 */
public interface TradeNotifyService {
    void notifyTrade(TradeResponse response);
}
