package com.kuainiu.oes.xtp.service.file;

import com.google.gson.*;
import com.kuainiu.oes.xtp.service.file.entity.XtpOrderReqQuery;
import com.kuainiu.oes.xtp.service.file.utils.GsonHelper;

import java.lang.reflect.Type;

/**
 * @author danol
 * @Classname XtpCurrentDayOrderQryReqAdapter
 * @Description TODO
 * @Date 11/7/2019 14:17
 */
public class XtpOrderReqQueryAdapter implements JsonDeserializer<XtpOrderReqQuery> {
    @Override
    public XtpOrderReqQuery deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
        XtpOrderReqQuery xtpOrderReqQuery = new XtpOrderReqQuery();
        JsonObject jsonObject = jsonElement.getAsJsonObject();
        if (GsonHelper.isNull(jsonElement)) {
            return null;
        }
        if(GsonHelper.isNotNull(jsonObject.get("channelOrderId"))){
            xtpOrderReqQuery.setChannelOrderId(GsonHelper.getAsString(jsonObject.get("channelOrderId")));
        }
        if(GsonHelper.isNotNull(jsonObject.get("qtOrderId"))){
            xtpOrderReqQuery.setQtOrderId(GsonHelper.getAsString(jsonObject.get("qtOrderId")));
        }
        if(GsonHelper.isNotNull(jsonObject.get("assetNo"))){
            xtpOrderReqQuery.setAssetNo(GsonHelper.getAsString(jsonObject.get("assetNo")));
        }
        return xtpOrderReqQuery;
    }
}
