package com.kuainiu.oes.xtp.service.file.entity;

import com.kuainiu.oes.xtp.facade.request.TodayOrderQryReq;
import com.kuainiu.oes.xtp.service.file.utils.KnGsonBuilder;

/**
 * @author danol
 * @Classname XtpCurrentDayOrderQryReq
 * @Description TODO
 * @Date 11/7/2019 14:15
 */
public class XtpOrderReqQuery extends TodayOrderQryReq {
    public static XtpOrderReqQuery fromJson(String json) {
        return KnGsonBuilder.create().fromJson(json, XtpOrderReqQuery.class);
    }

    @Override
    public String toString() {
        return KnGsonBuilder.create().toJson(this);
    }
}
