package com.kuainiu.oes.xtp.service.xtpclient.wrapper.req;


import com.kuainiu.oes.xtp.common.consts.XtpConsts;
import com.kuainiu.oes.xtp.common.enums.*;
import com.kuainiu.oes.xtp.service.annotation.RequestData;
import com.kuainiu.oes.xtp.service.xtpclient.request.OrderInsertRequest;
import lombok.*;

import java.math.BigDecimal;
/**
 * authored by lucaszhuang
 * 下单请求包装类
 */
@Data
@RequestData(clazz = OrderInsertRequest.class,hasResponse = false)
public class OrderInsertRequestWrapper extends BaseRequestWrapper{
    public OrderInsertRequestWrapper() {
        setFunctionId(XtpConsts.TransFunction.ORDER_INSERT);
    }
    /**XTP系统订单ID，无需用户填写，在XTP系统中唯一 */
    private String orderXtpId;
    /**报单引用，由客户自定义*/
    private Integer orderClientId;
    /**合约代码 客户端请求不带空格*/
    private String ticker;
    /**交易市场*/
    private MarketType marketType;
    /**价格*/
    private BigDecimal price;
    /**止损价*/
    private BigDecimal stopPrice;
    /**数量(股票单位为股，逆回购单位为张)*/
    private Long quantity;
    /**报单价格*/
    private PriceType priceType;
    /**买卖方向*/
    private SideType sideType;
    /**开平标志*/
    private PositionEffectType positionEffectType;
    /**业务类型*/
    private BusinessType businessType;

    public int getMarketType() {
        return marketType.ordinal();
    }

    public int getPriceType() {
        return priceType.getType();
    }

    public int getSideType() {
        return sideType.getType();
    }

    public int getPositionEffectType() {
        if(positionEffectType==null) return 0;//默认为初始化类型  现货适用
        else return positionEffectType.ordinal();
    }


    public int getBusinessType() {
        return businessType.ordinal();
    }

}
