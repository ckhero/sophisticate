package com.kuainiu.oes.xtp.service.xtpclient.impl;

import com.kuainiu.oes.xtp.common.consts.XtpConsts;
import com.kuainiu.oes.xtp.exception.ServiceException;
import com.kuainiu.oes.xtp.service.xtpclient.TradeRequestService;
import com.kuainiu.oes.xtp.service.xtpclient.api.TradeApi;
import com.kuainiu.oes.xtp.service.xtpclient.request.OrderCancelRequest;
import com.kuainiu.oes.xtp.service.xtpclient.request.OrderInsertRequest;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.BaseRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.OrderQryRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.req.TradeQryRequestWrapper;
import com.kuainiu.oes.xtp.service.xtpclient.wrapper.resp.BaseResponseWrapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.annotation.Order;

@Slf4j
public class TradeRequestServiceImpl implements TradeRequestService {

    private TradeApi traderApi;

    public TradeRequestServiceImpl(TradeApi traderApi) {
        this.traderApi = traderApi;
    }

    @Override
    public BaseResponseWrapper handle(BaseRequestWrapper requestBase) throws ServiceException {
        Integer functionId = requestBase.getFunctionId();
        BaseResponseWrapper resp=new BaseResponseWrapper();
        Integer requestId = requestBase.getRequestId();
        String rtnStr;
        int rtnStatus;
        switch (functionId) {
            case XtpConsts.TransFunction.ORDER_INSERT:
                rtnStr=traderApi.insertOrder((OrderInsertRequest) requestBase.getTarget(), requestBase.getSessionId());
                if(StringUtils.isNotEmpty(rtnStr)){
                    resp.setReturnCode(1);
                    resp.setRequestId(requestId);
                    resp.setSyncReturnStr(rtnStr);
                }
                break;
            case XtpConsts.TransFunction.ORDER_CANCEL:
                rtnStr=traderApi.cancelOrder(((OrderCancelRequest) requestBase.getTarget()).getOrderXtpId(), requestBase.getSessionId());
                if(StringUtils.isNotEmpty(rtnStr)){
                    resp.setReturnCode(1);
                    resp.setRequestId(requestId);
                    resp.setSyncReturnStr(rtnStr);
                }
                break;

            case XtpConsts.QueryFunction.QRY_ORDER_BY_CHANNEL_ID:
                rtnStatus=traderApi.queryOrderByXtpId(((OrderQryRequestWrapper)requestBase).getOrderXtpId(), requestBase.getSessionId(),requestBase.getRequestId());
                if(rtnStatus==0){
                    resp.setReturnCode(1);
                    resp.setRequestId(requestId);
                }
                break;
            case XtpConsts.QueryFunction.QRY_TRADE_BY_CHANNEL_ID:
                rtnStatus=traderApi.queryTradesByXtpId(((TradeQryRequestWrapper)requestBase).getOrderXtpId(), requestBase.getSessionId(),requestBase.getRequestId());
                if(rtnStatus==0){
                    resp.setReturnCode(1);
                    resp.setRequestId(requestId);
                }
                break;
            default:
                throw new ServiceException("No interface functionId:" + functionId);
        }
        return resp;
    }
}
