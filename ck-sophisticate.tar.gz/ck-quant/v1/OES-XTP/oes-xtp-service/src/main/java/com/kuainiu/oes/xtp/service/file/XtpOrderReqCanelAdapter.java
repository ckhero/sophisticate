package com.kuainiu.oes.xtp.service.file;

import com.google.gson.*;
import com.kuainiu.oes.xtp.service.file.entity.XtpOrderReqCancel;
import com.kuainiu.oes.xtp.service.file.utils.GsonHelper;

import java.lang.reflect.Type;

/**
 * @author danol
 * @Classname XtpOrderRequestAdapter
 * @Description TODO
 * @Date 9/29/2019 12:00
 */
public class XtpOrderReqCanelAdapter implements JsonDeserializer<XtpOrderReqCancel> {

    @Override
    public XtpOrderReqCancel deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
        XtpOrderReqCancel xtpOrderReqCancel = new XtpOrderReqCancel();
        JsonObject jsonObject = jsonElement.getAsJsonObject();
        if (GsonHelper.isNull(jsonElement)) {
            return null;
        }

        if(GsonHelper.isNotNull(jsonObject.get("channelOrderId"))){
            xtpOrderReqCancel.setChannelOrderId(GsonHelper.getAsString(jsonObject.get("channelOrderId")));
        }

        return xtpOrderReqCancel;
    }
}
