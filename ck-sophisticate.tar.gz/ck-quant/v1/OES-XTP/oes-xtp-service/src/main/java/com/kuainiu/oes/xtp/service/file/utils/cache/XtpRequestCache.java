package com.kuainiu.oes.xtp.service.file.utils.cache;

import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author danol
 * @Classname XtpRequestCache
 * @Description TODO
 * @Date 10/23/2019 16:18
 */
@Component
public class XtpRequestCache {
    private static ConcurrentHashMap<String, Object> data;

    @PostConstruct
    private void init(){
        data = new ConcurrentHashMap<String, Object>(256);
    }
    public ConcurrentHashMap<String, Object> getData(){
        return data;
    }
}
