package com.kuainiu.oes.xtp.service.xtpclient.request;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
public class OrderAndTradeQryRequest {

    private String orderXtpId;


}
