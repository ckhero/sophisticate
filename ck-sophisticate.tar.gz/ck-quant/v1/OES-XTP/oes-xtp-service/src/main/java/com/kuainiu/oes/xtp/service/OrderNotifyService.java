package com.kuainiu.oes.xtp.service;

import com.kuainiu.oes.xtp.service.xtpclient.response.OrderResponse;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 4:54 PM
 */
public interface OrderNotifyService {

    void notifyOrder(OrderResponse response);
}
