package com.kuainiu.oes.xtp.common.enums;

import lombok.Getter;
import lombok.Setter;


public enum XtpAssetTypeCode {
    /**股票*/
    XTP_ASSET_TYPE_STK(1, "STK"),
    /**可转债*/
    XTP_ASSET_TYPE_CV(2, "CV"),
    ;

    @Getter
    @Setter
    private int type;

    @Getter
    @Setter
    private String assetType;

    XtpAssetTypeCode(int type, String transBoard) {
        this.type = type;
        this.assetType = transBoard;
    }

    public static XtpAssetTypeCode getCodeByAssetType(String transBoard) {
        if (null == transBoard) {
            return null;
        }
        for (XtpAssetTypeCode assetTypeCode: XtpAssetTypeCode.values()) {
            if (assetTypeCode.getAssetType().equals(transBoard)) {
                return assetTypeCode;
            }
        }
        return null;
    }
}
