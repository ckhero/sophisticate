package com.kuainiu.oes.xtp.common.enums;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 3:55 PM
 */
public enum XtpMarketTypeCode {
    /**深圳A股*/
    XTP_MKT_SZ_A(1, "SZ"),
    /**上海A股*/
    XTP_MKT_SH_A(2, "SH"),
    ;

    @Getter
    @Setter
    private int type;

    @Getter
    @Setter
    private String transBoard;

    XtpMarketTypeCode(int type, String transBoard) {
        this.type = type;
        this.transBoard = transBoard;
    }

    public static XtpMarketTypeCode getCodeByTransBoard(String transBoard) {
        if (null == transBoard) {
            return null;
        }
        for (XtpMarketTypeCode marketTypeCode: XtpMarketTypeCode.values()) {
            if (marketTypeCode.getTransBoard().equals(transBoard)) {
                return marketTypeCode;
            }
        }
        return null;
    }
}
