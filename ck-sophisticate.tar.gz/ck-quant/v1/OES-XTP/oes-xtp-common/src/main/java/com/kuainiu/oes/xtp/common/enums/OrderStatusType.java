package com.kuainiu.oes.xtp.common.enums;

import lombok.Getter;

/**
 * 报单状态类型
 */
public enum OrderStatusType {
    /**初始化*/
    XTP_ORDER_STATUS_INIT(1),
    /**全部成交*/
    XTP_ORDER_STATUS_ALLTRADED(2),
    /**部分成交*/
    XTP_ORDER_STATUS_PARTTRADEDQUEUEING(3),
    /**部分撤单*/
    XTP_ORDER_STATUS_PARTTRADEDNOTQUEUEING(4),
    /**未成交*/
    XTP_ORDER_STATUS_NOTRADEQUEUEING(5),
    /**已撤单*/
    XTP_ORDER_STATUS_CANCELED(6),
    /**已拒绝*/
    XTP_ORDER_STATUS_REJECTED(7),
    /**未知订单状态*/
    XTP_ORDER_STATUS_UNKNOWN(8),
    ;

    @Getter
    public final int type;

    OrderStatusType(int type) {
        this.type = type;
    }

    public static OrderStatusType forType(int type) {
        for (OrderStatusType orderStatusType: OrderStatusType.values()) {
            if (orderStatusType.getType() == type) {
                return orderStatusType;
            }
        }
        return XTP_ORDER_STATUS_UNKNOWN;
    }
}
