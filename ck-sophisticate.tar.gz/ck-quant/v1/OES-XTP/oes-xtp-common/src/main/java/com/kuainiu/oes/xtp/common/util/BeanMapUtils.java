package com.kuainiu.oes.xtp.common.util;

import org.springframework.beans.BeanUtils;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * bean拷贝类
 * authored by lucas.zhuang
 */
public class BeanMapUtils {

  public static void map(Object src, Object tar){
    BeanUtils.copyProperties(src, tar);
  }

  public static <S, D> List<D> mapAsList(List<S> srcList, Class<D> tar)
      throws InstantiationException, IllegalAccessException{
    List<D> tarList = new ArrayList<D>();
    if (CollectionUtils.isEmpty(srcList)) {
      return tarList;
    }
    for (S s : srcList) {
      D d = tar.newInstance();
      BeanUtils.copyProperties(s, d);
      tarList.add(d);
    }
    return tarList;
  }

}
