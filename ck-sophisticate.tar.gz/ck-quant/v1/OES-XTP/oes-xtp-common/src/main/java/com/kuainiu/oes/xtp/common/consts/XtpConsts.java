package com.kuainiu.oes.xtp.common.consts;

public class XtpConsts {
    public static class TransFunction {
        public static final int ORDER_INSERT = 100;
        public static final int ORDER_CANCEL = 101;
    }
    public static class QueryFunction {
        public static final int QRY_ORDER_BY_CHANNEL_ID = 200;
        public static final int QRY_TRADE_BY_CHANNEL_ID = 201;
    }
}
