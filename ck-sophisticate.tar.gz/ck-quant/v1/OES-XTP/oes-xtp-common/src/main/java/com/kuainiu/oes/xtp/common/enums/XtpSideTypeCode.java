package com.kuainiu.oes.xtp.common.enums;

import lombok.Getter;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 4:15 PM
 */
public enum XtpSideTypeCode {
    /**买（新股申购、ETF买等）*/
    XTP_SIDE_BUY(1, "BUY"),
    /**卖（逆回购）*/
    XTP_SIDE_SELL(2, "SELL"),
    ;

    @Getter
    private int type;

    @Getter
    private String transSide;

    XtpSideTypeCode(int type, String transSide) {
        this.transSide = transSide;
        this.type = type;
    }

    public static XtpSideTypeCode getCodeByTransSide(String transSide) {
        if (null == transSide) {
            return null;
        }
        for (XtpSideTypeCode xtpSideTypeCode: XtpSideTypeCode.values()) {
            if (xtpSideTypeCode.getTransSide().equals(transSide)) {
                return xtpSideTypeCode;
            }
        }
        return null;
    }
}
