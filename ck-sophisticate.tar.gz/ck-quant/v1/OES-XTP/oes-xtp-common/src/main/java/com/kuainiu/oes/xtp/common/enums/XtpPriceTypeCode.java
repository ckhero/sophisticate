package com.kuainiu.oes.xtp.common.enums;

import lombok.Getter;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 4:06 PM
 */
public enum XtpPriceTypeCode {
    MARKET_BUY(100, "市价买入", 4),

    OPTIMAL_REMNANT_TRANS_BUY(101, "最优成交剩撤买入", 4),

    LIMIT_PRICE_BUY(110, "限价买入", 1),

    MARKET_SELL(200, "市价卖出", 4),

    OPTIMAL_REMNANT_TRANS_SELL(201, "最优成交剩撤卖出", 4),

    LIMIT_PRICE_SELL(210, "限价卖出", 1),
    ;
    @Getter
    private Integer code;

    @Getter
    private String desc;

    @Getter
    private int type;

    XtpPriceTypeCode(int code, String desc, int type) {
        this.code = code;
        this.desc = desc;
        this.type = type;
    }

    public static XtpPriceTypeCode getTransTypeByCode(Integer code) {
        if (0 == code){
            return null;
        }
        for (XtpPriceTypeCode transType : XtpPriceTypeCode.values()) {
            if (transType.getCode().equals(code)) {
                return transType;
            }
        }
        return null;
    }
}
