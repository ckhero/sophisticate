package com.kuainiu.oes.xtp.common.enums;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/15
 * Time: 7:48 PM
 * @author user
 */
public enum IsWithdrawCode {
    /**
     * withdraw code: withdraw order
     */
    YES("YES", "撤单"),
    /**
     * withdraw code: not withdraw order
     */
    NO("NO", "非撤单"),
    ;

    private String code;

    private String desc;

    IsWithdrawCode(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static IsWithdrawCode getEnum(String code) {
        if (null == code){
            return null;
        }
        for (IsWithdrawCode isWithdrawCode : IsWithdrawCode.values()) {
            if (code.equals(isWithdrawCode.getCode())) {
                return isWithdrawCode;
            }
        }
        return null;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
