package com.kuainiu.oes.xtp.common.util;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 6:49 PM
 */
public class QtDateUtils {

    public static final String DATE_FORMAT_LONG = "yyyyMMddHHmmss";

    /**
     * LocalDateTime to Date
     * @param dateToConvert
     * @return
     */
    public static Date convertToDateViaInstant(LocalDateTime dateToConvert) {
        return Date.from(dateToConvert.atZone(ZoneId.systemDefault())
                .toInstant());
    }

    public static Date convertToDate(long date) {
        String dateStr = String.valueOf(date);
        DateTimeFormatter formatter = new DateTimeFormatterBuilder()
                .appendPattern(DATE_FORMAT_LONG)
                .appendValue(ChronoField.MILLI_OF_SECOND, 3)
                .toFormatter();
        LocalDateTime localDateTime = LocalDateTime.parse(dateStr, formatter);
        return convertToDateViaInstant(localDateTime);
    }
}
