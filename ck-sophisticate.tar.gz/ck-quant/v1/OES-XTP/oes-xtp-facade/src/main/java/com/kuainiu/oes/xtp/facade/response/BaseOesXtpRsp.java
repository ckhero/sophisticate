package com.kuainiu.oes.xtp.facade.response;

import com.kuainiu.oes.xtp.facade.code.OesXtpRspCode;
import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 2:22 PM
 */
@Data
public class BaseOesXtpRsp extends BaseRsp {
    public void setErrorCodeAndException(OesXtpRspCode rspCode, Throwable e) {
        //TODO
    }
}
