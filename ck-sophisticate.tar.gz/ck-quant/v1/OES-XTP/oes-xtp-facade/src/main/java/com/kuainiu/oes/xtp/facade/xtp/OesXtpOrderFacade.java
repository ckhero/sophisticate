package com.kuainiu.oes.xtp.facade.xtp;

import com.kuainiu.oes.xtp.facade.request.OrderCancelReq;
import com.kuainiu.oes.xtp.facade.request.OrderCommitReq;
import com.kuainiu.oes.xtp.facade.request.TodayOrderQryReq;
import com.kuainiu.oes.xtp.facade.response.OrderCancelRsp;
import com.kuainiu.oes.xtp.facade.response.OrderCommitRsp;
import com.kuainiu.oes.xtp.facade.response.TodayOrderQryRsp;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 2:30 PM
 */
public interface OesXtpOrderFacade {
    OrderCommitRsp commitOrder(OrderCommitReq request);

    OrderCancelRsp cancelOrder(OrderCancelReq request);

    TodayOrderQryRsp qryTodayOrderAndTrans(TodayOrderQryReq request);
}
