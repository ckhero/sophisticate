package com.kuainiu.oes.xtp.facade.request;

import lombok.Data;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 2:26 PM
 */
@Data
public class OrderCommitReq extends BaseOesXtpReq {

    private String qtOrderId;
    /**
     * 交易板块
     */
    private String transBoard;

    /**
     * 股票代码
     */
    private String assetNo;

    /**
     * 交易数量 单位/股
     */
    private Integer orderQty = 0;

    /**
     * 交易方向
     */
    private String transSide;

    /**
     * 交易类型
     */
    private Integer transType;

    private BigDecimal limitPrice;

    /**
     * 资产类型：
     * STK 股票
     * CV  可转债
     */
    private String assetType;
}
