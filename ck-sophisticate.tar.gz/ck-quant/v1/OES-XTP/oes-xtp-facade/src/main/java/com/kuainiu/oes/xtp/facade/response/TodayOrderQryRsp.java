package com.kuainiu.oes.xtp.facade.response;

import com.kuainiu.oes.xtp.facade.bean.TodayOrderBean;
import com.kuainiu.oes.xtp.facade.bean.TodayTransBean;
import lombok.Data;

import java.util.List;


@Data
public class TodayOrderQryRsp extends BaseOesXtpRsp{
    TodayOrderBean todayOrderBean;
    List<TodayTransBean> todayTransBeanList;
}

