package com.kuainiu.oes.xtp.facade.bean;

import lombok.Data;

import java.util.Date;

@Data
public class TodayOrderBean extends BaseFacBean {
    private String channelOrderId;

    private String qtOrderId;

    private String status;

    private String submitStatus;

    private Date orderConfirmTime;

    private Date orderCancelTime;
}
