package com.kuainiu.oes.xtp.facade.response;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 2:25 PM
 */
@Data
public class OrderCancelRsp extends BaseOesXtpRsp {
    private String qtOrderId;
}
