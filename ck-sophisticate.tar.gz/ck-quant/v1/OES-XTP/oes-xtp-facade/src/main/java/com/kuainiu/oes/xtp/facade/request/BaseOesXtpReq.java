package com.kuainiu.oes.xtp.facade.request;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 2:26 PM
 */
@Data
public class BaseOesXtpReq extends BaseReq {
}
