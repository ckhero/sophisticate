package com.kuainiu.oes.xtp.facade.code;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/6
 * Time: 2:56 PM
 */
public enum OesXtpRspCode {
    SUCCESS("处理成功", "10"),
    FAIL("操作失败", "20"),
    /**
     * 业务类异常 2XXX,外部需回滚
     */


    /**
     * 系统内异常 3xxx
     */
    ERR_SYS_ERROR("交易系统错误", "00500013001"),

    SYS_TIMEOUT("交易系统超时", "00500013002"),

    SYS_ERROR("交易系统错误", "00500013003"),

    ERR_DBERR("db错误", "00500013004"),

    ERR_CHANNEL_RULE_FAIL("渠道路由没命中", "00500013005"),

    ERR_PARAM_ERROR_REQUEST("请求参数异常","00500013006"),
    ERR_PARAM_ERROR_RESPONSE("响应参数异常","00500013007"),

    /**
     * 系统间问题 ,4xxx
     */
    ERR_PARAM_ERROR("参数错误", "00500014001"),
    ERR_PARAM_TRANS_BOARD("交易板块不能为空", "00500014002"),
    ERR_PARAM_ASSET_NO("股票代码不能为空", "00500014003"),
    ERR_PARAM_ORDER_AMOUNT("委托数量要大于0", "00500014004"),
    ERR_PARAM_TRANS_TYPE("交易方式不能为空", "00500014005"),
    ERR_PARAM_CHANNEL_ORDER_ID("渠道订单号不能为空", "00500014006"),
    ERR_PARAM_QT_ORDER_ID("交易系统订单号不能为空", "00500014007"),
    ERR_PARAM_TRANS_SIDE("交易方向不能为空", "00500014008"),
    ERR_PARAM_ASSET_TYPE("资产类型不能为空", "00500014009"),
    ERR_PARAM_CV_NOT_SUPPORT_MARKET("可转债不支持市价操作", "00500014010"),


    /**
     *  业务类异常 5XXX,外部不用回滚
     */

    ERR_BUSI_ERROR("业务错误", "00500015001"),
    ERR_COMMIT_ORDER("委托失败", "00500015002"),
    ERR_CANCEL_ORDER("取消委托失败", "00500015003"),
    ERR_TRANS_BORAD("非法的交易板块", "00500015004"),
    ERR_TRANS_SIDE("非法的交易防线", "00500015005"),
    ERR_TRANS_TYPE("非法的交易类型", "00500015006"),
    ERR_XTP_COMMIT_ORDER("向XTP发起委托失败", "00500015007"),
    ERR_XTP_QRY_ORDER("向XTP发起查询委托失败", "00500015008"),
    ERR_XTP_QRY_TRADE("向XTP发起查询委托失败", "00500015009"),
    ERR_XTP_CALLBACK("XTP回报处理失败", "00500015010"),

    ;

    @Setter
    @Getter
    private String code;

    @Setter
    @Getter
    private String msg;

    private OesXtpRspCode(String message, String code){
        this.code = code;
        this.msg = message;
    }

    public static OesXtpRspCode getEnum(String value){
        if (null == value) {
            return null;
        }
        OesXtpRspCode[] crc = OesXtpRspCode.values();
        for (int i = 0; i < crc.length; i++) {
            if (crc[i].getCode().equals(value)) {
                return crc[i];
            }
        }
        return null;
    }

    public static OesXtpRspCode getEnumOrDefault(String value){
        if (null == value) {
            return SYS_ERROR;
        }
        OesXtpRspCode[] crc = OesXtpRspCode.values();
        for (int i = 0; i < crc.length; i++) {
            if (crc[i].getCode().equals(value)) {
                return crc[i];
            }
        }
        return SYS_ERROR;
    }
}
