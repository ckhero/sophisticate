package com.kuainiu.oes.xtp.facade.bean;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class TodayTransBean extends BaseFacBean {
    private String channelOrderId;

    private String channelTransId;

    private Integer transQty;

    private BigDecimal transPrice;

    private Date transTime;

    private String isWithdraw;
}
