package com.kuainiu.oes.xtp.facade.request;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 2:27 PM
 */
@Data
public class OrderCancelReq extends BaseOesXtpReq {
    private String channelOrderId;
    private String qtOrderId;
}
