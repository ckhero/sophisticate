package com.kuainiu.oes.xtp.facade.bean;

import java.io.Serializable;

public class BaseFacBean implements Serializable {
    private static final long serialVersionUID = 875436129763621379L;
}