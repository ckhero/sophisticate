package com.kuainiu.oes.xtp.facade.request;

import lombok.Data;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 2:29 PM
 */
@Data
public class BaseReq implements Serializable {

    private static final long serialVersionUID = 3631257388971869817L;
}
