package com.kuainiu.oes.xtp.facade.response;

import lombok.Data;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 2:21 PM
 */
@Data
public class BaseRsp implements Serializable {
    private static final long serialVersionUID = 2770148927273917797L;

    String code;

    String msg;

    private Throwable exception;
}

