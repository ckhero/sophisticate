package com.kuainiu.oes.xtp.facade.request;

import lombok.Data;

import java.math.BigDecimal;


@Data
public class TodayOrderQryReq extends BaseOesXtpReq {

    private String qtOrderId;
    private String channelOrderId;

    /**
     * 股票代码
     */
    private String assetNo;

}
