package com.kuainiu.oes.xtp.web.controller;

import com.kuainiu.oes.xtp.facade.request.OrderCancelReq;
import com.kuainiu.oes.xtp.facade.request.OrderCommitReq;
import com.kuainiu.oes.xtp.facade.request.TodayOrderQryReq;
import com.kuainiu.oes.xtp.facade.response.OrderCancelRsp;
import com.kuainiu.oes.xtp.facade.response.OrderCommitRsp;
import com.kuainiu.oes.xtp.facade.response.TodayOrderQryRsp;
import com.kuainiu.oes.xtp.facade.xtp.OesXtpOrderFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/8
 * Time: 3:30 PM
 */
@RestController
@RequestMapping("order")
@Slf4j
public class OrderController {
    @Autowired
    OesXtpOrderFacade oesXtpOrderFacade;

    @PostMapping(value="commit",produces = "application/json;charset=UTF-8")
    OrderCommitRsp commitOrder(@RequestBody OrderCommitReq request) {
        return oesXtpOrderFacade.commitOrder(request);
    }

    @PostMapping(value="cancel",produces = "application/json;charset=UTF-8")
    OrderCancelRsp cancelOrder(@RequestBody OrderCancelReq request) {
        return oesXtpOrderFacade.cancelOrder(request);
    }

    @PostMapping(value = "qryTodayOrderAndTrans",produces = "application/json;charset=UTF-8")
    public TodayOrderQryRsp queryTodayOrderAndTrans(@RequestBody TodayOrderQryReq request)
    {
        TodayOrderQryRsp response = oesXtpOrderFacade.qryTodayOrderAndTrans(request);
        return response;
    }
}
