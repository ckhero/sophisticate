package com.kuainiu.oes.xtp.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/6
 * Time: 3:58 PM
 */
@SpringBootApplication(scanBasePackages = "com.kuainiu.oes.xtp")
@EnableAsync
public class OesXtpWebApplication {
    public static void main(String[] args) {
        SpringApplication.run(OesXtpWebApplication.class, args);
    }

}
