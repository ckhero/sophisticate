package com.kuainiu.oes.xtp.web.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * @author danol
 * @Classname FileController
 * @Description TODO
 * @Date 11/4/2019 11:22
 */
@RestController
@RequestMapping("file")
@Slf4j
public class FileController {
    @Value("${file.local.path.request}")
    private String localRequestPath;

    @PostMapping("/upload")
    ResponseEntity<Object> upFile(@RequestParam("userfile") MultipartFile file) {
        String fullFileName = this.fileAbsolutePathBuilder(localRequestPath, file.getOriginalFilename());
        log.info("Full file name is: [{}]", fullFileName);
        try {
            if (Files.notExists(Paths.get(fullFileName))) {
                log.info("create file: [{}]", fullFileName);
                Files.createFile(Paths.get(fullFileName));
                log.info("create file: [{}] end", fullFileName);
            }
            if(Files.exists(Paths.get(fullFileName))){
                Files.write(Paths.get(fullFileName), file.getBytes());
            }else{
                return new ResponseEntity<Object>("Upload failed", HttpStatus.SERVICE_UNAVAILABLE);
            }
            return new ResponseEntity<Object>("Uploaded", HttpStatus.OK);
        } catch (IOException e) {
            log.error("Write file: [{}] to: [{}] failed", file.getName(), localRequestPath);
            return new ResponseEntity<Object>(e, HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    private String fileAbsolutePathBuilder(String filePath, String fileName) {
        if (filePath.endsWith("/")) {
            return filePath.concat(fileName);
        } else {
            return filePath.concat("/").concat(fileName);
        }
    }
}
