package com.kuainiu.qt.admin.bean;

public class BaseFacadeBean {
}
