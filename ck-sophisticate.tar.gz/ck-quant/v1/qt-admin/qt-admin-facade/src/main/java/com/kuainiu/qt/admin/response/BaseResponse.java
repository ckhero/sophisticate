package com.kuainiu.qt.admin.response;

import lombok.Data;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/2
 * Time: 2:38 PM
 */
@Data
public class BaseResponse implements Serializable {

    private static final long serialVersionUID = 8416580146722082469L;

    private static final String SYSTEM_NAME = "[Admin]";

    private String code;

    private String msg;
}
