package com.kuainiu.qt.admin.bean;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/30
 * Time: 9:45 PM
 */
@Data
public class FuturesTransFacadeBean {
    private String qtOrderId;
    private String qtTransId;
    private String channelTransId;
    private String assetNo;
    private Integer transQty;
    private BigDecimal transPrice;
    private BigDecimal transCost;
    private String positionEffect;
    private String submitStatus;
    private String status;
    private Date transTime;
    private String transSide;
    private String futuresType;
}
