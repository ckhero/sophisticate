package com.kuainiu.qt.admin.response;

import com.kuainiu.qt.admin.bean.StkOrderCommitFacadeBean;
import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-25
 * Time: 17:05
 */
@Data
public class StkOrderCommitResponse extends BaseQtAdminResponse {
    private StkOrderCommitFacadeBean data;
}
