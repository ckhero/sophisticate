package com.kuainiu.qt.admin.request;

import lombok.Data;

@Data
public class StkTransListQryRequest extends BaseQtAdminRequest {

    private String portfolioCode;

    private String strategyCode;
}
