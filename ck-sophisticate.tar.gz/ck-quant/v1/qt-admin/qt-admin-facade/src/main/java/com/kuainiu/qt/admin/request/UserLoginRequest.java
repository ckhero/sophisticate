package com.kuainiu.qt.admin.request;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-17
 * Time: 11:05
 */
public class UserLoginRequest extends BaseQtAdminRequest {
    private String username;
    private String password;
}
