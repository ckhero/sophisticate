package com.kuainiu.qt.admin.response;

import com.kuainiu.qt.admin.bean.PortfolioInfoQryFacadeBean;
import lombok.Data;

@Data
public class PortfolioInfoQryResponse extends BaseQtAdminResponse {
    private PortfolioInfoQryFacadeBean data;
}
