package com.kuainiu.qt.admin.facade;

import com.kuainiu.qt.admin.request.StkOrderCommitRequest;
import com.kuainiu.qt.admin.response.StkOrderCommitResponse;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-25
 * Time: 17:29
 */
public interface StkTradeFacade {
    StkOrderCommitResponse stkOrderCommit(StkOrderCommitRequest request);
}
