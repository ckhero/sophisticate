package com.kuainiu.qt.admin.code;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-26
 * Time: 16:34
 */

public enum QtAdminExternalRspCode {
    SUCCESS(0, "10", "处理成功"),
    ;

    @Setter
    @Getter
    private Integer code;

    @Setter
    @Getter
    private String sysCode;

    @Setter
    @Getter
    private String  msg;

    QtAdminExternalRspCode(Integer code, String sysCode, String msg) {
        this.code = code;
        this.sysCode = sysCode;
        this.msg = msg;
    }

    public static Integer getCodeBySysCode(String sysCode) {
        for (QtAdminExternalRspCode adminExternalRspCode: QtAdminExternalRspCode.values()) {
            if (sysCode.equals(adminExternalRspCode.getSysCode())) {
                return adminExternalRspCode.getCode();
            }
        }
        return Integer.parseInt(sysCode);
    }
}
