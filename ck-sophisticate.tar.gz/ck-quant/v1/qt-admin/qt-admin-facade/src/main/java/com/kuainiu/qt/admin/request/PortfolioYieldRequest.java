package com.kuainiu.qt.admin.request;

import lombok.Data;

import java.util.Date;

@Data
public class PortfolioYieldRequest extends BaseQtAdminRequest {
    private String portfolioCode;
    private String strategyCode;
    private Date startBelongTime;
    private Date endBelongTime;
}
