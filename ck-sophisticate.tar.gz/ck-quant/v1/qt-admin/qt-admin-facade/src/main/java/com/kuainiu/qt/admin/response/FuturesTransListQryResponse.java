package com.kuainiu.qt.admin.response;

import com.kuainiu.qt.admin.bean.FuturesTransQryFacadeBean;
import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/30
 * Time: 9:44 PM
 */
@Data
public class FuturesTransListQryResponse extends BaseQtAdminResponse {
    private FuturesTransQryFacadeBean data;
}
