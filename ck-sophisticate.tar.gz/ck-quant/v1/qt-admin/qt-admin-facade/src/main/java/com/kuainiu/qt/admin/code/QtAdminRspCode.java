package com.kuainiu.qt.admin.code;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/2
 * Time: 2:33 PM
 */
public enum QtAdminRspCode {

    SUCCESS("处理成功", "10"),
    FAIL("操作失败", "20"),
    /**
     * 业务类异常 2XXX,外部需回滚
     */


    /**
     * 系统内异常 3xxx
     */
    ERR_SYS_ERROR("交易系统错误", "00200013001"),

    SYS_TIMEOUT("交易系统超时", "00200013002"),

    SYS_ERROR("交易系统错误", "00200013003"),

    ERR_DBERR("db错误", "00200013004"),

    ERR_CHANNEL_RULE_FAIL("渠道路由没命中", "00200013005"),

    ERR_PARAM_ERROR_REQUEST("请求参数异常","00200013006"),
    ERR_PARAM_ERROR_RESPONSE("响应参数异常","00200013007"),

    /**
     * 系统间问题 ,4xxx
     */
    ERR_PARAM_ERROR("参数错误", "00200014001"),
    ERR_PARAM_CODE_REQUIRED("入参编号不能为空", "00200014002"),
    ERR_DUBBO_REMOTE_NO_PROVIDER("DUBBO服务无服务提供者","00200014003"),
    ERR_QT_TRANS_REQUEST_FAIL("trans系统请求失败","00200014004"),
    ERR_HTTP_RESPONSE_CLASS_NULL("HTTP请求响应class为空", "002000140005"),
    ERR_HTTP_CONNECT("HTTP连接异常", "002000140006"),
    ERR_QUANT_REQUEST_FAIL("quant系统响应失败", "00200014007"),

    /**
     *  业务类异常 5XXX,外部不用回滚
     */
    ERR_BUSI_ERROR("业务错误", "00200015001"),
    ERR_STK_ORDER_COMMIT_FAIL("股票下单失败", "00200015002"),

    //其他
    ERR_PORTFOLIO_QRY_FAIL("投资组合查询失败", "00200016002"),

    //参数
    ERR_PARAM_PORTFOLIO_CODE_REQUIRED("投资组合编码不能为空", "00200017001"),
    ERR_PARAM_STRATEGY_CODE_REQUIRED("策略编码错误","00200017002"),


    /**
     *  用户登录及权限类 8XXX
     */
    USER_NOT_LOGIN("用户需要登录","00200018001"),
    USER_NO_PERMISSION("用户权限不足","00200018002"),
    ;

    @Setter
    @Getter
    private String code;

    @Setter
    @Getter
    private String msg;

    private QtAdminRspCode(String message, String code){
        this.code = code;
        this.msg = message;
    }

    public static QtAdminRspCode getEnum(String value){
        if (null == value) {
            return null;
        }
        QtAdminRspCode[] crc = QtAdminRspCode.values();
        for (int i = 0; i < crc.length; i++) {
            if (crc[i].getCode().equals(value)) {
                return crc[i];
            }
        }
        return null;
    }

    public static QtAdminRspCode getEnumOrDefault(String value){
        if (null == value) {
            return SYS_ERROR;
        }
        QtAdminRspCode[] crc = QtAdminRspCode.values();
        for (int i = 0; i < crc.length; i++) {
            if (crc[i].getCode().equals(value)) {
                return crc[i];
            }
        }
        return SYS_ERROR;
    }
}
