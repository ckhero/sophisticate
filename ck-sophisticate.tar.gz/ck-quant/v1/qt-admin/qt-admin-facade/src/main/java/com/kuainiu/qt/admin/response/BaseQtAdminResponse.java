package com.kuainiu.qt.admin.response;

import com.kuainiu.qt.admin.code.QtAdminRspCode;
import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/2
 * Time: 2:41 PM
 */
@Data
public class BaseQtAdminResponse extends BaseResponse {
    public void setErrorCodeAndException(QtAdminRspCode qtAdminRspCode, Throwable e) {
        //TODO
    }
}
