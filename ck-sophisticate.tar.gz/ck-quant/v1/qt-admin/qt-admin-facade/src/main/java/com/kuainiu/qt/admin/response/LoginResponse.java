package com.kuainiu.qt.admin.response;

import lombok.Data;

/**
 * @author chengqiang
 * @Classname LoginResponse
 * @Description TODO
 * @Created by chengqiang
 * @Date 2019/9/12 2:19 PM
 */
@Data
public class LoginResponse extends BaseResponse {
    private String data;
}
