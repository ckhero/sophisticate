package com.kuainiu.qt.admin.request;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/30
 * Time: 9:46 PM
 */
@Data
public class FuturesTransListQryRequest extends BaseQtAdminRequest {

    private String portfolioCode;

    private String strategyCode;
}
