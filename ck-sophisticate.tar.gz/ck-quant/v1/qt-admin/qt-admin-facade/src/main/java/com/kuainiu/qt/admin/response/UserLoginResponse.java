package com.kuainiu.qt.admin.response;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-17
 * Time: 11:04
 */
@Data
public class UserLoginResponse extends BaseResponse {
}
