package com.kuainiu.qt.admin.bean;

import lombok.Data;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/30
 * Time: 9:54 PM
 */
@Data
public class FuturesTransQryFacadeBean extends BaseFacadeBean {
    private Integer total;
    private List<FuturesTransFacadeBean> list;
}
