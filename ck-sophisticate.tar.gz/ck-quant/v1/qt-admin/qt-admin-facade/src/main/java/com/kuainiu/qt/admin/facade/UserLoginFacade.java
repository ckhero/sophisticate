package com.kuainiu.qt.admin.facade;

import com.kuainiu.qt.admin.request.UserLoginRequest;
import com.kuainiu.qt.admin.response.UserLoginResponse;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-17
 * Time: 11:17
 */
public interface UserLoginFacade {
    UserLoginResponse login (UserLoginRequest request);
}
