package com.kuainiu.qt.admin.facade;

import com.kuainiu.qt.admin.response.FuturesTransListQryResponse;
import com.kuainiu.qt.admin.response.PortfolioInfoQryResponse;
import com.kuainiu.qt.admin.response.StkTransListQryResponse;
import com.kuainiu.qt.admin.request.FuturesTransListQryRequest;
import com.kuainiu.qt.admin.request.PortfolioInfoQryRequest;
import com.kuainiu.qt.admin.request.StkTransListQryRequest;

public interface PortfolioInfoQryFacade {

    PortfolioInfoQryResponse qryPortfolioInfo (PortfolioInfoQryRequest request);

    StkTransListQryResponse qryStkTransList(StkTransListQryRequest request);

    FuturesTransListQryResponse qryFuturesTransList(FuturesTransListQryRequest request);
}
