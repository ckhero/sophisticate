package com.kuainiu.qt.admin.bean;

import lombok.Data;

import java.util.List;

@Data
public class StkTransListFacadeBean extends BaseFacadeBean{
    private Integer total;
    private List<StkTransQryFacadeBean> list;
}
