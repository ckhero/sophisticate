package com.kuainiu.qt.admin.response;



import com.kuainiu.qt.admin.bean.PortfolioYieldQryFacadeBean;
import lombok.Data;

import java.util.List;

@Data
public class PortfolioYieldResponse extends BaseQtAdminResponse {
    List<PortfolioYieldQryFacadeBean> data;
}
