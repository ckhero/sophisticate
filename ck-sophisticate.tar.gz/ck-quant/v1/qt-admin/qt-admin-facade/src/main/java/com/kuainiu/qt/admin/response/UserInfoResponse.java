package com.kuainiu.qt.admin.response;

import com.kuainiu.qt.auth.bean.User;
import lombok.Data;

/**
 * @author chengqiang
 * @Classname UserInfoResponse
 * @Description TODO
 * @Created by chengqiang
 * @Date 2019/9/11 11:04 AM
 */
@Data
public class UserInfoResponse extends BaseResponse {
    private User data;
}
