package com.kuainiu.qt.admin.response;

import com.kuainiu.qt.admin.bean.StkTransListFacadeBean;
import lombok.Data;

@Data
public class StkTransListQryResponse extends BaseQtAdminResponse {
    private StkTransListFacadeBean data;
}
