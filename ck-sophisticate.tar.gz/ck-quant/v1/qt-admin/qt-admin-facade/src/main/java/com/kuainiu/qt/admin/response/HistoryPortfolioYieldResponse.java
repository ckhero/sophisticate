package com.kuainiu.qt.admin.response;

import com.kuainiu.qt.admin.bean.HistoryPortfolioYieldQryFacadeBean;
import lombok.Data;

import java.util.List;

@Data
public class HistoryPortfolioYieldResponse extends BaseQtAdminResponse {
    List<HistoryPortfolioYieldQryFacadeBean> data;
}
