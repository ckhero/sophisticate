package com.kuainiu.qt.admin.bean;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class PortfolioYieldQryFacadeBean {
    private Date timestamp;
    private BigDecimal realtimeReturns;
    private BigDecimal baseRealtimeReturns;
}
