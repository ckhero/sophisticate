package com.kuainiu.qt.admin.bean;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-25
 * Time: 20:17
 */
@Data
public class StkOrderCommitFacadeBean extends BaseFacadeBean {
    private String frontOrderId;

    private String qtOrderId;
}
