package com.kuainiu.qt.admin.request;

import lombok.Data;

@Data
public class PortfolioInfoQryRequest extends BaseQtAdminRequest {
    private String portfolioCode;
    private String strategyCode;
}
