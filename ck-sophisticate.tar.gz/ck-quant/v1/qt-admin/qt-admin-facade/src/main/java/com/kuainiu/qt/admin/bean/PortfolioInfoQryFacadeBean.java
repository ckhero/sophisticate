package com.kuainiu.qt.admin.bean;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
public class PortfolioInfoQryFacadeBean extends BaseFacadeBean{

    /** 累计收益 */
    private BigDecimal totalReturns;

    /** 当日盈亏 */
    private BigDecimal realtimeReturns;

    /** 剩余资金 */
    private BigDecimal cash;

    /** 仓位市值 */
    private BigDecimal marketValue;

    /** 当日盈亏金额 */
    private BigDecimal dailyPnl;

    /** 累计盈亏金额 */
    private BigDecimal pnl;

    /** 总权益 */
    private BigDecimal totalFund;

    /** 累计年化收益率 */
    private BigDecimal annualizedReturns;

    /** 非系统性风险 */
    private BigDecimal alpha;

    /** 系统性风险 */
    private BigDecimal beta;

    /** 单位总风险产生的超额报酬 */
    private BigDecimal sharpeRatio;

    /** 单位超额风险带来的超额收益 */
    private BigDecimal informationRatio;

    private List<FuturesPositionQryFacadeBean> futuresPositions;

    private List<StkPositionQryFacadeBean> stkPositions;

    /** 策略类型 */
    private String strategyName;

    /** 策略ID */
    private String strategyID;

    /** 策略本金 */
    private BigDecimal units;

    /** 开始时间 */
    private Date startDate;
}
