package com.kuainiu.qt.admin.facade;

import com.kuainiu.qt.admin.request.HistoryPortfolioYieldRequest;
import com.kuainiu.qt.admin.request.PortfolioYieldRequest;
import com.kuainiu.qt.admin.response.HistoryPortfolioYieldResponse;
import com.kuainiu.qt.admin.response.PortfolioYieldResponse;

public interface LiveChartFacade {
    PortfolioYieldResponse qryPortfolio(PortfolioYieldRequest request);

    HistoryPortfolioYieldResponse qryHistoryPortfolio(HistoryPortfolioYieldRequest request);
}
