package com.kuainiu.qt.admin.web.controller;


import com.kuainiu.qt.admin.facade.PortfolioInfoQryFacade;
import com.kuainiu.qt.admin.request.FuturesTransListQryRequest;
import com.kuainiu.qt.admin.request.PortfolioInfoQryRequest;
import com.kuainiu.qt.admin.request.StkTransListQryRequest;
import com.kuainiu.qt.admin.response.FuturesTransListQryResponse;
import com.kuainiu.qt.admin.response.PortfolioInfoQryResponse;
import com.kuainiu.qt.admin.response.StkTransListQryResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(value = "singleStrategy")
public class PortfolioController {

    @Autowired
    PortfolioInfoQryFacade portfolioInfoQryFacade;

    @PostMapping(value = "/qryPortfolioInfo", produces = "application/json;charset=UTF-8")
    public PortfolioInfoQryResponse qryPortfolioInfo(@RequestBody PortfolioInfoQryRequest request){
        return portfolioInfoQryFacade.qryPortfolioInfo(request);
    }

    @PostMapping(value = "/getStkTransList", produces = "application/json;charset=UTF-8")
    public StkTransListQryResponse getStkTransList(@RequestBody StkTransListQryRequest request){
        return portfolioInfoQryFacade.qryStkTransList(request);
    }

    @PostMapping(value = "/getFuturesTransList", produces = "application/json;charset=UTF-8")
    public FuturesTransListQryResponse getStkTransList(@RequestBody FuturesTransListQryRequest request){
        return portfolioInfoQryFacade.qryFuturesTransList(request);
    }

    @PostMapping(value = "/test", produces = "application/json;charset=UTF-8")
    public String test(){

        log.error("something failed");
        log.warn("something warning");
        log.info("log something");
        return "test success";
    }

}
