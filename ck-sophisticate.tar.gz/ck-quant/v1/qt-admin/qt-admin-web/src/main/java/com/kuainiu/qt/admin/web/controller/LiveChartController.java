package com.kuainiu.qt.admin.web.controller;

import com.kuainiu.qt.admin.facade.LiveChartFacade;
import com.kuainiu.qt.admin.request.HistoryPortfolioYieldRequest;
import com.kuainiu.qt.admin.request.PortfolioYieldRequest;
import com.kuainiu.qt.admin.response.HistoryPortfolioYieldResponse;
import com.kuainiu.qt.admin.response.PortfolioYieldResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("liveChart")
public class LiveChartController {

    @Autowired
    LiveChartFacade liveChartFacade;

    @PostMapping(value = "/qryPortfolioYieldCurve",produces = "application/json;charset=UTF-8")
    public PortfolioYieldResponse qryPortfolioYieldCurve(@RequestBody PortfolioYieldRequest request){
        return liveChartFacade.qryPortfolio(request);
    }

    @PostMapping(value = "/qryHistoryProfolioYieldCurve", produces = "application/json;charset=UTF-8")
    public HistoryPortfolioYieldResponse qryHistoryPortfolioYieldCurve(@RequestBody HistoryPortfolioYieldRequest request){
        return liveChartFacade.qryHistoryPortfolio(request);
    }
}
