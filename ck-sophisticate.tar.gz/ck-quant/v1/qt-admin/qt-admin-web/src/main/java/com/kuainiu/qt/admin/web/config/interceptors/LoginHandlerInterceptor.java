package com.kuainiu.qt.admin.web.config.interceptors;

import com.kuainiu.qt.auth.bean.User;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author chengqiang
 * @Classname LoginHandlerInterceptor
 * @Description TODO
 * @Created by chengqiang
 * @Date 2019-09-03 11:08
 */
@Component
public class LoginHandlerInterceptor implements HandlerInterceptor {

    @Resource
    private RedisTemplate<String, User> redisTemplate;

    @Value("${user.version:02}")
    private String userVersion;


    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String userToken = request.getHeader("token");
        if (userToken == null) {
            request.setAttribute("msg", "Have no permission, please login.");
            request.getRequestDispatcher("/passport/notlogin").forward(request, response);
            return false;
        }
        User user = (User) redisTemplate.opsForValue().get(userToken + userVersion);
        if (user == null) {
            request.setAttribute("msg", "Have no permission, please login.");
            request.getRequestDispatcher("/passport/notlogin").forward(request, response);
            return false;
        } else {
            if (!"VALID".equals(user.getStatus())) {
                request.setAttribute("msg", "Have not Authorized, please contact with administrator.");
                request.getRequestDispatcher("/passport/unauthorized").forward(request, response);
                return false;
            }
            return true;
        }
    }
}
