package com.kuainiu.qt.admin.web;

import com.alibaba.nacos.spring.context.annotation.config.NacosPropertySource;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/2
 * Time: 2:19 PM
 */
@SpringBootApplication(scanBasePackages = {"com.kuainiu.qt.admin", "com.kuainiu.qt.auth"})
@NacosPropertySource(dataId = "com.kuainiu.qt-admin.properties", groupId = "application", autoRefreshed = true)
@NacosPropertySource(dataId = "com.kuainiu.qt-admin.properties", groupId = "bizProvider", autoRefreshed = true)
@EnableRedisHttpSession
@ServletComponentScan
public class QtAdminWebApplication {
    public static void main(String[] args) {
        SpringApplication.run(QtAdminWebApplication.class, args);
    }
}
