package com.kuainiu.qt.admin.web.controller;

import com.kuainiu.qt.admin.facade.StkTradeFacade;
import com.kuainiu.qt.admin.request.StkOrderCommitRequest;
import com.kuainiu.qt.admin.response.StkOrderCommitResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-25
 * Time: 15:01
 */
@RestController
@RequestMapping("stkTrade")
@Slf4j
public class StkTradeController {

    @Autowired
    StkTradeFacade stkTradeFacade;

    @PostMapping(value = "/stkOrderCommit", produces = "application/json;charset=UTF-8")
    public StkOrderCommitResponse stkOrderCommit(@RequestBody StkOrderCommitRequest request){
        return stkTradeFacade.stkOrderCommit(request);
    }

}
