package com.kuainiu.qt.admin.web.controller;

import com.kuainiu.qt.admin.biz.LoginBiz;
import com.kuainiu.qt.admin.biz.UserBiz;
import com.kuainiu.qt.admin.response.LoginResponse;
import com.kuainiu.qt.admin.response.UserInfoResponse;
import com.kuainiu.qt.auth.bean.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author user
 */
@RestController
@RequestMapping("/passport")
@Slf4j
@EnableAutoConfiguration
public class AuthenticationController {

    @Autowired
    private UserBiz userBiz;

    @Autowired
    private LoginBiz loginBiz;

    @Value("${user.version:02}")
    private String userVersion;

    @Resource
    private RedisTemplate<String, User> redisTemplate;

    @GetMapping(value = "/callback", produces = "application/json;charset=UTF-8")
    public UserInfoResponse callBack(HttpServletRequest request, HttpServletResponse response, @RequestParam("code") String code) {
        log.info("Temp authentication code: {}", code);
        String userToken = request.getHeader("token");
        String uuid = userBiz.getUUID(code);
        User user = redisTemplate.opsForValue().get(uuid + userVersion);
        try {
            response.sendRedirect(userBiz.getFrontEndRedirectUri() + uuid);
        } catch (IOException e) {
            log.error("用户登录转发前台失败：{}", e);
        }
        UserInfoResponse userInfoResponse = userBiz.loginSuccess(user);
        return userInfoResponse;
    }

    @RequestMapping(value = "/unauthorized", produces = "application/json;charset=UTF-8")
    public Object unauthorized(HttpServletRequest request, HttpServletResponse response) {
        String userToken = request.getHeader("token");
        if (userToken == null) {
            return loginBiz.notLoginStatus();
        }
        User user = (User) redisTemplate.opsForValue().get(userToken + userVersion);
        if (user == null) {
            return loginBiz.notLoginStatus();
        }
        User userdata = userBiz.getUserById(user.getId());
        if ("VALID".equalsIgnoreCase(userdata.getStatus())) {
            userBiz.saveUserInfoToCache(userToken, userdata);
            return userBiz.loginSuccess(userdata);
        }
        log.info("User unauthorized.");
        return loginBiz.unauthorizedUser();
    }

    @RequestMapping(value = "/notlogin", produces = "application/json;charset=UTF-8")
    public LoginResponse notlogin(HttpServletRequest request, HttpServletResponse response) {
        log.info("User not login.");
        return loginBiz.notLoginStatus();
    }

    @RequestMapping(value = "/login", produces = "application/json;charset=UTF-8")
    public LoginResponse login(HttpServletRequest request, HttpServletResponse response) {
        log.info("Start to switch to QR code page.");
        return loginBiz.getEeWeChatQrUrl();
    }

    @PostMapping(value = "/getUserInfo", produces = "application/json;charset=UTF-8")
    public Object getUserInfo(HttpServletRequest request, HttpServletResponse response) {
        String userToken = request.getHeader("token");
        if (userToken == null) {
            return loginBiz.notLoginStatus();
        }
        log.info("Get user info for {}", userToken);
        User user = (User) redisTemplate.opsForValue().get(userToken + userVersion);
        if (user == null) {
            return loginBiz.notLoginStatus();
        }
        log.info("User info: {}", user.toString());
        return userBiz.loginSuccess(user);
    }
}
