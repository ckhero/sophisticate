package com.kuainiu.qt.admin.common.code;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/2
 * Time: 2:51 PM
 */
public enum Demo {
}
