package com.kuainiu.qt.admin.service.http.request;

import lombok.Data;

@Data
public class BaseQtAdminHttpRequest extends BaseHttpRequest {
}
