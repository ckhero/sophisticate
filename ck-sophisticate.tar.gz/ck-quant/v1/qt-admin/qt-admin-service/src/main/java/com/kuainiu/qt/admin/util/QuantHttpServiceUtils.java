package com.kuainiu.qt.admin.util;

import com.kuainiu.qt.admin.service.bean.quant.*;
import com.kuainiu.qt.admin.service.http.response.QuantRMQryResponse;
import com.kuainiu.qt.admin.service.http.response.QuantTQryResponse;
import com.kuainiu.qt.admin.common.util.BeanMapUtils;
import com.kuainiu.qt.admin.service.bean.quant.*;
import com.kuainiu.qt.admin.service.http.request.QuantRMQryRequest;
import com.kuainiu.qt.admin.service.http.request.QuantTQryRequest;
import com.kuainiu.qt.admin.service.http.response.*;

public class QuantHttpServiceUtils {
    public static QuantRMQryRequest buildRMQryRequest(QuantRMReqSerBean reqSerBean) {
        QuantRMQryRequest request = new QuantRMQryRequest();
        BeanMapUtils.map(reqSerBean, request);
        return request;
    }

    public static QuantTQryRequest buildTQryRequest(QuantTReqSerBean reqSerBean) {
        QuantTQryRequest request = new QuantTQryRequest();
        BeanMapUtils.map(reqSerBean, request);
        request.setPortfolio_key(reqSerBean.getPortfolioKey());
        request.setStrategy_key(reqSerBean.getStrategyCode());
        return request;
    }

    public static QuantRMSerBean buildRMQrySerBean(QuantRMQryResponse rmQryResponse) {
        QuantRMSerBean serBean = new QuantRMSerBean();
        RMSerBean rmSerBean = new RMSerBean();
        RmBean data = rmQryResponse.getData();
        if(data == null) {
            return serBean;
        }
        BeanMapUtils.map(data, rmSerBean);
        serBean.setData(rmSerBean);
        return serBean;
    }

    public static QuantTSerBean buildTQrySerBean(QuantTQryResponse response) {
        QuantTSerBean serBean = new QuantTSerBean();
        BeanMapUtils.map(response, serBean);
        return serBean;
    }
}
