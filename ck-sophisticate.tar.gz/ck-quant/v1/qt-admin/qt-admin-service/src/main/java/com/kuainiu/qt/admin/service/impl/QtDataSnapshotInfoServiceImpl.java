package com.kuainiu.qt.admin.service.impl;

import com.kuainiu.qt.admin.service.QtDataSnapshotInfoService;
import com.kuainiu.qt.admin.service.bean.trans.PortfolioInfoReqSerBean;
import com.kuainiu.qt.admin.service.bean.trans.PortfolioInfoSerBean;
import com.kuainiu.qt.admin.util.PortfolioServiceUtils;
import com.kuainiu.qt.data.facade.QtDataSnapshotPortfolioFacade;
import com.kuainiu.qt.data.facade.request.PortfolioQryRequest;
import com.kuainiu.qt.data.facade.response.PortfolioQryResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.Reference;
import org.apache.dubbo.rpc.RpcException;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class QtDataSnapshotInfoServiceImpl implements QtDataSnapshotInfoService {

    @Reference
    QtDataSnapshotPortfolioFacade qtDataSnapshotPortfolioFacade;

    @Override
    public PortfolioInfoSerBean qryPortfolioInfo(PortfolioInfoReqSerBean reqSerBean) {
        PortfolioQryRequest request = PortfolioServiceUtils.buildPortfolioInfoQryRequest(reqSerBean);
        log.info("qry portfolio info request : " + request);
        PortfolioQryResponse response = new PortfolioQryResponse();
        try {
            request.setRealTimeCalc(false);
            response = qtDataSnapshotPortfolioFacade.qryPortfolio(request);
            log.info("qry portfolio info response : " + response);
        } catch (RpcException e){
            log.error("data qry portfolio info fail rpc", e);
        } catch (Exception e){
            log.error("data fail", e);
        }
        return PortfolioServiceUtils.buildPortfolioInfoResSerBean(response);
    }
}
