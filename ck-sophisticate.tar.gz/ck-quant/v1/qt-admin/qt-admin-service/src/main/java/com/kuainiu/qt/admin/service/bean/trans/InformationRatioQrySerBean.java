package com.kuainiu.qt.admin.service.bean.trans;

import com.kuainiu.qt.admin.service.bean.BaseQtAdminSerBean;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class InformationRatioQrySerBean extends BaseQtAdminSerBean {
    private BigDecimal informationRatio;
}
