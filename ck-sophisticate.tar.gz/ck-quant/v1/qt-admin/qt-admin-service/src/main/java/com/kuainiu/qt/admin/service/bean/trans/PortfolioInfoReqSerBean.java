package com.kuainiu.qt.admin.service.bean.trans;

import com.kuainiu.qt.admin.service.bean.BaseQtAdminReqSerBean;
import lombok.Data;

import java.util.Date;

@Data
public class PortfolioInfoReqSerBean extends BaseQtAdminReqSerBean {
    private String portfolioCode;
    private Date datetime;
    private String portfolioKey;
    private String strategyCode;
    private Date startBelongTime;
    private Date endBelongTime;
    private Integer pageNo;
    private Integer pageSize;
}
