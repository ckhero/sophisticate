package com.kuainiu.qt.admin.service.http.impl;

import com.kuainiu.qt.admin.service.http.request.QuantRMQryRequest;
import com.kuainiu.qt.admin.service.http.response.QuantRMQryResponse;
import com.kuainiu.qt.admin.service.http.response.QuantTQryResponse;
import com.kuainiu.qt.admin.service.http.response.RmBean;
import com.kuainiu.qt.admin.service.http.MonitorHtttpClient;
import com.kuainiu.qt.admin.service.http.QuantHttpService;
import com.kuainiu.qt.admin.service.http.bean.HttpSerBean;
import com.kuainiu.qt.admin.service.http.request.QuantTQryRequest;
import com.kuainiu.qt.admin.service.http.response.*;
import com.kuainiu.qt.admin.service.http.util.HttpSerBeanUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Service
@Slf4j
public class QuantHttpServiceImpl implements QuantHttpService {
    @Value("${domain.aidc}")
    private String domain;

    @Override
    public QuantRMQryResponse qryRM(QuantRMQryRequest request) {
        String uri = "data/mtk/stock/hs300/rm";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = request.getDatetime();
        String sdfDate = sdf.format(date);
        try {
            request.setDatetime(sdf.parse(sdfDate));
            log.info("qry rm http request : " + request);
        } catch (ParseException e) {
            log.error("rm parse error", e);
        }
        HttpSerBean httpSerBean = HttpSerBeanUtils.buildHttpSerBean(request, QuantRMQryResponse.class, domain, uri);
        QuantRMQryResponse response = new QuantRMQryResponse();
        try {
            response = (QuantRMQryResponse) MonitorHtttpClient.post(httpSerBean);
            if(!"0".equals(response.getCode())){
                log.error("qry rm response error : "+ response);
                response.setData(new RmBean());
            }
        } catch (ClassCastException e){
            log.error("qry quant rm response error", e);
        } catch (Exception e){
            log.error("qry quant rm response error (may be quant db error) : ", e);
        }
        log.info("qry rm http response : " + response);
        return response;
    }

    @Override
    public QuantTQryResponse qryT(QuantTQryRequest tQryRequest) {
        log.info("qry rm http request : " + tQryRequest);
        String uri = "common/strategyExecutionCount";
        HttpSerBean httpSerBean = HttpSerBeanUtils.buildHttpSerBean(tQryRequest, QuantTQryResponse.class, domain, uri);
        QuantTQryResponse response = new QuantTQryResponse();
        try{
            response = (QuantTQryResponse) MonitorHtttpClient.post(httpSerBean);
        } catch (ClassCastException e){
            log.error("qry quant t response error", e);
        } catch (Exception e){
            log.error("qry quant rm response error (may be quant db error) : ", e);
        }
        log.info("qry t http response: " + response);
        return response;
    }
}
