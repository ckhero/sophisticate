package com.kuainiu.qt.admin.service.bean.quant;

import com.kuainiu.qt.admin.service.bean.BaseQtAdminReqSerBean;
import lombok.Data;

import java.util.Date;

@Data
public class QuantRMReqSerBean extends BaseQtAdminReqSerBean {
    private Date datetime;
}
