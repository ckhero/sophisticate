package com.kuainiu.qt.admin.service.bean.auth;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-17
 * Time: 18:58
 */
public class LoginUserQrySerBean {
}
