package com.kuainiu.qt.admin.service.bean.trans;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class FuturesTransBean {
    private String qtOrderId;
    private String qtTransId;
    private String channelTransId;
    private String assetNo;
    private Integer transQty;
    private BigDecimal transPrice;
    private BigDecimal transCost;
    private String submitStatus;
    private String status;
    private Date transTime;
    private String transSide;
    private String futuresType;
    //期货
    private String positionEffect;
}
