package com.kuainiu.qt.admin.service.http.response;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class QuantTQryResponse extends BaseQtAdminHttpResponse {
    private BigDecimal data;
}
