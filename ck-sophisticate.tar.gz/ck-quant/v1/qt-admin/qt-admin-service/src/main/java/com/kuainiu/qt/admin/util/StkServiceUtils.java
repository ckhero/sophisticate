package com.kuainiu.qt.admin.util;

import com.kuainiu.qt.admin.common.util.BeanMapUtils;
import com.kuainiu.qt.admin.service.bean.trans.StkTradeReqSerBean;
import com.kuainiu.qt.admin.service.bean.trans.StkTradeSerBean;
import com.kuainiu.qt.core.facade.request.StkOrderCommitRequest;
import com.kuainiu.qt.core.facade.response.StkOrderCommitResponse;
import lombok.extern.slf4j.Slf4j;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-25
 * Time: 15:46
 */
@Slf4j
public class StkServiceUtils {
    public static StkOrderCommitRequest buildStkOrderCommitRequest(StkTradeReqSerBean reqSerBean) {
        StkOrderCommitRequest request = new StkOrderCommitRequest();
        BeanMapUtils.map(reqSerBean, request);
        return request;
    }


    public static StkTradeSerBean buildStkTradeSerBean(StkOrderCommitResponse response) {
        StkTradeSerBean serBean = new StkTradeSerBean();
        serBean.setFrontOrderId(response.getData().getFrontOrderId());
        serBean.setQtOrderId(response.getData().getQtOrderId());
        return serBean;
    }
}
