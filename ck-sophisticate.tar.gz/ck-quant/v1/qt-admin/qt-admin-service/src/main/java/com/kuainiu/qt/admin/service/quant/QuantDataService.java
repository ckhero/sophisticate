package com.kuainiu.qt.admin.service.quant;

import com.kuainiu.qt.admin.service.bean.quant.QuantRMReqSerBean;
import com.kuainiu.qt.admin.service.bean.quant.QuantRMSerBean;
import com.kuainiu.qt.admin.service.bean.quant.QuantTReqSerBean;
import com.kuainiu.qt.admin.service.bean.quant.QuantTSerBean;
import com.kuainiu.qt.admin.service.bean.quant.*;

public interface QuantDataService {
    QuantRMSerBean qryRM(QuantRMReqSerBean reqSerBean);

    QuantTSerBean qryT(QuantTReqSerBean reqSerBean);
}
