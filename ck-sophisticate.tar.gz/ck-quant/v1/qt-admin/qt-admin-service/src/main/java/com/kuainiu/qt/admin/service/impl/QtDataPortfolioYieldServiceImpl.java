package com.kuainiu.qt.admin.service.impl;

import com.kuainiu.qt.admin.service.QtDataPortfolioYieldService;
import com.kuainiu.qt.admin.service.bean.trans.HistoryPortfolioYieldSerBean;
import com.kuainiu.qt.admin.service.bean.trans.PortfolioYieldReqSerBean;
import com.kuainiu.qt.admin.util.PortfolioServiceUtils;
import com.kuainiu.qt.admin.service.bean.trans.HistoryPortfolioYieldReqSerBean;
import com.kuainiu.qt.admin.service.bean.trans.PortfolioYieldSerBean;
import com.kuainiu.qt.data.facade.QtDataSnapshotPortfolioFacade;
import com.kuainiu.qt.data.facade.request.PortfolioLastRecordPerDayRequest;
import com.kuainiu.qt.data.facade.response.SnapshotPortfolioListResponse;
import com.kuainiu.qt.data.facade.request.PortfolioYieldRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.Reference;
import org.apache.dubbo.rpc.RpcException;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class QtDataPortfolioYieldServiceImpl implements QtDataPortfolioYieldService {
    @Reference
    QtDataSnapshotPortfolioFacade qtDataSnapshotPortfolioFacade;

    @Override
    public PortfolioYieldSerBean qryPortfolioYield(PortfolioYieldReqSerBean reqSerBean) {
        PortfolioYieldRequest request = PortfolioServiceUtils.buildPortfolioYieldRequest(reqSerBean);
        log.info("qry portfolio yield request : " + request);
        SnapshotPortfolioListResponse response = null;
        try {
            response = qtDataSnapshotPortfolioFacade.qrySnapshotPortfolioList(request);
            log.info("qry portfolio yield response : " + response);
        } catch (RpcException e){
            log.error("qry trans fail", e);
        } catch (Exception e){
            log.error("trans fail", e);
        }
        return PortfolioServiceUtils.buildPortfolioYieldSerBean(response);
    }

    @Override
    public HistoryPortfolioYieldSerBean qryHistoryPortfolioYield(HistoryPortfolioYieldReqSerBean reqSerBean) {
        PortfolioLastRecordPerDayRequest request = PortfolioServiceUtils.buildHistoryPortfolioYieldrequest(reqSerBean);
        log.info("qry history portfolio yield request :" + request);
        SnapshotPortfolioListResponse response = null;
        try{
            response = qtDataSnapshotPortfolioFacade.qryLastRecordPerDay(request);
            log.info("qry history portfolio yield response : " + response);
        }catch (RpcException e){
            log.error("qry trans fail", e);
        } catch (Exception e){
            log.error("trans fail", e);
        }
        return PortfolioServiceUtils.buildHistoryPortfolioYieldSerBean(response);
    }
}
