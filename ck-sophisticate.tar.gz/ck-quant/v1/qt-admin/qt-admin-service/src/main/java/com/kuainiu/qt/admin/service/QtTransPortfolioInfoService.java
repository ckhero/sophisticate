package com.kuainiu.qt.admin.service;

import com.kuainiu.qt.admin.service.bean.trans.*;
import com.kuainiu.qt.admin.service.bean.trans.*;

public interface QtTransPortfolioInfoService {

    StkTransListSerBean qryStkTransList(StkTransListReqSerBean stkReqSerBean);

    FuturesTransListSerBean qryFuturesTransList(FuturesTransListReqSerBean futuresTransListReqSerBean);
}
