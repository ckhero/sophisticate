package com.kuainiu.qt.admin.service;

import com.kuainiu.qt.admin.service.bean.trans.PortfolioInfoReqSerBean;
import com.kuainiu.qt.admin.service.bean.trans.PortfolioInfoSerBean;

public interface QtDataSnapshotInfoService {
    PortfolioInfoSerBean qryPortfolioInfo(PortfolioInfoReqSerBean reqSerBean);
}
