package com.kuainiu.qt.admin.service.bean.quant;

import com.kuainiu.qt.admin.service.bean.BaseQtAdminReqSerBean;
import lombok.Data;

@Data
public class QuantTReqSerBean extends BaseQtAdminReqSerBean {
    private String portfolioKey;
    private String strategyCode;
}
