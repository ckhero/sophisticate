package com.kuainiu.qt.admin.service.bean.trans;

import com.kuainiu.qt.admin.service.bean.BaseQtAdminSerBean;
import lombok.Data;

import java.util.List;

@Data
public class StkTransListSerBean extends BaseQtAdminSerBean {
    private Integer total;
    private List<StkTransBean> transList;
}
