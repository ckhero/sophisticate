package com.kuainiu.qt.admin.service.quant.impl;

import com.kuainiu.qt.admin.service.bean.quant.QuantRMReqSerBean;
import com.kuainiu.qt.admin.service.bean.quant.QuantRMSerBean;
import com.kuainiu.qt.admin.service.bean.quant.QuantTReqSerBean;
import com.kuainiu.qt.admin.service.bean.quant.QuantTSerBean;
import com.kuainiu.qt.admin.util.QuantHttpServiceUtils;
import com.kuainiu.qt.admin.service.http.QuantHttpService;
import com.kuainiu.qt.admin.service.http.request.QuantRMQryRequest;
import com.kuainiu.qt.admin.service.http.request.QuantTQryRequest;
import com.kuainiu.qt.admin.service.http.response.QuantRMQryResponse;
import com.kuainiu.qt.admin.service.http.response.QuantTQryResponse;
import com.kuainiu.qt.admin.service.quant.QuantDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class QuantDataServiceImpl implements QuantDataService {
    @Autowired
    QuantHttpService quantHttpService;

    @Override
    public QuantRMSerBean qryRM(QuantRMReqSerBean reqSerBean) {
        QuantRMQryRequest quantRmQryRequest = QuantHttpServiceUtils.buildRMQryRequest(reqSerBean);
        QuantRMQryResponse rmQryResponse = quantHttpService.qryRM(quantRmQryRequest);
        return QuantHttpServiceUtils.buildRMQrySerBean(rmQryResponse);
    }

    @Override
    public QuantTSerBean qryT(QuantTReqSerBean reqSerBean){
        QuantTQryRequest request = QuantHttpServiceUtils.buildTQryRequest(reqSerBean);
        QuantTQryResponse response = quantHttpService.qryT(request);
        return QuantHttpServiceUtils.buildTQrySerBean(response);
    }
}
