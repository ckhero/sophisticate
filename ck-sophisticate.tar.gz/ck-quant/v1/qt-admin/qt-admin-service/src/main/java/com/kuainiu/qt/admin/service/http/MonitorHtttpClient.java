package com.kuainiu.qt.admin.service.http;


import com.alibaba.fastjson.JSON;
import com.kuainiu.qt.admin.service.http.bean.HttpSerBean;
import com.kuainiu.qt.admin.service.http.response.BaseQtAdminHttpResponse;
import com.kuainiu.qt.admin.code.QtAdminRspCode;
import com.kuainiu.qt.admin.common.code.LogFormatCode;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.Objects;

@Slf4j
public class MonitorHtttpClient {
    private static CloseableHttpClient httpClient = HttpClients.createDefault();

    /** 连接超时时间 */
    private static final int CONNECTION_TIMEOUT = 5000;

    /** 请求超时时间 */
    private static final int CONNECTION_REQUEST_TIMEOUT = 5000;

    /** 数据读取等待超时 */
    private static final int SOCKET_TIMEOUT = 10000;

    /** 默认编码 */
    private static final String DEFAULT_ENCODING = "UTF-8";

    /** 默认编码 */
    private static final String HEAD_CONTENT_TYPE  = "Content-Type";

    /** 默认编码 */
    private static final String CONTENT_TYPE_TEXT = "application/json";

    public static BaseQtAdminHttpResponse post(HttpSerBean httpSerBean) {
        String jsonParams = JSON.toJSONString(httpSerBean.getRequest());
        log.info(LogFormatCode.HTTP_REQUEST.getFormat(), httpSerBean.getUrl(), jsonParams);
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(CONNECTION_TIMEOUT)
                .setConnectionRequestTimeout(CONNECTION_REQUEST_TIMEOUT)
                .setSocketTimeout(SOCKET_TIMEOUT)
                .setRedirectsEnabled(true)
                .build();

        HttpPost httpPost = new HttpPost(httpSerBean.getUrl());
        httpPost.setConfig(requestConfig);
        httpPost.setHeader(HEAD_CONTENT_TYPE, CONTENT_TYPE_TEXT);
        Class responseClass = httpSerBean.getResponseClass();
        if (Objects.isNull(responseClass)) {
            log.error("http responseClass is null");
        }
        BaseQtAdminHttpResponse response = new BaseQtAdminHttpResponse();
        try {
            httpPost.setEntity(new StringEntity(jsonParams, ContentType.create(CONTENT_TYPE_TEXT, DEFAULT_ENCODING)));
            HttpResponse result = httpClient.execute(httpPost);
            String jsonReponse = EntityUtils.toString(result.getEntity());
            response = (BaseQtAdminHttpResponse) JSON.parseObject(jsonReponse, responseClass);
            log.info(LogFormatCode.HTTP_RESPONSE.getFormat(), httpSerBean.getUrl(), jsonReponse);
        } catch (HttpHostConnectException e) {
            log.error(LogFormatCode.HTTP_ERROR.getFormat(), QtAdminRspCode.ERR_HTTP_CONNECT.getMsg(), httpSerBean.getUrl(),"http host connection error");
        } catch (ClientProtocolException e) {
            log.error(LogFormatCode.HTTP_ERROR.getFormat(), QtAdminRspCode.ERR_HTTP_CONNECT.getMsg(), httpSerBean.getUrl(),"http client protocol error");
        } catch (IOException e) {
            log.error(LogFormatCode.HTTP_ERROR.getFormat(), QtAdminRspCode.ERR_HTTP_CONNECT.getMsg(), httpSerBean.getUrl(),"http IO error");
        }
        return response;
    }
}
