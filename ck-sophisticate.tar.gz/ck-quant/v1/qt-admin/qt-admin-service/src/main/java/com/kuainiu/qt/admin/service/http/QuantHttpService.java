package com.kuainiu.qt.admin.service.http;

import com.kuainiu.qt.admin.service.http.request.QuantRMQryRequest;
import com.kuainiu.qt.admin.service.http.request.QuantTQryRequest;
import com.kuainiu.qt.admin.service.http.response.QuantRMQryResponse;
import com.kuainiu.qt.admin.service.http.response.QuantTQryResponse;

public interface QuantHttpService {
    QuantRMQryResponse qryRM(QuantRMQryRequest request);

    QuantTQryResponse qryT(QuantTQryRequest tQryRequest);
}
