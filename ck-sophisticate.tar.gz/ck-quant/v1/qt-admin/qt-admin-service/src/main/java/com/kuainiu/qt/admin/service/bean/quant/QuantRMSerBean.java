package com.kuainiu.qt.admin.service.bean.quant;

import com.kuainiu.qt.admin.service.bean.BaseQtAdminSerBean;
import lombok.Data;

@Data
public class QuantRMSerBean extends BaseQtAdminSerBean {
    private RMSerBean data;
}
