package com.kuainiu.qt.admin.util;

import com.kuainiu.qt.admin.common.util.CalcUtils;
import com.kuainiu.qt.admin.service.bean.trans.*;
import com.kuainiu.qt.admin.common.util.BeanMapUtils;
import com.kuainiu.qt.data.facade.bean.PortfolioInfoFacadeBean;
import com.kuainiu.qt.data.facade.request.*;
import com.kuainiu.qt.data.facade.request.PortfolioQryRequest;
import com.kuainiu.qt.data.facade.response.InfoRatioResponse;
import com.kuainiu.qt.data.facade.response.SnapshotPortfolioListResponse;
import com.kuainiu.qt.data.facade.bean.SnapshotPortfolioFacadeBean;
import com.kuainiu.qt.data.facade.response.StdResponse;
import com.kuainiu.qt.trans.facade.request.*;
import com.kuainiu.qt.trans.facade.request.futures.QtTransFuturesTransQryRequest;
import com.kuainiu.qt.trans.facade.response.*;
import com.kuainiu.qt.trans.facade.response.futures.QtTransFuturesTransQryResponse;
import com.kuainiu.qt.data.facade.response.PortfolioQryResponse;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class PortfolioServiceUtils {
    public static PortfolioQryRequest buildPortfolioInfoQryRequest(PortfolioInfoReqSerBean reqSerBean){
        PortfolioQryRequest request = new PortfolioQryRequest();
        BeanMapUtils.map(reqSerBean, request);
        return request;
    }

    public static PortfolioInfoSerBean buildPortfolioInfoResSerBean(PortfolioQryResponse response){
        PortfolioInfoSerBean serBean = new PortfolioInfoSerBean();
        PortfolioInfoFacadeBean facadeBean = response.getData();
        BeanMapUtils.map(facadeBean, serBean);
        List<StkPositionSerBean> stkPositionSerBeanList = null;
        List<FuturesPositionSerBean> futuresPositionSerBeanList = null;
        try {
            stkPositionSerBeanList = BeanMapUtils.mapAsList(facadeBean.getStkPositionList(), StkPositionSerBean.class);
        } catch (InstantiationException e) {
            log.error("stk response list instantiation exception");
        } catch (IllegalAccessException e) {
            log.error("stk response list illegal access exception");
        }
        try {
            futuresPositionSerBeanList = BeanMapUtils.mapAsList(facadeBean.getFuturesPositionList(), FuturesPositionSerBean.class);
        } catch (InstantiationException e) {
            log.error("futures response list instantiation exception");
        } catch (IllegalAccessException e) {
            log.error("futures response list illegal access exception");
        }
        serBean.setStkPositions(stkPositionSerBeanList);
        serBean.setFuturesPositions(futuresPositionSerBeanList);

        return serBean;
    }

    //当日盈亏曲线
    public static PortfolioYieldRequest buildPortfolioYieldRequest(PortfolioYieldReqSerBean reqSerBean) {
        PortfolioYieldRequest request = new PortfolioYieldRequest();
        BeanMapUtils.map(reqSerBean, request);
        return request;
    }

    public static PortfolioYieldSerBean buildPortfolioYieldSerBean(SnapshotPortfolioListResponse response) {
        PortfolioYieldSerBean serBean = new PortfolioYieldSerBean();
        List<PortfolioYieldBean> data = new ArrayList<>();
        //将下一分钟的数据存入临时变量，如果rm或rp请求出现null或0，即沿用
        BigDecimal tempRM = BigDecimal.ZERO;
        BigDecimal tempRP = BigDecimal.ZERO;
        if(response != null) {
            for (int i = 0; i < response.getData().size(); i++) {
                PortfolioYieldBean bean = new PortfolioYieldBean();
                SnapshotPortfolioFacadeBean item = response.getData().get(i);
                bean.setTimestamp(item.getBelongTime());
                BigDecimal rm = item.getBaseRealtimeReturns();
                BigDecimal rp = item.getRealtimeReturns();
                if(CalcUtils.isZeroOrNull(rp)){
                    bean.setRealtimeReturns(tempRP);
                } else {
                    bean.setRealtimeReturns(rp.setScale(4, BigDecimal.ROUND_UP));
                }
                if(CalcUtils.isZeroOrNull(rm)){
                    bean.setBaseRealtimeReturns(tempRM);
                } else {
                    bean.setBaseRealtimeReturns(rm.setScale(4, BigDecimal.ROUND_UP));
                }
                data.add(bean);
                tempRM = bean.getBaseRealtimeReturns();
                tempRP = bean.getRealtimeReturns();
            }
        }
        serBean.setData(data);
        log.info("兼容null和0之后的: "+ serBean.toString());
        return serBean;
    }

    public static PortfolioLastRecordPerDayRequest buildHistoryPortfolioYieldrequest(HistoryPortfolioYieldReqSerBean reqSerBean) {
        PortfolioLastRecordPerDayRequest request = new PortfolioLastRecordPerDayRequest();
        BeanMapUtils.map(reqSerBean, request);
        return request;
    }

    public static HistoryPortfolioYieldSerBean buildHistoryPortfolioYieldSerBean(SnapshotPortfolioListResponse response) {
        HistoryPortfolioYieldSerBean serBean = new HistoryPortfolioYieldSerBean();
        List<HistoryPortfolioYieldBean> data = new ArrayList<>();
        //将下一分钟的数据存入临时变量，如果rm或rp请求出现null或0，即沿用
        BigDecimal tempRM = BigDecimal.ZERO;
        BigDecimal tempRP = BigDecimal.ZERO;
        if(response != null) {
            for (int i = 0; i < response.getData().size(); i++) {
                HistoryPortfolioYieldBean bean = new HistoryPortfolioYieldBean();
                SnapshotPortfolioFacadeBean item = response.getData().get(i);
                if(item.getBelongDate() == null){
                    log.info("history yield belongDate null" + item.toString());
                    continue;
                }
                BeanMapUtils.map(item, bean);
                bean.setTimestamp(item.getBelongDate());
                BigDecimal rm = item.getBaseRealtimeReturns();
                BigDecimal rp = item.getRealtimeReturns();
                if(rp == null || rp.stripTrailingZeros().equals(BigDecimal.ZERO)){
                    bean.setRealtimeReturns(tempRP);
                } else {
                    bean.setRealtimeReturns(rp.setScale(4, BigDecimal.ROUND_UP));
                }
                if(rm == null || rm.stripTrailingZeros().equals(BigDecimal.ZERO)){
                    bean.setBaseRealtimeReturns(tempRM);
                } else {
                    bean.setBaseRealtimeReturns(rm.setScale(4, BigDecimal.ROUND_UP));
                }
                data.add(bean);
                tempRM = bean.getBaseRealtimeReturns();
                tempRP = bean.getRealtimeReturns();
            }
        }
        serBean.setData(data);
        return serBean;
    }

    public static StdRequest buildPortfolioStdQryRequest(PortfolioInfoReqSerBean reqSerBean) {
        StdRequest request = new StdRequest();
        BeanMapUtils.map(reqSerBean, request);
        return request;
    }

    public static PortfolioStdQrySerBean buildPortfolioStdSerBean(StdResponse response) {
        PortfolioStdQrySerBean serBean = new PortfolioStdQrySerBean();
        BeanMapUtils.map(response, serBean);
        return serBean;
    }

    public static QtTransStkTransQryRequest buildStkTransListRequest(StkTransListReqSerBean stkReqSerBean) {
        QtTransStkTransQryRequest request = new QtTransStkTransQryRequest();
        BeanMapUtils.map(stkReqSerBean, request);
        return request;
    }

    public static StkTransListSerBean buildStkTransListSerBean(QtTransStkTransQryResponse stkResponse) {
        StkTransListSerBean serBean = new StkTransListSerBean();
        List<StkTransBean> list = new ArrayList<>();
        try {
            BeanMapUtils.map(stkResponse, serBean);
            list = BeanMapUtils.mapAsList(stkResponse.getTransList(), StkTransBean.class);
        } catch (InstantiationException e) {
            log.error("stk translist param instantiation error");
        } catch (IllegalAccessException e) {
            log.error("stk translist param illegal access error");
        }
        serBean.setTransList(list);
        return serBean;
    }

    public static QtTransFuturesTransQryRequest buildFuturesTransListRequest(FuturesTransListReqSerBean futuresTransListReqSerBean) {
        QtTransFuturesTransQryRequest request = new QtTransFuturesTransQryRequest();
        BeanMapUtils.map(futuresTransListReqSerBean, request);
        return request;
    }

    public static FuturesTransListSerBean buildFuturesTransListSerBean(QtTransFuturesTransQryResponse futuresResponse) {
        FuturesTransListSerBean serBean = new FuturesTransListSerBean();
        List<FuturesTransBean> list = new ArrayList<>();
        try {
            BeanMapUtils.map(futuresResponse, serBean);
            list = BeanMapUtils.mapAsList(futuresResponse.getTransList(), FuturesTransBean.class);
        } catch (InstantiationException e) {
            log.error("futures translist param instantiation error");
        } catch (IllegalAccessException e) {
            log.error("futures translist param illegal access error");
        }
        serBean.setTransList(list);
        return serBean;
    }

    public static InfoRatioRequest buildInformationRatioRequest(InformationRatioQryReqSerBean reqSerBean) {
        InfoRatioRequest request = new InfoRatioRequest();
        BeanMapUtils.map(reqSerBean, request);
        return request;
    }


    public static InformationRatioQrySerBean buildInformationRatioSerBean(InfoRatioResponse response) {
        InformationRatioQrySerBean serBean = new InformationRatioQrySerBean();
        BeanMapUtils.map(response, serBean);
        return serBean;
    }

}
