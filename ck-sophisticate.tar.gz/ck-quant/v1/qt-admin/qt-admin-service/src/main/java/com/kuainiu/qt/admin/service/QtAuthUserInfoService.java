package com.kuainiu.qt.admin.service;

import com.kuainiu.qt.admin.service.bean.auth.LoginUserQryReqSerBean;
import com.kuainiu.qt.admin.service.bean.auth.LoginUserQrySerBean;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-17
 * Time: 18:55
 */
public interface QtAuthUserInfoService {
    LoginUserQrySerBean qryLoginUser(LoginUserQryReqSerBean reqSerBean);
}
