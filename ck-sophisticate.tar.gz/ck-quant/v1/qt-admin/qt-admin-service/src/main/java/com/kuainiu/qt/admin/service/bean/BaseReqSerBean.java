package com.kuainiu.qt.admin.service.bean;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/2
 * Time: 2:27 PM
 */
@Data
public class BaseReqSerBean {
}
