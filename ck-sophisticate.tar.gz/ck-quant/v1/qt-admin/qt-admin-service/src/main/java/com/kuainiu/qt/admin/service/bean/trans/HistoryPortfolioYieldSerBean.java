package com.kuainiu.qt.admin.service.bean.trans;

import com.kuainiu.qt.admin.service.bean.BaseQtAdminSerBean;
import lombok.Data;

import java.util.List;

@Data
public class HistoryPortfolioYieldSerBean extends BaseQtAdminSerBean {
    List<HistoryPortfolioYieldBean> data;
}
