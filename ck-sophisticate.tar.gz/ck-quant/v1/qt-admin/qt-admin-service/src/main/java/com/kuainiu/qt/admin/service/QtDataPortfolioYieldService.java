package com.kuainiu.qt.admin.service;

import com.kuainiu.qt.admin.service.bean.trans.HistoryPortfolioYieldSerBean;
import com.kuainiu.qt.admin.service.bean.trans.PortfolioYieldReqSerBean;
import com.kuainiu.qt.admin.service.bean.trans.HistoryPortfolioYieldReqSerBean;
import com.kuainiu.qt.admin.service.bean.trans.PortfolioYieldSerBean;

public interface QtDataPortfolioYieldService {
    PortfolioYieldSerBean qryPortfolioYield(PortfolioYieldReqSerBean reqSerBean);

    HistoryPortfolioYieldSerBean qryHistoryPortfolioYield(HistoryPortfolioYieldReqSerBean reqSerBean);
}
