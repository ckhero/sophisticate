package com.kuainiu.qt.admin.service.http.request;

import lombok.Data;

import java.io.Serializable;

@Data
public class BaseHttpRequest implements Serializable {
}
