package com.kuainiu.qt.admin.service.impl;

import com.kuainiu.qt.admin.common.util.BeanMapUtils;
import com.kuainiu.qt.admin.service.QtAuthUserInfoService;
import com.kuainiu.qt.admin.service.bean.auth.LoginUserQryReqSerBean;
import com.kuainiu.qt.admin.service.bean.auth.LoginUserQrySerBean;
import com.kuainiu.qt.auth.facade.QtAuthUserLoginFacade;
import com.kuainiu.qt.auth.request.UserLoginInfoQryRequest;
import com.kuainiu.qt.auth.response.UserLoginInfoQryResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.stereotype.Service;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-17
 * Time: 18:56
 */
@Service
@Slf4j
public class QtAuthUserInfoServiceImpl implements QtAuthUserInfoService {
    @Reference
    QtAuthUserLoginFacade qtAuthUserLoginFacade;

    @Override
    public LoginUserQrySerBean qryLoginUser(LoginUserQryReqSerBean reqSerBean) {
        UserLoginInfoQryRequest request = new UserLoginInfoQryRequest();
        BeanMapUtils.map(reqSerBean, request);
        LoginUserQrySerBean response = new LoginUserQrySerBean();
        UserLoginInfoQryResponse rpcResponse = new UserLoginInfoQryResponse();
        try {
            log.info("qryLoginUser request:{}",request);
            rpcResponse = qtAuthUserLoginFacade.qryUserLoginInfo(request);
            log.info("qryLoginUser response:{}",rpcResponse);
        } catch (Exception e) {
            e.printStackTrace();
        }
        BeanMapUtils.map(rpcResponse, response);
        return null;
    }
}
