package com.kuainiu.qt.admin.service.bean.auth;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-17
 * Time: 18:59
 */
@Data
public class LoginUserQryReqSerBean {
    private String username;
}
