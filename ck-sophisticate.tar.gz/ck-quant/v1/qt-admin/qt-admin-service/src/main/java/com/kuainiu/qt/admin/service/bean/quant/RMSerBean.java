package com.kuainiu.qt.admin.service.bean.quant;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class RMSerBean {
    private Date timestamp;
    private BigDecimal data;
}
