package com.kuainiu.qt.admin.exception;

import com.kuainiu.qt.admin.code.QtAdminRspCode;
import com.kuainiu.qt.admin.common.util.CommonConstant;
import com.kuainiu.qt.admin.response.BaseQtAdminResponse;
import com.taobao.config.client.utils.StringUtils;

import java.text.MessageFormat;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/19
 * Time: 10:10 AM
 */
public class ServiceException extends Exception{
    private QtAdminRspCode qtAdminRspCode;

    private String code;

    private String msg;

    public ServiceException(QtAdminRspCode qtAdminRspCode){
        this.qtAdminRspCode = qtAdminRspCode;
        this.code = qtAdminRspCode.getCode();
        this.msg = qtAdminRspCode.getMsg();
    }

    public ServiceException(QtAdminRspCode qtAdminRspCode, Throwable t){
        super(t);
        this.qtAdminRspCode = qtAdminRspCode;
        this.code = qtAdminRspCode.getCode();
        this.msg = qtAdminRspCode.getMsg();
    }

    public ServiceException(QtAdminRspCode qtAdminRspCode, String msg, Throwable t){
        super(t);
        this.qtAdminRspCode = qtAdminRspCode;
        this.code = qtAdminRspCode.getCode();
        this.msg = qtAdminRspCode.getMsg();
        if (StringUtils.isNotBlank(msg)) {
            this.msg += CommonConstant.COMMA + msg;
        }
    }

    public ServiceException(QtAdminRspCode qtAdminRspCode, String msg){
        this.qtAdminRspCode = qtAdminRspCode;
        this.code = qtAdminRspCode.getCode();
        this.msg = qtAdminRspCode.getMsg();
        if (StringUtils.isNotBlank(msg)) {
            this.msg += CommonConstant.COMMA + msg;
        }
    }

    public ServiceException(String msg){
        this.qtAdminRspCode = QtAdminRspCode.ERR_SYS_ERROR;
        this.code = qtAdminRspCode.getCode();
        this.msg = msg;
    }

    public void setcode(String code){
        this.code = code;
    }

    public String getCode(){
        return code;
    }

    public String getMsg(){
        return msg;
    }

    public void setMsg(String msg){
        this.msg = msg;
    }

    public void exceptionToResponse(BaseQtAdminResponse baseQtAdminResponse){
        baseQtAdminResponse.setCode(this.getCode());
        baseQtAdminResponse.setMsg(this.getMsg());
    }

    public ServiceException(String pattern, Object... arguments){
        super(MessageFormat.format(pattern, arguments));
    }
}
