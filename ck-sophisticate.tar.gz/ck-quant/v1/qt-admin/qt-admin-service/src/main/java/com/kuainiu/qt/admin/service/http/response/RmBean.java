package com.kuainiu.qt.admin.service.http.response;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class RmBean {
    private Date timestamp;
    private BigDecimal data;
}
