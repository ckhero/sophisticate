package com.kuainiu.qt.admin.service.http.util;

import com.kuainiu.qt.admin.service.http.bean.HttpSerBean;
import com.kuainiu.qt.admin.service.http.request.BaseQtAdminHttpRequest;

public class HttpSerBeanUtils {
    public static HttpSerBean buildHttpSerBean(BaseQtAdminHttpRequest request, Class response, String domain, String uri) {
        HttpSerBean httpSerBean = new HttpSerBean();
        httpSerBean.setRequest(request);
        httpSerBean.setResponseClass(response);
        String url = domain + uri;
        httpSerBean.setUrl(url);
        httpSerBean.setDomain(domain);
        httpSerBean.setUri(uri);
        return httpSerBean;
    }
}
