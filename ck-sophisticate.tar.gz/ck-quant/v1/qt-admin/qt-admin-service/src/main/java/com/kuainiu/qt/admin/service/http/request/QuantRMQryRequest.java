package com.kuainiu.qt.admin.service.http.request;

import lombok.Data;

import java.util.Date;

@Data
public class QuantRMQryRequest extends BaseQtAdminHttpRequest {
    private Date datetime;
}
