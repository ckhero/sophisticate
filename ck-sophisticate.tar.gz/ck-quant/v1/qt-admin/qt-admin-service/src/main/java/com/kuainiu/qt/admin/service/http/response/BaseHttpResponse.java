package com.kuainiu.qt.admin.service.http.response;

import lombok.Data;

import java.io.Serializable;

@Data
public class BaseHttpResponse implements Serializable{
    private String code;
    private String msg;
}
