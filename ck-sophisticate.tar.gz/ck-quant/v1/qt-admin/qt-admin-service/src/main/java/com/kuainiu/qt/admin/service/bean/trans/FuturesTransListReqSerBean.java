package com.kuainiu.qt.admin.service.bean.trans;

import com.kuainiu.qt.admin.service.bean.BaseQtAdminReqSerBean;
import lombok.Data;

@Data
public class FuturesTransListReqSerBean extends BaseQtAdminReqSerBean {

    private String portfolioCode;

    private String strategyCode;
}
