package com.kuainiu.qt.admin.service.bean.quant;

import com.kuainiu.qt.admin.service.bean.BaseQtAdminSerBean;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class QuantTSerBean extends BaseQtAdminSerBean {
    private BigDecimal data;
}
