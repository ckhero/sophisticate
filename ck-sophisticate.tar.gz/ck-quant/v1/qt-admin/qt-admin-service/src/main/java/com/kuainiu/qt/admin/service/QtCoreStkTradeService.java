package com.kuainiu.qt.admin.service;

import com.kuainiu.qt.admin.exception.ServiceException;
import com.kuainiu.qt.admin.service.bean.trans.StkTradeReqSerBean;
import com.kuainiu.qt.admin.service.bean.trans.StkTradeSerBean;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-25
 * Time: 15:25
 */
public interface QtCoreStkTradeService {
    StkTradeSerBean stkOrderCommit(StkTradeReqSerBean reqSerBean) throws ServiceException;;
}
