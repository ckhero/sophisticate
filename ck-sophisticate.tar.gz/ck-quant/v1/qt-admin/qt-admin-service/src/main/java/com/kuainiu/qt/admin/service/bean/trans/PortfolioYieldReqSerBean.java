package com.kuainiu.qt.admin.service.bean.trans;

import com.kuainiu.qt.admin.service.bean.BaseQtAdminReqSerBean;
import lombok.Data;

import java.util.Date;

@Data
public class PortfolioYieldReqSerBean extends BaseQtAdminReqSerBean {
    private String portfolioCode;
    private Date startBelongTime;
    private Date endBelongTime;
}
