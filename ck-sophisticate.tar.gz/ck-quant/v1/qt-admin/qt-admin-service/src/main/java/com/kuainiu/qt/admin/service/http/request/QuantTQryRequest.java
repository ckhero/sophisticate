package com.kuainiu.qt.admin.service.http.request;

import lombok.Data;

@Data
public class QuantTQryRequest extends BaseQtAdminHttpRequest {
    private String portfolio_key;
    private String strategy_key;
}
