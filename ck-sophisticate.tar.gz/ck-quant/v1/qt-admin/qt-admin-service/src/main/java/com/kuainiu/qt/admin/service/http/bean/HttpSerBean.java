package com.kuainiu.qt.admin.service.http.bean;

import com.kuainiu.qt.admin.service.http.request.BaseQtAdminHttpRequest;
import lombok.Data;

@Data
public class HttpSerBean {
    private BaseQtAdminHttpRequest request;

    private Class responseClass;

    private String url;

    private String domain;

    private String uri;
}
