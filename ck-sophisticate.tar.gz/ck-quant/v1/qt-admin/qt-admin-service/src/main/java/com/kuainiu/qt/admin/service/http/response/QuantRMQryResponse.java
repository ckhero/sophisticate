package com.kuainiu.qt.admin.service.http.response;

import lombok.Data;

@Data
public class QuantRMQryResponse extends BaseQtAdminHttpResponse {
    private RmBean data;
}
