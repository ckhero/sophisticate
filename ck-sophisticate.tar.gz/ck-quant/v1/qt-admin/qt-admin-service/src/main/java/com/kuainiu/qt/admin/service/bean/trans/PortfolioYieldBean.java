package com.kuainiu.qt.admin.service.bean.trans;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class PortfolioYieldBean {
    private Date timestamp;
    private BigDecimal realtimeReturns;
    private BigDecimal baseRealtimeReturns;
}
