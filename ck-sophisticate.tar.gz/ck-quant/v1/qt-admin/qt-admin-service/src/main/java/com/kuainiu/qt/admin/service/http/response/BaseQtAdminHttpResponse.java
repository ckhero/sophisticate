package com.kuainiu.qt.admin.service.http.response;

import lombok.Data;

@Data
public class BaseQtAdminHttpResponse extends BaseHttpResponse {

}
