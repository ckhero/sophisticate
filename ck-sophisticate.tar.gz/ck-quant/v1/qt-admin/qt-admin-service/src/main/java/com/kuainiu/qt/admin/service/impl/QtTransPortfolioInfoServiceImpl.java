package com.kuainiu.qt.admin.service.impl;

import com.kuainiu.qt.admin.service.QtTransPortfolioInfoService;
import com.kuainiu.qt.admin.service.bean.trans.*;
import com.kuainiu.qt.admin.util.PortfolioServiceUtils;
import com.kuainiu.qt.data.facade.QtDataSnapshotPortfolioFacade;
import com.kuainiu.qt.data.facade.request.InfoRatioRequest;
import com.kuainiu.qt.data.facade.request.PortfolioQryRequest;
import com.kuainiu.qt.data.facade.request.StdRequest;
import com.kuainiu.qt.data.facade.response.InfoRatioResponse;
import com.kuainiu.qt.data.facade.response.StdResponse;
import com.kuainiu.qt.trans.facade.request.QtTransStkTransQryRequest;
import com.kuainiu.qt.trans.facade.request.futures.QtTransFuturesTransQryRequest;
import com.kuainiu.qt.data.facade.response.PortfolioQryResponse;
import com.kuainiu.qt.trans.facade.response.QtTransStkTransQryResponse;
import com.kuainiu.qt.trans.facade.response.futures.QtTransFuturesTransQryResponse;
import com.kuainiu.qt.trans.facade.trans.QtTransFuturesQryFacade;
import com.kuainiu.qt.trans.facade.trans.QtTransStkQryFacade;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.Reference;
import org.apache.dubbo.rpc.RpcException;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class QtTransPortfolioInfoServiceImpl implements QtTransPortfolioInfoService {
    @Reference
    QtTransFuturesQryFacade qtTransFuturesQryFacade;
    @Reference
    QtTransStkQryFacade qtTransStkQryFacade;

    @Override
    public StkTransListSerBean qryStkTransList(StkTransListReqSerBean stkReqSerBean) {
        QtTransStkTransQryRequest stkRequest = PortfolioServiceUtils.buildStkTransListRequest(stkReqSerBean);
        log.info("qry stk trans request : " + stkRequest);
        QtTransStkTransQryResponse stkResponse = new QtTransStkTransQryResponse();
        try{
            stkResponse = qtTransStkQryFacade.qryStkTrans(stkRequest);
            log.info("qry stk trans response : " + stkResponse);
        } catch (RpcException e){
            log.error("qry trans stk transList fail rpc", e);
        } catch (Exception e){
            log.error("trans fail", e);
        }
        return PortfolioServiceUtils.buildStkTransListSerBean(stkResponse);
    }

    @Override
    public FuturesTransListSerBean qryFuturesTransList(FuturesTransListReqSerBean futuresTransListReqSerBean) {
        QtTransFuturesTransQryRequest futuresRequest = PortfolioServiceUtils.buildFuturesTransListRequest(futuresTransListReqSerBean);
        log.info("qry futures trans request : " + futuresRequest);
        QtTransFuturesTransQryResponse futuresResponse = new QtTransFuturesTransQryResponse();
        try{
            futuresResponse = qtTransFuturesQryFacade.qryFuturesTrans(futuresRequest);
            log.info("qry futures trans response : " + futuresResponse);
        }catch (RpcException e){
            log.error("qry trans futures transList fail rpc", e);
        } catch (Exception e){
            log.error("trans fail", e);
        }
        return PortfolioServiceUtils.buildFuturesTransListSerBean(futuresResponse);
    }
}
