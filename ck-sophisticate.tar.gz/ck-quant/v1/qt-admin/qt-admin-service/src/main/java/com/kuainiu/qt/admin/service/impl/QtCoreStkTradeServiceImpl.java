package com.kuainiu.qt.admin.service.impl;

import com.alibaba.fastjson.JSON;
import com.kuainiu.qt.admin.code.QtAdminExternalRspCode;
import com.kuainiu.qt.admin.code.QtAdminRspCode;
import com.kuainiu.qt.admin.exception.ServiceException;
import com.kuainiu.qt.admin.service.QtCoreStkTradeService;
import com.kuainiu.qt.admin.service.bean.trans.PortfolioInfoReqSerBean;
import com.kuainiu.qt.admin.service.bean.trans.PortfolioInfoSerBean;
import com.kuainiu.qt.admin.service.bean.trans.StkTradeReqSerBean;
import com.kuainiu.qt.admin.service.bean.trans.StkTradeSerBean;
import com.kuainiu.qt.admin.util.StkServiceUtils;
import com.kuainiu.qt.core.facade.core.StkOrderFacade;
import com.kuainiu.qt.core.facade.request.StkOrderCommitRequest;
import com.kuainiu.qt.core.facade.response.StkOrderCommitResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.Reference;
import org.apache.dubbo.rpc.RpcException;
import org.springframework.stereotype.Service;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-25
 * Time: 15:27
 */
@Service
@Slf4j
public class QtCoreStkTradeServiceImpl implements QtCoreStkTradeService {
    @Reference
    StkOrderFacade stkOrderFacade;

    @Override
    public StkTradeSerBean stkOrderCommit(StkTradeReqSerBean reqSerBean) throws ServiceException {
        StkOrderCommitResponse response ;
        try {
            StkOrderCommitRequest request = StkServiceUtils.buildStkOrderCommitRequest(reqSerBean);
            log.info("[rpc to core] stkOrderCommit request : " + request);
            response = stkOrderFacade.stkOrderCommit(request);
            log.info("[rpc to core] stkOrderCommit response : " + response);
            if(QtAdminExternalRspCode.SUCCESS.getCode()!=response.getCode()){
                log.error("stkOrderCommit fail ! msg {} request {}", response.getMsg(), JSON.toJSONString(request));
                throw new ServiceException(QtAdminRspCode.ERR_STK_ORDER_COMMIT_FAIL);
            }
        }  catch (Exception e) {
            log.error("core fail", e);
            throw new ServiceException(QtAdminRspCode.ERR_STK_ORDER_COMMIT_FAIL);
        }
        return StkServiceUtils.buildStkTradeSerBean(response);
    }
}
