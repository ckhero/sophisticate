package com.kuainiu.qt.admin.service.bean.trans;

import com.kuainiu.qt.admin.service.bean.BaseQtAdminSerBean;
import lombok.Data;

import java.util.List;

@Data
public class PortfolioYieldSerBean extends BaseQtAdminSerBean {
    List<PortfolioYieldBean> data;
}
