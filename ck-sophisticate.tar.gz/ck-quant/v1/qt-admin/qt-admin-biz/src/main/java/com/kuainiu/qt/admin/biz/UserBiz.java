package com.kuainiu.qt.admin.biz;

import com.kuainiu.qt.admin.response.UserInfoResponse;
import com.kuainiu.qt.admin.response.UserLoginResponse;
import com.kuainiu.qt.auth.bean.User;

/**
 * @author chengqiang
 * @Classname UserLoginFacade
 * @Description TODO
 * @Created by chengqiang
 * @Date 2019/9/11 11:32 AM
 */
public interface UserBiz {
    /**
     * Get user login result information
     *
     * @param tempCode
     * @return
     */
    UserInfoResponse getLoginResult(String tempCode);

    /**
     * Get Enterprise QR url
     *
     * @return
     */
    String getEeQrUrl();

    /**
     *
     * @param user
     * @return
     */
    UserInfoResponse unauthorizedUser(User user);

    /**
     *
     * @param tempCode
     * @return
     */
    String getUUID(String tempCode);

    /**
     *
     * @param user
     * @return
     */
    UserInfoResponse loginSuccess(User user);

    /**
     *
     * @return
     */
    String getFrontEndRedirectUri();

    /**
     *
     * @param id
     * @return
     */
    User getUserById(int id);

    void saveUserInfoToCache(String uuid, User user);
    UserLoginResponse qryUserLoginInfo(String username);

}
