package com.kuainiu.qt.admin.bean.trans;

import com.kuainiu.qt.admin.bean.BaseQtAdminInBean;
import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/30
 * Time: 9:47 PM
 */
@Data
public class FuturesTransInBean extends BaseQtAdminInBean {

    private String portfolioCode;

    private String strategyCode;
}
