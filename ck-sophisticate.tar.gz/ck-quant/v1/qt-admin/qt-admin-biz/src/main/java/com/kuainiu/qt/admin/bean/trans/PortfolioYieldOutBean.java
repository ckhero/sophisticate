package com.kuainiu.qt.admin.bean.trans;

import com.kuainiu.qt.admin.bean.BaseQtAdminOutBean;
import lombok.Data;

import java.util.List;

@Data
public class PortfolioYieldOutBean extends BaseQtAdminOutBean {
    List<PortfolioYieldQryBean> data;
}
