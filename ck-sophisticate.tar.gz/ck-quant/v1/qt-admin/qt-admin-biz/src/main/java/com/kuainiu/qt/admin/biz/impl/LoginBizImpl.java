package com.kuainiu.qt.admin.biz.impl;

import com.kuainiu.qt.admin.biz.LoginBiz;
import com.kuainiu.qt.admin.code.QtAdminRspCode;
import com.kuainiu.qt.admin.response.LoginResponse;
import com.kuainiu.qt.admin.util.LoginLinkUtils;
import com.kuainiu.qt.auth.facade.UserOperatorFacade;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.stereotype.Service;

/**
 * @author chengqiang
 * @Classname LoginLinkImpl
 * @Description TODO
 * @Created by chengqiang
 * @Date 2019/9/12 2:24 PM
 */
@Service
@Slf4j
public class LoginBizImpl implements LoginBiz {

    @Reference
    private UserOperatorFacade userSerive;

    @Override
    public LoginResponse getEeWeChatQrUrl() {
        LoginResponse loginResponse = new LoginResponse();
        loginResponse.setMsg("登录连接返回成功");
        loginResponse.setCode(QtAdminRspCode.SUCCESS.getCode());
        loginResponse.setData(userSerive.getQrCodeUrl());

        return LoginLinkUtils.createUrl(loginResponse);
    }

    @Override
    public LoginResponse notLoginStatus() {
        LoginResponse loginResponse = new LoginResponse();
        loginResponse.setMsg(QtAdminRspCode.USER_NOT_LOGIN.getMsg());
        loginResponse.setCode(QtAdminRspCode.USER_NOT_LOGIN.getCode());
        return loginResponse;
    }

    @Override
    public LoginResponse unauthorizedUser() {
        LoginResponse loginResponse = new LoginResponse();
        loginResponse.setMsg("登录失败");
        loginResponse.setCode(QtAdminRspCode.FAIL.getCode());
        loginResponse.setData("冻结的用户！");
        return loginResponse;
    }
}
