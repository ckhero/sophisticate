package com.kuainiu.qt.admin.biz.facade.impl;

import com.kuainiu.qt.admin.bean.trans.*;
import com.kuainiu.qt.admin.param.ParamCheckHandle;
import com.kuainiu.qt.admin.util.PortfolioBizUtils;
import com.kuainiu.qt.admin.util.ResponseUtils;
import com.kuainiu.qt.admin.biz.PortfolioInfoBiz;
import com.kuainiu.qt.admin.facade.PortfolioInfoQryFacade;
import com.kuainiu.qt.admin.request.FuturesTransListQryRequest;
import com.kuainiu.qt.admin.request.PortfolioInfoQryRequest;
import com.kuainiu.qt.admin.request.StkTransListQryRequest;
import com.kuainiu.qt.admin.response.FuturesTransListQryResponse;
import com.kuainiu.qt.admin.response.PortfolioInfoQryResponse;
import com.kuainiu.qt.admin.response.StkTransListQryResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class PortfolioInfoQryFacadeImpl implements PortfolioInfoQryFacade {

    @Autowired
    PortfolioInfoBiz portfolioInfoBiz;

    @Override
    public PortfolioInfoQryResponse qryPortfolioInfo(PortfolioInfoQryRequest request) {
        PortfolioInfoQryResponse response = new PortfolioInfoQryResponse();
        ParamCheckHandle.checkPortfolioInfoQryRequest(request);
        PortfolioInBean inBean = PortfolioBizUtils.buildPortfolioInfoInBean(request);
        PortfolioOutBean outBean = portfolioInfoBiz.qryPortfolio(inBean);
        response = PortfolioBizUtils.buildPortfolioQryResponse(outBean);
        ResponseUtils.success(response);
        return response;
    }

    @Override
    public StkTransListQryResponse qryStkTransList(StkTransListQryRequest request) {
        StkTransListQryResponse response = new StkTransListQryResponse();
        StkTransListInBean inBean = PortfolioBizUtils.buildStkTransListInBean(request);
        StkTransListOutBean outBean = portfolioInfoBiz.qryStkTrans(inBean);
        response = PortfolioBizUtils.buildStkTransListQryResponse(outBean);
        ResponseUtils.success(response);
        return response;
    }

    @Override
    public FuturesTransListQryResponse qryFuturesTransList(FuturesTransListQryRequest request) {
        FuturesTransListQryResponse response;
        FuturesTransInBean inBean = PortfolioBizUtils.buildFuturesTransInBean(request);
        FuturesTransQryBean outBean = portfolioInfoBiz.qryFuturesTrans(inBean);
        response = PortfolioBizUtils.buildStkTransListQryResponse(outBean);
        ResponseUtils.success(response);
        return response;
    }
}
