package com.kuainiu.qt.admin.bean.trans;

import com.kuainiu.qt.admin.bean.BaseQtAdminInBean;
import lombok.Data;

@Data
public class StkTransListInBean extends BaseQtAdminInBean {

    private String portfolioCode;

    private String strategyCode;
}
