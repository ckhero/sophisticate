package com.kuainiu.qt.admin.util;

import com.kuainiu.qt.admin.bean.*;
import com.kuainiu.qt.admin.bean.trans.*;
import com.kuainiu.qt.admin.request.*;
import com.kuainiu.qt.admin.response.*;
import com.kuainiu.qt.admin.service.bean.quant.QuantRMReqSerBean;
import com.kuainiu.qt.admin.service.bean.quant.QuantTReqSerBean;
import com.kuainiu.qt.admin.service.bean.trans.*;
import com.kuainiu.qt.admin.bean.trans.*;
import com.kuainiu.qt.admin.common.util.BeanMapUtils;
import com.kuainiu.qt.admin.consts.Consts;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Slf4j
public class PortfolioBizUtils {
    //策略组合查询
    public static PortfolioInBean buildPortfolioInfoInBean(PortfolioInfoQryRequest request) {
        PortfolioInBean inBean = new PortfolioInBean();
        BeanMapUtils.map(request, inBean);

        inBean.setPortfolioKey("PF000001");
        inBean.setDatetime(new Date());
        inBean.setStartBelongTime(TimeUtils.getStartBelongTimePortfolio(new Date()));
        inBean.setEndBelongTime(new Date());
        inBean.setPageNo(Consts.PAGE_NO);
        inBean.setPageSize(Consts.PAGE_SIZE_PORTFOLIO);
        return inBean;
    }

    public static PortfolioInfoQryResponse buildPortfolioQryResponse(PortfolioOutBean outBean) {
        PortfolioInfoQryResponse response = new PortfolioInfoQryResponse();
        PortfolioInfoQryFacadeBean portfolioInfoQryFacadeBean = new PortfolioInfoQryFacadeBean();

        BeanMapUtils.map(outBean, portfolioInfoQryFacadeBean);
        BigDecimal tr = portfolioInfoQryFacadeBean.getTotalReturns();
        BigDecimal rr = portfolioInfoQryFacadeBean.getRealtimeReturns();
        BigDecimal cash = portfolioInfoQryFacadeBean.getCash();
        BigDecimal mv = portfolioInfoQryFacadeBean.getMarketValue();
        BigDecimal dp = portfolioInfoQryFacadeBean.getDailyPnl();
        BigDecimal pnl = portfolioInfoQryFacadeBean.getPnl();
        BigDecimal ar = portfolioInfoQryFacadeBean.getAnnualizedReturns();
        BigDecimal tf = portfolioInfoQryFacadeBean.getTotalFund();

        if (tr == null || rr == null || cash == null || mv == null || dp == null || pnl == null || ar == null) {
            log.error("portfolio outBean value null, totalReturns: {}, realtimeReturns: {}, cash: {},marketValue: {}, DailyPnl: {}, pnl: {}, AnnualizedReturns: {}"
                    ,tr,rr,cash,mv,dp,pnl,ar);
        } else {
            portfolioInfoQryFacadeBean.setTotalReturns(tr.setScale(4, BigDecimal.ROUND_UP));
            portfolioInfoQryFacadeBean.setRealtimeReturns(rr.setScale(4, BigDecimal.ROUND_UP));
            portfolioInfoQryFacadeBean.setAnnualizedReturns(ar.setScale(4, BigDecimal.ROUND_UP));
            BigDecimal change = new BigDecimal(10000);
            portfolioInfoQryFacadeBean.setCash(cash.divide(change, 4, RoundingMode.HALF_UP));
            portfolioInfoQryFacadeBean.setMarketValue(mv.divide(change, 4, RoundingMode.HALF_UP));
            portfolioInfoQryFacadeBean.setDailyPnl(dp.divide(change, 4, RoundingMode.HALF_UP));
            portfolioInfoQryFacadeBean.setPnl(pnl.divide(change, 4, RoundingMode.HALF_UP));
            portfolioInfoQryFacadeBean.setTotalFund(tf.divide(change, 4, RoundingMode.HALF_UP));
            response.setData(portfolioInfoQryFacadeBean);
        }
        return response;
    }

    public static PortfolioInfoReqSerBean buildPortfolioReqSerBean(PortfolioInBean inBean) {
        PortfolioInfoReqSerBean reqSerBean = new PortfolioInfoReqSerBean();
        BeanMapUtils.map(inBean, reqSerBean);
        return reqSerBean;
    }

    public static PortfolioOutBean buildPortfolioInfoOutBean(PortfolioInfoSerBean serBean) {
        PortfolioOutBean outBean = new PortfolioOutBean();
        BeanMapUtils.map(serBean, outBean);
        return outBean;
    }

    //策略组合曲线
    public static PortfolioYieldInBean buildPortfolioYieldInBean(PortfolioYieldRequest request) {
        PortfolioYieldInBean inBean = new PortfolioYieldInBean();
        BeanMapUtils.map(request, inBean);
        Date now = new Date();
        Date end = TimeUtils.getEndBelongTimeYield(now);
        inBean.setStartBelongTime(TimeUtils.getStartBelongTimeYield(now));
        if (now.before(end)) {
            inBean.setEndBelongTime(TimeUtils.getOneMintueAgo(now));
        } else {
            inBean.setEndBelongTime(end);
        }
        inBean.setPageNo(Consts.PAGE_NO);
        inBean.setPageSize(Consts.PAGE_SIZE_YIELD);
        return inBean;
    }

    public static PortfolioYieldReqSerBean buildPortfolioYieldSerBean(PortfolioYieldInBean inBean) {
        PortfolioYieldReqSerBean reqSerBean = new PortfolioYieldReqSerBean();
        BeanMapUtils.map(inBean, reqSerBean);
        return reqSerBean;
    }

    public static PortfolioYieldOutBean buildPortfolioYieldOutBean(PortfolioYieldSerBean serBean) {
        PortfolioYieldOutBean outBean = new PortfolioYieldOutBean();
        List<PortfolioYieldQryBean> data = new ArrayList<>();
        try {
            data = BeanMapUtils.mapAsList(serBean.getData(),PortfolioYieldQryBean.class);
        } catch (InstantiationException e) {
            log.error("portfolio yield outBean param instantiation error");
        } catch (IllegalAccessException e) {
            log.error("portfolio yield outBean param illegal access");
        }
        outBean.setData(data);
        return outBean;
    }

    public static PortfolioYieldResponse buildPortfolioYieldResponse(PortfolioYieldOutBean outBean) {
        PortfolioYieldResponse response = new PortfolioYieldResponse();
        List<PortfolioYieldQryFacadeBean> data = new ArrayList<>();
        try {
            data = BeanMapUtils.mapAsList(outBean.getData(), PortfolioYieldQryFacadeBean.class);
        } catch (InstantiationException e) {
            log.error("portfolio yield response param instantiation error");
        } catch (IllegalAccessException e) {
            log.error("portfolio yield response param illegal access");
        }
        response.setData(data);
        return response;
    }

    public static HistoryPortfolioYieldInBean buildHistoryPortfolioYieldInBean(HistoryPortfolioYieldRequest request) {
        HistoryPortfolioYieldInBean inBean = new HistoryPortfolioYieldInBean();
        BeanMapUtils.map(request, inBean);
        return inBean;
    }

    public static HistoryPortfolioYieldReqSerBean buildHistoryPortfolioYieldReqSerBean(HistoryPortfolioYieldInBean inBean) {
        HistoryPortfolioYieldReqSerBean reqSerBean = new HistoryPortfolioYieldReqSerBean();
        BeanMapUtils.map(inBean, reqSerBean);
        return reqSerBean;
    }

    public static HistoryPortfolioYieldOutBean buildHistoryPortfolioYieldOutBean(HistoryPortfolioYieldSerBean serBean) {
        HistoryPortfolioYieldOutBean outBean = new HistoryPortfolioYieldOutBean();
        List<HistoryPortfolioYieldQryBean> data = new ArrayList<>();
        try {
            data = BeanMapUtils.mapAsList(serBean.getData(), HistoryPortfolioYieldQryBean.class);
        } catch (InstantiationException e) {
            log.error("history portfolio yield outBean param instantiation error");
        } catch (IllegalAccessException e) {
            log.error("history portfolio yield outBean param illegal access");
        }
        outBean.setData(data);
        return outBean;
    }

    public static HistoryPortfolioYieldResponse buildHistoryPortfolioYieldResponse(HistoryPortfolioYieldOutBean outBean) {
        HistoryPortfolioYieldResponse response = new HistoryPortfolioYieldResponse();
        List<HistoryPortfolioYieldQryFacadeBean> data = new ArrayList<>();
        try {
            data = BeanMapUtils.mapAsList(outBean.getData(), HistoryPortfolioYieldQryFacadeBean.class);
        } catch (InstantiationException e) {
            log.error("history portfolio yield response param instantiation error");
        } catch (IllegalAccessException e) {
            log.error("history portfolio yield response param illegal access error");
        }
        response.setData(data);
        return response;
    }

    public static PortfolioYieldReqSerBean buildRPListReqSerBean(PortfolioInfoReqSerBean reqSerBean) {
        PortfolioYieldReqSerBean rp = new PortfolioYieldReqSerBean();
        BeanMapUtils.map(reqSerBean, rp);
        return rp;
    }

    public static QuantRMReqSerBean buildRMReqSerBean(PortfolioInfoReqSerBean reqSerBean) {
        QuantRMReqSerBean rmReqSerBean = new QuantRMReqSerBean();
        BeanMapUtils.map(reqSerBean, rmReqSerBean);
        return rmReqSerBean;
    }

    public static StkTransListReqSerBean buildStkTransListReqSerBean(StkTransListInBean inBean) {
        StkTransListReqSerBean reqSerBean = new StkTransListReqSerBean();
        BeanMapUtils.map(inBean, reqSerBean);
        return reqSerBean;
    }

    public static FuturesTransListReqSerBean buildFuturesTransListReqSerBeann(FuturesTransInBean inBean) {
        FuturesTransListReqSerBean reqSerBean = new FuturesTransListReqSerBean();
        BeanMapUtils.map(inBean, reqSerBean);
        return reqSerBean;
    }

    public static InformationRatioQryReqSerBean buildInformationRatioReqSerBean(PortfolioInfoReqSerBean reqSerBean) {
        InformationRatioQryReqSerBean reqSerBean1 = new InformationRatioQryReqSerBean();
        BeanMapUtils.map(reqSerBean, reqSerBean1);
        return reqSerBean1;
    }


    public static QuantTReqSerBean buildTReqSerBean(PortfolioInfoReqSerBean reqSerBean) {
        QuantTReqSerBean tReqSerBean = new QuantTReqSerBean();
        BeanMapUtils.map(reqSerBean, tReqSerBean);
        return tReqSerBean;
    }

    public static StkTransListInBean buildStkTransListInBean(StkTransListQryRequest request) {
        StkTransListInBean inBean = new StkTransListInBean();
        BeanMapUtils.map(request, inBean);
        return inBean;
    }

    public static FuturesTransInBean buildFuturesTransInBean(FuturesTransListQryRequest request) {
        FuturesTransInBean inBean = new FuturesTransInBean();
        BeanMapUtils.map(request, inBean);
        return inBean;
    }
    public static StkTransListOutBean buildTransListOutBean(StkTransListSerBean stkSerBean) {
        StkTransListOutBean listOutBean = new StkTransListOutBean();
        List<StkTransOutBean> outBean = new ArrayList<>();
        BeanMapUtils.map(stkSerBean, listOutBean);
        try {
            outBean = BeanMapUtils.mapAsList(stkSerBean.getTransList(), StkTransOutBean.class);
        } catch (InstantiationException e) {
            log.error(" stk transList outBean param instantiation error");
        } catch (IllegalAccessException e) {
            log.error(" stk transList outBean param illegal access error");
        }
        listOutBean.setTransList(outBean);
        return listOutBean;
    }

    public static StkTransListQryResponse buildStkTransListQryResponse(StkTransListOutBean outBean) {
        StkTransListQryResponse response = new StkTransListQryResponse();
        StkTransListFacadeBean data = new StkTransListFacadeBean();
        List<StkTransQryFacadeBean> facadeBeanList= new ArrayList<>();
        try {
            BeanMapUtils.map(outBean, response);
            facadeBeanList = BeanMapUtils.mapAsList(outBean.getTransList(),StkTransQryFacadeBean.class);
        } catch (InstantiationException e) {
            log.error("transList response param instantiation error");
        } catch (IllegalAccessException e) {
            log.error("transList response param illegal access");
        }
        data.setList(facadeBeanList);
        data.setTotal(outBean.getTotal());
        response.setData(data);
        return response;
    }

    public static FuturesTransListQryResponse buildStkTransListQryResponse(FuturesTransQryBean outBean) {
        FuturesTransListQryResponse response = new FuturesTransListQryResponse();
        List<FuturesTransFacadeBean> transList= new ArrayList<>();
        FuturesTransQryFacadeBean qryFacadeBean = new FuturesTransQryFacadeBean();
        try {
            BeanMapUtils.map(outBean, response);
            transList = BeanMapUtils.mapAsList(outBean.getTransList(),FuturesTransFacadeBean.class);
        } catch (InstantiationException e) {
            log.error("transList response param instantiation error");
        } catch (IllegalAccessException e) {
            log.error("transList response param illegal access");
        }
        qryFacadeBean.setList(transList);
        qryFacadeBean.setTotal(outBean.getTotal());
        response.setData(qryFacadeBean);
        return response;
    }

    public static FuturesTransQryBean buildFuturesTransQryBean(FuturesTransListSerBean futuresTrans) {
        FuturesTransQryBean qryBean = new FuturesTransQryBean();
        List<FuturesTransOutBean> transList = new ArrayList<>();
        BeanMapUtils.map(futuresTrans, qryBean);
        try {
            transList = BeanMapUtils.mapAsList(futuresTrans.getTransList(), FuturesTransOutBean.class);
        } catch (InstantiationException e) {
            log.error(" stk transList outBean param instantiation error");
        } catch (IllegalAccessException e) {
            log.error(" stk transList outBean param illegal access error");
        }
        qryBean.setTransList(transList);
        return qryBean;
    }
}
