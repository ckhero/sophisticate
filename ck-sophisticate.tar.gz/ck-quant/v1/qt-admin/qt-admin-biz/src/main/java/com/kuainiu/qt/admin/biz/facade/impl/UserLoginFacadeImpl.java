package com.kuainiu.qt.admin.biz.facade.impl;

import com.kuainiu.qt.admin.facade.UserLoginFacade;
import com.kuainiu.qt.admin.request.UserLoginRequest;
import com.kuainiu.qt.admin.response.UserLoginResponse;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-17
 * Time: 11:19
 */
public class UserLoginFacadeImpl implements UserLoginFacade {



    @Override
    public UserLoginResponse login(UserLoginRequest request) {

        return null;
    }
}
