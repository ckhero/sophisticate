package com.kuainiu.qt.admin.bean.trans;

import lombok.Data;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-26
 * Time: 17:21
 */
@Data
public class StkOrderCommitBizInBean {
    /**
     * 前置委托编号
     */
    private String frontOrderId;

    /**
     * 投资组合编号
     */
    private String portfolioCode;

    private String strategyCode;

    /**
     * token
     */
    private String accessToken;

    /**
     * 股票代码
     */
    private String assetNo;

    /**
     * 渠道号[PASH:平安上证;PASZ:平安深证]
     */
    private String channelCode;

    /**
     * 委托类型[100:市价买入(默认策略);101:最优成交剩撤买入;110:限价买入;200:市价卖出(默认策略);201:最优成交剩撤卖出;210:限价卖出;300:委托撤销;]
     */
    private Integer transType;

    /**
     * 限价(单位：分)，限价买入卖出时必填
     */
    private BigDecimal limitPrice;

    /**
     * 委托数量（单位：手），指定手数时必填
     */
    private Integer amount;

    private String sysId;
}
