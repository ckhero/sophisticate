package com.kuainiu.qt.admin.util;

import com.kuainiu.qt.admin.code.QtAdminRspCode;
import com.kuainiu.qt.admin.response.UserInfoResponse;
import lombok.extern.slf4j.Slf4j;

/**
 * @author chengqiang
 * @Classname UserUtils
 * @Description TODO
 * @Created by chengqiang
 * @Date 2019/9/11 12:02 PM
 */
@Slf4j
public class UserUtils {

    public static UserInfoResponse succeed(UserInfoResponse response) {
        if (response != null) {
            response.setCode(QtAdminRspCode.SUCCESS.getCode());
            response.setMsg("登录成功");
            return response;
        } else {
            UserInfoResponse responseSysErr = new UserInfoResponse();
            log.error("Set user info succeed response error.");
            responseSysErr.setCode(QtAdminRspCode.ERR_PARAM_ERROR.getCode());
            responseSysErr.setMsg("系统参数错误");
            return responseSysErr;
        }

    }

    public static UserInfoResponse failed(UserInfoResponse response) {
        if (response != null) {
            response.setCode(QtAdminRspCode.FAIL.getCode());
            response.setMsg("登录失败");
            return response;
        } else {
            UserInfoResponse responseSysErr = new UserInfoResponse();
            log.error("Set user info failed response error.");
            responseSysErr.setCode(QtAdminRspCode.ERR_PARAM_ERROR.getCode());
            responseSysErr.setMsg("系统参数错误");
            return responseSysErr;
        }

    }

    public static UserInfoResponse unauthrized(UserInfoResponse response) {
        if (response != null) {
            response.setCode(QtAdminRspCode.USER_NO_PERMISSION.getCode());
            response.setMsg("用户权限不足");
            return response;
        } else {
            UserInfoResponse responseSysErr = new UserInfoResponse();
            log.error("Set user info unauthorized response error.");
            responseSysErr.setCode(QtAdminRspCode.ERR_PARAM_ERROR.getCode());
            responseSysErr.setMsg("系统参数错误");
            return responseSysErr;
        }
    }
}
