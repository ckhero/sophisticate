package com.kuainiu.qt.admin.bean.trans;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class StkPositionBean {

    private String assetNo;

    private String transBoard;

    private Integer qty;

    private BigDecimal pnl;

    private Integer sellableQty;

    private BigDecimal marketValue;

    private BigDecimal valuePercent;

    private BigDecimal avgPrice;

    private String assetName;
}
