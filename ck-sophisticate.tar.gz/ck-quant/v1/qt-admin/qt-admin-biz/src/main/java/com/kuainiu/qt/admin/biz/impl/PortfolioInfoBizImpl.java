package com.kuainiu.qt.admin.biz.impl;

import com.kuainiu.qt.admin.bean.trans.*;
import com.kuainiu.qt.admin.service.QtDataSnapshotInfoService;
import com.kuainiu.qt.admin.service.bean.trans.*;
import com.kuainiu.qt.admin.util.PortfolioBizUtils;
import com.kuainiu.qt.admin.biz.PortfolioInfoBiz;
import com.kuainiu.qt.admin.service.QtTransPortfolioInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class PortfolioInfoBizImpl implements PortfolioInfoBiz {

    @Autowired
    QtTransPortfolioInfoService qtTransPortfolioInfoService;
    @Autowired
    QtDataSnapshotInfoService qtDataSnapshotInfoService;

    @Override
    public PortfolioOutBean qryPortfolio(PortfolioInBean inBean) {
        PortfolioOutBean outBean;

        PortfolioInfoReqSerBean reqSerBean = PortfolioBizUtils.buildPortfolioReqSerBean(inBean);
        PortfolioInfoSerBean serBean = qtDataSnapshotInfoService.qryPortfolioInfo(reqSerBean);
        log.info("qry PortfolioInfo : " + serBean.toString());

        //一期写死的两个数据
        serBean.setStrategyID("股票SF00001");
        serBean.setStrategyName("股票+期货");
        outBean = PortfolioBizUtils.buildPortfolioInfoOutBean(serBean);
        return outBean;
    }

    @Override
    public StkTransListOutBean qryStkTrans(StkTransListInBean inBean) {
        StkTransListReqSerBean stkReqSerBean = PortfolioBizUtils.buildStkTransListReqSerBean(inBean);
        StkTransListSerBean stkSerBean = qtTransPortfolioInfoService.qryStkTransList(stkReqSerBean);
        return PortfolioBizUtils.buildTransListOutBean(stkSerBean);
    }

    @Override
    public FuturesTransQryBean qryFuturesTrans(FuturesTransInBean inBean) {
        FuturesTransListReqSerBean reqSerBean = PortfolioBizUtils.buildFuturesTransListReqSerBeann(inBean);
        FuturesTransListSerBean serBean= qtTransPortfolioInfoService.qryFuturesTransList(reqSerBean);
        return PortfolioBizUtils.buildFuturesTransQryBean(serBean);
    }
}
