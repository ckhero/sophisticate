package com.kuainiu.qt.admin.util;

import lombok.extern.slf4j.Slf4j;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

@Slf4j
public class TimeUtils {
    private static Date changeTime(Date date, int addDay, int hour, int min, int second){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, addDay);

        calendar.set(Calendar.HOUR_OF_DAY,hour);
        calendar.set(Calendar.MINUTE,min);
        calendar.set(Calendar.SECOND,second);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    private Date changeDay(Date date, int addDay){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, addDay);
        return calendar.getTime();
    }

    public static Date getStartBelongTimePortfolio(Date now){
        return changeTime(now,-1,9,30,0);
    }

    public static Date getStartBelongTimeYield(Date now){
        return changeTime(now,0,9,30,0);
    }

    public static Date getEndBelongTimeYield(Date now){
        return changeTime(now,0,15,0,0);
    }

    public static Date getOneMintueAgo(Date now) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(now);
        calendar.add(Calendar.MINUTE, -1);// 1分钟之前的时间
        return calendar.getTime();
    }
}
