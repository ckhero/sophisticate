package com.kuainiu.qt.admin.biz;

import com.kuainiu.qt.admin.bean.trans.HistoryPortfolioYieldInBean;
import com.kuainiu.qt.admin.bean.trans.HistoryPortfolioYieldOutBean;
import com.kuainiu.qt.admin.bean.trans.PortfolioYieldInBean;
import com.kuainiu.qt.admin.bean.trans.PortfolioYieldOutBean;

public interface YieldBiz {
    PortfolioYieldOutBean qryPortfolioYield(PortfolioYieldInBean inBean);

    HistoryPortfolioYieldOutBean qryHistoryPortfolioYield(HistoryPortfolioYieldInBean inBean);
}
