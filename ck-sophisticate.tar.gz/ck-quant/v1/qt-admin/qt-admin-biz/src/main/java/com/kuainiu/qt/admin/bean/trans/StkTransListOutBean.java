package com.kuainiu.qt.admin.bean.trans;

import com.kuainiu.qt.admin.bean.BaseQtAdminOutBean;
import lombok.Data;

import java.util.List;

@Data
public class StkTransListOutBean extends BaseQtAdminOutBean {
    private Integer total;
    private List<StkTransOutBean> transList;
}
