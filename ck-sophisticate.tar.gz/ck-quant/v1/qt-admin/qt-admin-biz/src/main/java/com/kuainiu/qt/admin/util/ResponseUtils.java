package com.kuainiu.qt.admin.util;

import com.kuainiu.qt.admin.code.QtAdminRspCode;
import com.kuainiu.qt.admin.exception.BizException;
import com.kuainiu.qt.admin.exception.ServiceException;
import com.kuainiu.qt.admin.exception.ServiceRuntimeException;
import com.kuainiu.qt.admin.response.BaseQtAdminResponse;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.TimeoutException;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/19
 * Time: 4:13 PM
 */
@Slf4j
public class ResponseUtils {

    private ResponseUtils(){
    }

    public static void sysError(BaseQtAdminResponse resp, Throwable e){
        if (e instanceof IllegalArgumentException) {
            resp.setCode(QtAdminRspCode.ERR_PARAM_ERROR.getCode());
            resp.setMsg(e.getMessage());
        } else if (e instanceof TimeoutException) {
            resp.setCode(QtAdminRspCode.SYS_TIMEOUT.getCode());
            resp.setMsg(QtAdminRspCode.SYS_TIMEOUT.getMsg());
        } else if (e instanceof ServiceException) {
            ServiceException se = (ServiceException) e;
            if (se.getCode() != null) {
                se.exceptionToResponse(resp);
            } else {
                resp.setErrorCodeAndException(QtAdminRspCode.ERR_BUSI_ERROR, e);
            }
        } else if (e instanceof ServiceRuntimeException) {
            ServiceRuntimeException se = (ServiceRuntimeException) e;
            if (se.getCode() != null) {
                se.exceptionToResponse(resp);
            } else {
                resp.setErrorCodeAndException(QtAdminRspCode.ERR_SYS_ERROR, e);
            }
        } else if (e instanceof BizException) {
            BizException be = (BizException) e;

            if (be.getCode() != null) {
                be.exceptionToResponse(resp);
            } else {
                resp.setErrorCodeAndException(QtAdminRspCode.ERR_BUSI_ERROR, e);
            }
        } else {
            resp.setCode(QtAdminRspCode.SYS_ERROR.getCode());
            resp.setMsg(QtAdminRspCode.SYS_ERROR.getMsg());
        }
        log.error("facade调用返回异常！code：{},msg:{}", resp.getCode(), resp.getMsg());
        log.error("facade调用返回异常！", e);
    }

    public static void success(BaseQtAdminResponse resp){
        resp.setCode(QtAdminRspCode.SUCCESS.getCode());
        resp.setMsg(QtAdminRspCode.SUCCESS.getMsg());
    }
}
