package com.kuainiu.qt.admin.biz.impl;

import com.kuainiu.qt.admin.bean.trans.HistoryPortfolioYieldInBean;
import com.kuainiu.qt.admin.bean.trans.HistoryPortfolioYieldOutBean;
import com.kuainiu.qt.admin.bean.trans.PortfolioYieldInBean;
import com.kuainiu.qt.admin.bean.trans.PortfolioYieldOutBean;
import com.kuainiu.qt.admin.util.PortfolioBizUtils;
import com.kuainiu.qt.admin.biz.YieldBiz;
import com.kuainiu.qt.admin.service.QtDataPortfolioYieldService;
import com.kuainiu.qt.admin.service.bean.trans.HistoryPortfolioYieldReqSerBean;
import com.kuainiu.qt.admin.service.bean.trans.HistoryPortfolioYieldSerBean;
import com.kuainiu.qt.admin.service.bean.trans.PortfolioYieldReqSerBean;
import com.kuainiu.qt.admin.service.bean.trans.PortfolioYieldSerBean;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class YieldBizImpl implements YieldBiz {

    @Autowired
    QtDataPortfolioYieldService qtDataPortfolioYieldService;

    @Override
    public PortfolioYieldOutBean qryPortfolioYield(PortfolioYieldInBean inBean) {
        PortfolioYieldReqSerBean reqSerBean = PortfolioBizUtils.buildPortfolioYieldSerBean(inBean);
        PortfolioYieldSerBean serBean = qtDataPortfolioYieldService.qryPortfolioYield(reqSerBean);
        return PortfolioBizUtils.buildPortfolioYieldOutBean(serBean);
    }

    @Override
    public HistoryPortfolioYieldOutBean qryHistoryPortfolioYield(HistoryPortfolioYieldInBean inBean) {
        HistoryPortfolioYieldReqSerBean reqSerBean = PortfolioBizUtils.buildHistoryPortfolioYieldReqSerBean(inBean);
        HistoryPortfolioYieldSerBean serBean = qtDataPortfolioYieldService.qryHistoryPortfolioYield(reqSerBean);
        return PortfolioBizUtils.buildHistoryPortfolioYieldOutBean(serBean);
    }
}
