package com.kuainiu.qt.admin.biz.facade.impl;

import com.kuainiu.qt.admin.bean.trans.StkOrderCommitBizInBean;
import com.kuainiu.qt.admin.bean.trans.StkOrderCommitBizOutBean;
import com.kuainiu.qt.admin.biz.StkTradeBiz;
import com.kuainiu.qt.admin.code.QtAdminRspCode;
import com.kuainiu.qt.admin.common.util.BeanMapUtils;
import com.kuainiu.qt.admin.exception.BizException;
import com.kuainiu.qt.admin.exception.ServiceException;
import com.kuainiu.qt.admin.facade.StkTradeFacade;
import com.kuainiu.qt.admin.request.StkOrderCommitRequest;
import com.kuainiu.qt.admin.response.StkOrderCommitResponse;
import com.kuainiu.qt.admin.service.QtCoreStkTradeService;
import com.kuainiu.qt.admin.service.bean.trans.StkTradeReqSerBean;
import com.kuainiu.qt.admin.service.bean.trans.StkTradeSerBean;
import com.kuainiu.qt.admin.util.ResponseUtils;
import com.kuainiu.qt.admin.util.StkTradeUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-25
 * Time: 17:33
 */
@Service
@Slf4j
public class StkTradeFacadeImpl implements StkTradeFacade {

    @Autowired
    StkTradeBiz stkTradeBiz;

    @Override
    public StkOrderCommitResponse stkOrderCommit(StkOrderCommitRequest request) {

        StkOrderCommitResponse response= new StkOrderCommitResponse();
        try {
            StkOrderCommitBizInBean inBean= StkTradeUtils.buildStkOrderCommitBizInBean(request);
            StkOrderCommitBizOutBean result=stkTradeBiz.stkOrderCommit(inBean);
            response = StkTradeUtils.buildStkOrderCommitResponse(result);
        } catch (BizException e) {
            ResponseUtils.sysError(response,e);
            return response;
        }catch (Exception e){
            response.setMsg(QtAdminRspCode.ERR_STK_ORDER_COMMIT_FAIL.getMsg());
            log.error("stkOrderCommit fail!",e);
            return response;
        }
        ResponseUtils.success(response);
        return response;
    }
}
