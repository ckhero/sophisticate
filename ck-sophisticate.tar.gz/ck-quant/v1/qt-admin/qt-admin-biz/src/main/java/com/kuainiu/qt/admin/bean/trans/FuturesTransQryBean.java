package com.kuainiu.qt.admin.bean.trans;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/30
 * Time: 9:49 PM
 */
@Data
public class FuturesTransQryBean {
    private Integer total;

    private List<FuturesTransOutBean> transList = new ArrayList<>();
}
