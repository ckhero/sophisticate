package com.kuainiu.qt.admin.bean.trans;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class FuturesPositionBean {

    private String assetNo;

    private BigDecimal pnl;

    private BigDecimal dailyPnl;

    private BigDecimal holdingPnl;

    private BigDecimal realizedPnl;

    private BigDecimal transCost;

    private BigDecimal margin;

    private BigDecimal frzMargin;

    private BigDecimal marketValue;

    private Integer closableBuyQty;

    private Integer buyTodayQty;

    private BigDecimal buyAvgOpenPrice;

    private BigDecimal buyAvgHoldingPrice;

    private Integer closableSellQty;

    private Integer sellTodayQty;

    private BigDecimal sellAvgOpenPrice;

    private BigDecimal sellAvgHoldingPrice;
}
