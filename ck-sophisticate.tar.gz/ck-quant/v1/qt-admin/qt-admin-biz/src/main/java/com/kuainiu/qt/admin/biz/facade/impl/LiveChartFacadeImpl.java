package com.kuainiu.qt.admin.biz.facade.impl;

import com.kuainiu.qt.admin.bean.trans.HistoryPortfolioYieldInBean;
import com.kuainiu.qt.admin.bean.trans.HistoryPortfolioYieldOutBean;
import com.kuainiu.qt.admin.bean.trans.PortfolioYieldInBean;
import com.kuainiu.qt.admin.bean.trans.PortfolioYieldOutBean;
import com.kuainiu.qt.admin.biz.YieldBiz;
import com.kuainiu.qt.admin.param.ParamCheckHandle;
import com.kuainiu.qt.admin.util.PortfolioBizUtils;
import com.kuainiu.qt.admin.util.ResponseUtils;
import com.kuainiu.qt.admin.facade.LiveChartFacade;
import com.kuainiu.qt.admin.request.HistoryPortfolioYieldRequest;
import com.kuainiu.qt.admin.request.PortfolioYieldRequest;
import com.kuainiu.qt.admin.response.HistoryPortfolioYieldResponse;
import com.kuainiu.qt.admin.response.PortfolioYieldResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class LiveChartFacadeImpl implements LiveChartFacade {

    @Autowired
    YieldBiz yieldBiz;

    @Override
    public PortfolioYieldResponse qryPortfolio(PortfolioYieldRequest request) {
        PortfolioYieldResponse response = new PortfolioYieldResponse();
        ParamCheckHandle.checkPortfolioYieldRequest(request);
        PortfolioYieldInBean inBean = PortfolioBizUtils.buildPortfolioYieldInBean(request);
        PortfolioYieldOutBean outBean = yieldBiz.qryPortfolioYield(inBean);
        response = PortfolioBizUtils.buildPortfolioYieldResponse(outBean);
        ResponseUtils.success(response);
        return response;
    }

    @Override
    public HistoryPortfolioYieldResponse qryHistoryPortfolio(HistoryPortfolioYieldRequest request) {
        HistoryPortfolioYieldResponse response = new HistoryPortfolioYieldResponse();
        ParamCheckHandle.checkHistoryPortfolioYield(request);
        HistoryPortfolioYieldInBean inBean = PortfolioBizUtils.buildHistoryPortfolioYieldInBean(request);
        HistoryPortfolioYieldOutBean outBean = yieldBiz.qryHistoryPortfolioYield(inBean);
        response = PortfolioBizUtils.buildHistoryPortfolioYieldResponse(outBean);
        ResponseUtils.success(response);
        return response;
    }
}
