package com.kuainiu.qt.admin.biz;

import com.kuainiu.qt.admin.bean.trans.StkOrderCommitBizInBean;
import com.kuainiu.qt.admin.bean.trans.StkOrderCommitBizOutBean;
import com.kuainiu.qt.admin.exception.BizException;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-26
 * Time: 17:16
 */
public interface StkTradeBiz {
    StkOrderCommitBizOutBean stkOrderCommit(StkOrderCommitBizInBean inBean)throws BizException;
}
