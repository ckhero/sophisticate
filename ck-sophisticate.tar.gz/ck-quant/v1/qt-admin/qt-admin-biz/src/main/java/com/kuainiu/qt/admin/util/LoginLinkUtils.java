package com.kuainiu.qt.admin.util;

import com.kuainiu.qt.admin.code.QtAdminRspCode;
import com.kuainiu.qt.admin.response.LoginResponse;
import lombok.extern.slf4j.Slf4j;

/**
 * @author chengqiang
 * @Classname LoginLinkUtils
 * @Description TODO
 * @Created by chengqiang
 * @Date 2019/9/12 3:14 PM
 */
@Slf4j
public class LoginLinkUtils {

    public static LoginResponse notLogin(LoginResponse response) {
        if (response != null) {
            response.setCode(QtAdminRspCode.USER_NOT_LOGIN.getCode());
            response.setMsg(QtAdminRspCode.USER_NOT_LOGIN.getMsg());
            return response;
        } else {
            LoginResponse responseSysErr = new LoginResponse();
            log.error("Set user login status response error.");
            responseSysErr.setCode(QtAdminRspCode.ERR_PARAM_ERROR.getCode());
            responseSysErr.setMsg("系统参数错误");
            return responseSysErr;
        }
    }

    public static LoginResponse createUrl(LoginResponse response) {
        if (response != null) {
            response.setCode(QtAdminRspCode.SUCCESS.getCode());
            response.setMsg("登录链接获取成功");
            return response;
        } else {
            LoginResponse responseSysErr = new LoginResponse();
            log.error("Set login link response error.");
            responseSysErr.setCode(QtAdminRspCode.ERR_PARAM_ERROR.getCode());
            responseSysErr.setMsg("系统参数错误");
            return responseSysErr;
        }
    }
}
