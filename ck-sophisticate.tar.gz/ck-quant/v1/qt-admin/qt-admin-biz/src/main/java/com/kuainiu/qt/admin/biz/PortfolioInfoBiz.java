package com.kuainiu.qt.admin.biz;

import com.kuainiu.qt.admin.bean.trans.*;
import com.kuainiu.qt.admin.bean.trans.*;

public interface PortfolioInfoBiz {
    PortfolioOutBean qryPortfolio(PortfolioInBean inBean);

    StkTransListOutBean qryStkTrans(StkTransListInBean inBean);

    FuturesTransQryBean qryFuturesTrans(FuturesTransInBean inBean);
}
