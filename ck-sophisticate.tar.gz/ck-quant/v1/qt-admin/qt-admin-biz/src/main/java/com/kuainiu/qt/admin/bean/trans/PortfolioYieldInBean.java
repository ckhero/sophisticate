package com.kuainiu.qt.admin.bean.trans;

import com.kuainiu.qt.admin.bean.BaseQtAdminInBean;
import lombok.Data;

import java.util.Date;

@Data
public class PortfolioYieldInBean extends BaseQtAdminInBean {
    private String portfolioCode;
    private Integer pageNo;
    private Integer pageSize;
    private Date startBelongTime;
    private Date endBelongTime;
}
