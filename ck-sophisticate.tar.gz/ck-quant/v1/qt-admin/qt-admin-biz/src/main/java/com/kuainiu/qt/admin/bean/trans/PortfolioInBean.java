package com.kuainiu.qt.admin.bean.trans;

import com.kuainiu.qt.admin.bean.BaseQtAdminInBean;
import lombok.Data;

import java.util.Date;

@Data
public class PortfolioInBean extends BaseQtAdminInBean {
    private String portfolioCode;
    private Date datetime;
    private String portfolioKey;
    private String strategyCode;
    private Date startBelongTime;
    private Date endBelongTime;
}
