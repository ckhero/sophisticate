package com.kuainiu.qt.admin.exception;

import com.kuainiu.qt.admin.code.QtAdminRspCode;
import com.kuainiu.qt.admin.common.util.CommonConstant;
import com.kuainiu.qt.admin.response.BaseQtAdminResponse;
import org.apache.commons.lang3.StringUtils;

import java.text.MessageFormat;

/**
 * 不需回滚异常
 */
//TODO
public class BizException extends Exception {

    private QtAdminRspCode qtAdminRspCode;

    private String code;

    private String msg;

    public BizException(QtAdminRspCode qtAdminRspCode){
        this.qtAdminRspCode = qtAdminRspCode;
        this.code = qtAdminRspCode.getCode();
        this.msg = qtAdminRspCode.getMsg();
    }

    public BizException(QtAdminRspCode qtAdminRspCode, Throwable t){
        super(t);
        this.qtAdminRspCode = qtAdminRspCode;
        this.code = qtAdminRspCode.getCode();
        this.msg = qtAdminRspCode.getMsg();
    }

    public BizException(QtAdminRspCode qtAdminRspCode, String msg, Throwable t){
        super(t);
        this.qtAdminRspCode = qtAdminRspCode;
        this.code = qtAdminRspCode.getCode();
        this.msg = qtAdminRspCode.getMsg();
        if (StringUtils.isNotBlank(msg)) {
            this.msg += CommonConstant.COMMA + msg;
        }
    }

    public BizException(QtAdminRspCode qtAdminRspCode, String msg){
        this.qtAdminRspCode = qtAdminRspCode;
        this.code = qtAdminRspCode.getCode();
        this.msg = qtAdminRspCode.getMsg();
        if (StringUtils.isNotBlank(msg)) {
            this.msg += CommonConstant.COMMA + msg;
        }
    }

    public void setCode(String code){
        this.code = code;
    }

    public String getCode(){
        return code;
    }

    public String getMsg(){
        return msg;
    }

    public void setMsg(String msg){
        this.msg = msg;
    }

    public void exceptionToResponse(BaseQtAdminResponse baseQtAdminResponse){
        baseQtAdminResponse.setCode(this.getCode());
        baseQtAdminResponse.setMsg(this.getMsg());
    }

    public BizException(String pattern, Object... arguments){
        super(MessageFormat.format(pattern, arguments));
    }
}
