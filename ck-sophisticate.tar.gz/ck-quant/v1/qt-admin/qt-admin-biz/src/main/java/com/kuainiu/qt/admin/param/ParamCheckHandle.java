package com.kuainiu.qt.admin.param;

import com.kuainiu.qt.admin.code.QtAdminRspCode;
import com.kuainiu.qt.admin.request.HistoryPortfolioYieldRequest;
import com.kuainiu.qt.admin.request.PortfolioInfoQryRequest;
import com.kuainiu.qt.admin.request.PortfolioYieldRequest;
import lombok.extern.slf4j.Slf4j;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/2
 * Time: 2:44 PM
 */
@Slf4j
public class ParamCheckHandle {
    public static void checkPortfolioInfoQryRequest(PortfolioInfoQryRequest request) {
        if(null == request.getPortfolioCode()){
            log.error(QtAdminRspCode.ERR_PARAM_PORTFOLIO_CODE_REQUIRED.getMsg());
        }
        if(!"strategy_key".equals(request.getStrategyCode())){
            log.error(QtAdminRspCode.ERR_PARAM_STRATEGY_CODE_REQUIRED.getMsg());
        }
    }

    public static void checkPortfolioYieldRequest(PortfolioYieldRequest request) {
        if(null == request.getPortfolioCode()){
            log.error(QtAdminRspCode.ERR_PARAM_PORTFOLIO_CODE_REQUIRED.getMsg());
        }
        if(!"strategy_key".equals(request.getStrategyCode())){
            log.error(QtAdminRspCode.ERR_PARAM_STRATEGY_CODE_REQUIRED.getMsg());
        }
    }

    public static void checkHistoryPortfolioYield(HistoryPortfolioYieldRequest request) {
        if(null == request.getPortfolioCode()){
            log.error(QtAdminRspCode.ERR_PARAM_PORTFOLIO_CODE_REQUIRED.getMsg());
        }
        if(!"strategy_key".equals(request.getStrategyCode())){
            log.error(QtAdminRspCode.ERR_PARAM_STRATEGY_CODE_REQUIRED.getMsg());
        }
    }
}
