package com.kuainiu.qt.admin.bean.trans;

import com.kuainiu.qt.admin.bean.BaseQtAdminInBean;
import lombok.Data;

@Data
public class HistoryPortfolioYieldInBean extends BaseQtAdminInBean {
    private String portfolioCode;    
}
