package com.kuainiu.qt.admin.biz.impl;

import com.kuainiu.qt.admin.bean.trans.StkOrderCommitBizInBean;
import com.kuainiu.qt.admin.bean.trans.StkOrderCommitBizOutBean;
import com.kuainiu.qt.admin.biz.StkTradeBiz;
import com.kuainiu.qt.admin.code.QtAdminRspCode;
import com.kuainiu.qt.admin.exception.BizException;
import com.kuainiu.qt.admin.exception.ServiceException;
import com.kuainiu.qt.admin.service.QtCoreStkTradeService;
import com.kuainiu.qt.admin.service.bean.trans.StkTradeReqSerBean;
import com.kuainiu.qt.admin.service.bean.trans.StkTradeSerBean;
import com.kuainiu.qt.admin.util.StkTradeUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-26
 * Time: 17:25
 */
@Service
@Slf4j
public class StkTradeBizImpl implements StkTradeBiz {

    @Autowired
    QtCoreStkTradeService qtCoreStkTradeService;

    @Override
    public StkOrderCommitBizOutBean stkOrderCommit(StkOrderCommitBizInBean inBean) throws BizException {
        StkOrderCommitBizOutBean outBean;
        try {
            StkTradeReqSerBean reqSerBean=StkTradeUtils.buildStkTradeReqSerBean(inBean);
            StkTradeSerBean serBean=qtCoreStkTradeService.stkOrderCommit(reqSerBean);
            outBean = StkTradeUtils.buildStkOrderCommitBizOutBean(serBean);
        } catch (ServiceException e) {
            throw new BizException(QtAdminRspCode.ERR_STK_ORDER_COMMIT_FAIL);
        }
        return outBean;
    }
}
