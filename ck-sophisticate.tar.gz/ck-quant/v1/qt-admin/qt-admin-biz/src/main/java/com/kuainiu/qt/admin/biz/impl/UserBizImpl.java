package com.kuainiu.qt.admin.biz.impl;


import com.kuainiu.qt.admin.biz.UserBiz;
import com.kuainiu.qt.admin.response.UserInfoResponse;
import com.kuainiu.qt.admin.response.UserLoginResponse;
import com.kuainiu.qt.admin.util.IdWorker;
import com.kuainiu.qt.admin.util.UserUtils;
import com.kuainiu.qt.auth.bean.User;
import com.kuainiu.qt.auth.facade.UserOperatorFacade;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

/**
 * @author chengqiang
 * @Classname UserLoginImpl
 * @Description TODO
 * @Created by chengqiang
 * @Date 2019/9/11 11:34 AM
 */
@Service
@Slf4j
public class UserBizImpl implements UserBiz {

    @Reference
    private UserOperatorFacade userSerive;

    @Value("${iworker.worker.id}")
    private Integer workerId;

    @Value("${iworker.datacenter.id}")
    private Integer datacenterId;

    @Value("${frontend.redirect.uri}")
    private String redirectUri;

    @Value("${user.version:02}")
    private String userVersion;

    @Autowired
    private RedisConnectionFactory redisConnectionFactory;

    @Bean
    public IdWorker idWorker() {
        return new IdWorker(workerId, datacenterId);
    }

    @Resource
    RedisTemplate<String, User> redisTemplate;

    @Override
    public UserInfoResponse getLoginResult(String tempCode) {

        UserInfoResponse userInfoResponse = new UserInfoResponse();
        User user = userSerive.getUserByPassport(tempCode);
        userInfoResponse.setData(user);
        if (user != null) {
            if (!"VALID".equals(user.getStatus())) {
                return UserUtils.unauthrized(userInfoResponse);
            } else {
                return UserUtils.succeed(userInfoResponse);
            }
        }
        return UserUtils.failed(userInfoResponse);
    }

    @Override
    public UserInfoResponse unauthorizedUser(User user) {
        UserInfoResponse userInfoResponse = new UserInfoResponse();
        userInfoResponse.setData(user);
        return UserUtils.unauthrized(userInfoResponse);
    }

    @Override
    public UserInfoResponse loginSuccess(User user) {
        UserInfoResponse userInfoResponse = new UserInfoResponse();
        userInfoResponse.setData(user);
        return UserUtils.succeed(userInfoResponse);
    }

    @Override
    public String getFrontEndRedirectUri() {
        return this.redirectUri;
    }

    @Override
    public User getUserById(int id) {
        return userSerive.findUserById(id);
    }

    @Override
    public void saveUserInfoToCache(String uuid, User user) {
        log.info("Save User:{} to redis for key :{}", user.toString() + userVersion, uuid);
        redisTemplate.opsForValue().set(uuid.toString() + userVersion, user, 60 * 60 * 24 * 7, TimeUnit.SECONDS);
    }

    @Override
    public UserLoginResponse qryUserLoginInfo(String username) {
        return null;
    }

    @Override
    public String getUUID(String tempCode) {

        User user = userSerive.getUserByPassport(tempCode);
        Long uuid = idWorker().nextId();
        log.info("Generate UUID: {}, user info version: {}", uuid, userVersion);
        //set uuid:user basic information in redis, expire time is 7 days
        redisTemplate.opsForValue().set(uuid.toString() + userVersion, user, 60 * 60 * 24 * 7, TimeUnit.SECONDS);
        return uuid.toString();
    }

    @Override
    public String getEeQrUrl() {
        return userSerive.getQrCodeUrl();
    }
}
