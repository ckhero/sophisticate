package com.kuainiu.qt.admin.bean.trans;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class StkTransOutBean {
    private String qtOrderId;
    private String qtTransId;
    private String channelTransId;
    private String assetNo;
    private Integer transQty;
    private BigDecimal transPrice;
    private BigDecimal transCost;
    private String submitStatus;
    private String status;
    private Date transTime;
    //股票
    private String transSide;
    private String accountCode;
    private String isWithdraw;
}
