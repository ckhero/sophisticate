package com.kuainiu.qt.admin.bean.trans;


import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-26
 * Time: 17:19
 */
@Data
public class StkOrderCommitBizOutBean {
    private String frontOrderId;

    private String qtOrderId;
}
