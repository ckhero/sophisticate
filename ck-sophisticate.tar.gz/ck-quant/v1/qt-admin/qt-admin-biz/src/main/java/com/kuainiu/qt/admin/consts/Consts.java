package com.kuainiu.qt.admin.consts;

public class Consts {
    //用于查询trans的rp
    public static Integer PAGE_NO = 0;
    public static Integer PAGE_SIZE_PORTFOLIO = 300;
    //用于查询当天曲线
    public static Integer PAGE_SIZE_YIELD = 360;
}
