package com.kuainiu.qt.admin.util;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/2
 * Time: 2:44 PM
 */
public class BeanUtils {
}
