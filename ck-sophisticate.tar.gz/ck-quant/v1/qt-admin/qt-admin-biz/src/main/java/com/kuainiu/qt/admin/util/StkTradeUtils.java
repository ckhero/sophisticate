package com.kuainiu.qt.admin.util;

import com.kuainiu.qt.admin.bean.StkOrderCommitFacadeBean;
import com.kuainiu.qt.admin.bean.trans.StkOrderCommitBizInBean;
import com.kuainiu.qt.admin.bean.trans.StkOrderCommitBizOutBean;
import com.kuainiu.qt.admin.common.util.BeanMapUtils;
import com.kuainiu.qt.admin.common.util.CommonConstant;
import com.kuainiu.qt.admin.request.StkOrderCommitRequest;
import com.kuainiu.qt.admin.response.StkOrderCommitResponse;
import com.kuainiu.qt.admin.service.bean.trans.StkTradeReqSerBean;
import com.kuainiu.qt.admin.service.bean.trans.StkTradeSerBean;
import lombok.extern.slf4j.Slf4j;

/**
 * Created by IntelliJ IDEA.
 * User: Jixuan
 * Date: 2019-09-26
 * Time: 17:30
 */
@Slf4j
public class StkTradeUtils {
    public static StkOrderCommitBizInBean buildStkOrderCommitBizInBean(StkOrderCommitRequest request){
        StkOrderCommitBizInBean inBean=new StkOrderCommitBizInBean();
        BeanMapUtils.map(request, inBean);
        inBean.setAccessToken(CommonConstant.ACCESS_TOKEN);
        inBean.setChannelCode(CommonConstant.CHANNEL_CODE);
        inBean.setFrontOrderId(System.currentTimeMillis()+"");
        return inBean;
    }

    public static StkOrderCommitResponse buildStkOrderCommitResponse(StkOrderCommitBizOutBean outBean){
        StkOrderCommitResponse response = new StkOrderCommitResponse();
        StkOrderCommitFacadeBean data=new StkOrderCommitFacadeBean();
        BeanMapUtils.map(outBean, data);
        response.setData(data);
        return response;
    }

    public static StkTradeReqSerBean buildStkTradeReqSerBean(StkOrderCommitBizInBean inBean){
        StkTradeReqSerBean reqSerBean = new StkTradeReqSerBean();
        BeanMapUtils.map(inBean, reqSerBean);
        return reqSerBean;
    }

    public static StkOrderCommitBizOutBean buildStkOrderCommitBizOutBean(StkTradeSerBean serBean){
        StkOrderCommitBizOutBean outBean = new StkOrderCommitBizOutBean();
        BeanMapUtils.map(serBean, outBean);
        return outBean;
    }
}
