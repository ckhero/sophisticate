package com.kuainiu.qt.admin.bean;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/2
 * Time: 2:53 PM
 */
public class BaseQtAdminOutBean extends BaseOutBean {
}
