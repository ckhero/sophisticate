package com.kuainiu.qt.admin.biz;

import com.kuainiu.qt.admin.response.LoginResponse;

/**
 * @author chengqiang
 * @Classname LoginLink
 * @Description TODO
 * @Created by chengqiang
 * @Date 2019/9/12 2:23 PM
 */
public interface LoginBiz {
    LoginResponse getEeWeChatQrUrl();
    LoginResponse notLoginStatus();
    LoginResponse unauthorizedUser();
}
