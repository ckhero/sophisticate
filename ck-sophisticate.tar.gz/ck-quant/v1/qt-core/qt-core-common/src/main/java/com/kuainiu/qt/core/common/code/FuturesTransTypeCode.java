package com.kuainiu.qt.core.common.code;

import lombok.Data;

import java.util.Objects;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/5
 * Time: 3:04 PM
 */
public enum FuturesTransTypeCode {
    BUY_MARKET(100, "市价买"),
    BUY_LIMIT(101, "限价买"),
    SELL_MARKET(200, "市价卖"),
    SELL_LIMIT(201, "限价卖"),
    CANCEL(300, "委托撤销"),
    ;
    private Integer code;

    private String desc;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    FuturesTransTypeCode(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static FuturesTransTypeCode getNumByCode(Integer code) {
        if (null == code) {
            return null;
        }
        for (FuturesTransTypeCode futuresTransTypeCode: FuturesTransTypeCode.values()) {
            if (Objects.equals(futuresTransTypeCode.getCode(), code)) {
                return  futuresTransTypeCode;
            }
        }
        return null;
    }
}
