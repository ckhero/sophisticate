package com.kuainiu.qt.core.common.util;

/**
 * Description:通用静态变量类
 * Created by lucaszhuang .
 */
public class CommonConstant {
  
  /** 当前系统编号 */
  public static final String SYSTEM_NO2 = "30045";
  

  public final static String ENCODE = "UTF-8";
  
  /** 逗号: , */
  public static final String COMMA = ",";

  public static final String DATE_FORMAT = "yyyy-MM-dd";

  /** 零 */
  public static final int ZERO = 0;
  
  public static final int INVALID_NUMBER = -1;
  
  /** 左括号 */
  public static final String LEFT_BRACKET = "[";
  
  /** 右括号 */
  public static final String RIGHT_BRACKET = "]";
  
  /** 冒号 */
  public static final String COLON = ":";
  
  /** 默认编号 */
  public static final String DEFAULT_SEQNO = "-";
  
  /** 默认分页大小 */
  public static final int DEFAULT_BATCH_SIZE = 1000;
  
  /** 异常最长限制 */
  public static final int MAX_EXCEPTION_LEN = 1024;
  
  public static final int INT_ZERO = 0;
  
  public static final int INT_ONE = 1;
  
  public static final int INT_NEGATIVE_ONE = -1;
  
  public static final String DATEFORMAT = "yyyyMMdd";
  
  public static final String DDHHMM = "dd日HH时mm分";
  
  public static final String STRING_ZERO = "0";
  
  public static final String STRING_ONE = "1";
  
  public static final String DATEFORMAT_START = "yyyy-MM-dd 00:00:00";
  
  public static final String DATEFORMAT_END = "yyyy-MM-dd 23:59:59";
  
  public static final String DATEFORMAT_YMDHMS = "yyyy-MM-dd HH:mm:ss";

  public static final String STOCK_DAY_AM_PREPARETIME = "09:00:00";

  public static final String STOCK_DAY_AM_STARTTIME = "09:30:00";

  public static final String STOCK_DAY_AM_ENDTIME = "11:30:00";

  public static final String STOCK_DAY_PM_STARTTIME = "13:00:00";

  public static final String STOCK_DAY_PM_ENDTIME = "15:00:00";

  public static final String SUCCESS = "1000";
  
  public static final long LONG_ZERO = 0;
  
  public static final String SEQ_RES = "^[0-9, A-Z]*$";

  //暂时 这么写
  public static final int BUBBO_TIMEOUT = 200000;
  
}
