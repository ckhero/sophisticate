package com.kuainiu.qt.core.common.util;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/20
 * Time: 2:51 PM
 */
public class CalculateUtils {
    public static BigDecimal addBigDecimal(BigDecimal... objs) {
        BigDecimal result = BigDecimal.ZERO;
        for (BigDecimal obj: objs) {
            result = result.add(obj);
        }
        return  result;
    }

    public static Integer sum(Integer... objs) {
        Integer result = CommonConstant.ZERO;
        for (Integer obj: objs) {
            obj = null == obj ? CommonConstant.ZERO : obj;
            result += obj;
        }
        return  result;
    }
}
