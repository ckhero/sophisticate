package com.kuainiu.qt.core.common.code;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/14
 * Time: 7:42 PM
 */
public enum LogFormatCode {
    MODEL_STK_ORDER_ORIGIN_M("[MODEL - stkOrderOrigin]msg: {} ", "委托源数据[mb]"),
    MODEL_STK_ORDER_ORIGIN_M_D("[MODEL - stkOrderOrigin]msg: {} data: {}", "委托源数据[mb]"),

    STK_ORDER_COMMIT_M("[STK ORDER - commit]msg: {}", "委托[m]"),
    STK_ORDER_COMMIT_MARKET_M("[STK ORDER - commitMarket]msg: {}", "市价提交[m]"),
    STK_ORDER_COMMIT_MARKET_MRQ("[STK ORDER - commitMarket]msg: {} request {} response {}", "市价提交[mrq]"),
    STK_ORDER_COMMIT_LIMIT_M("[STK ORDER - commitLimit]msg: {}", "限价提交[m]"),
    STK_ORDER_COMMIT_LIMIT_MRQ("[STK ORDER - commitLimit]msg: {} request {} response {}", "限价提交[mrq]"),
    STK_ORDER_CANCEL_M("[STK ORDER - cancel]msg: {}", "撤销委托[m]"),
    STK_ORDER_CANCEL_MRQ("[STK ORDER - cancel]msg: {} request {} response {}", "撤销委托[mrq]"),
    STK_POSITION_QRY_M("[STK POSITION - qry]msg: {} request {} response {}", "仓位查询[m]"),
    STK_POSITION_QRY_MRQ("[STK POSITION - qry]msg: {} request {} response {}", "仓位查询[mrq]"),
    STK_ACCOUNT_QRY_M("[STK ACCOUNT - qry]msg: {} request {} response {}", "账户查询[m]"),
    STK_ACCOUNT_QRY_MRQ("[STK ACCOUNT - qry]msg: {} request {} response {}", "限账户查询价[mrq]"),

    STK_ORDER_QRY_RESPONSE("[STK ORDER - qry]reponse: {}", "查询委托"),
    STK_ORDER_QRY_M("[STK ORDER - qry]msg: {}", "查询委托[m]"),
    STK_ORDER_QRY_MRQ("[STK ORDER - qry]msg: {} request {} response {}", "查询委托[mrq]"),

    STK_PORTFOLIO_QRY_RESPONSE("[STK PORTFOLIO - qry]reponse: {}", "查询组合"),
    STK_PORTFOLIO_QRY_M("[STK PORTFOLIO - qry]msg: {}", "查询组合[m]"),
    STK_PORTFOLIO_QRY_MRQ("[STK PORTFOLIO - qry]msg: {} request {} response {}", "查询组合[mrq]"),

    FUTURES_ORDER_COMMIT_FAIL("[FUTURES ORDER - commit] fail", "委托[m]"),
    FUTURES_ORDER_COMMIT_M("[FUTURES ORDER - commit]msg: {}", "委托[m]"),
    FUTURES_ORDER_COMMIT_MRQ("[FUTURES ORDER - commit]msg: {} request {} response {}", "市价提交[mrq]"),

    FUTURES_ORDER_CANCEL_FAIL("[FUTURES ORDER - cancel] fail", "撤销委托[m]"),
    FUTURES_ORDER_CANCEL_M("[FUTURES ORDER - cancel]msg: {}", "撤销委托[m]"),
    FUTURES_ORDER_CANCEL_MRQ("[FUTURES ORDER - cancel]msg: {} request {} response {}", "撤销委托[mrq]"),

    FUTURES_POSITION_QRY_M("[FUTURES POSITION - qry]msg: {} request {} response {}", "仓位查询[m]"),
    FUTURES_POSITION_QRY_MRQ("[FUTURES POSITION - qry]msg: {} request {} response {}", "仓位查询[mrq]"),

    FUTURES_ACCOUNT_QRY_M("[FUTURES ACCOUNT - qry]msg: {} request {} response {}", "账户查询[m]"),
    FUTURES_ACCOUNT_QRY_MRQ("[FUTURES ACCOUNT - qry]msg: {} request {} response {}", "限账户查询价[mrq]"),

    FUTURES_ORDER_QRY_RESPONSE("[FUTURES ORDER - qry]reponse: {}", "查询委托"),
    FUTURES_ORDER_QRY_M("[FUTURES ORDER - qry]msg: {}", "查询委托[m]"),
    FUTURES_ORDER_QRY_MRQ("[FUTURES ORDER - qry]msg: {} request {} response {}", "查询委托[mrq]"),

    FUTURES_ORDER_ORIGIN_M_BEAN("FUTURES ORDER ORIGIN]msg: {} bean {}", "期货委托原始数据[m]"),

    STRATEGY_QRY_MAP("[FUTURES ORDER - commit]msg: {} request {} response {}", "策略查询[mrq]"),
    ;
    private String format;

    private String desc;

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    LogFormatCode(String format, String desc) {
        this.format = format;
        this.desc = desc;
    }
}
