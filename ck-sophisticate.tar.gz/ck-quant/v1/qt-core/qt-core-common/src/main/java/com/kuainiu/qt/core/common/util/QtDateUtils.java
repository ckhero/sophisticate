package com.kuainiu.qt.core.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/11/8
 * Time: 11:19 AM
 */
public class QtDateUtils {

    public static boolean isInMarketTime() {
        Date date = new Date();
        String day = dateFormatStr(date);
        String amStartStr = day + " " + CommonConstant.STOCK_DAY_AM_PREPARETIME;
        String amEndStr = day + " " + CommonConstant.STOCK_DAY_AM_ENDTIME;
        String pmStartStr = day + " " + CommonConstant.STOCK_DAY_PM_STARTTIME;
        String pmEndStr = day + " " + CommonConstant.STOCK_DAY_PM_ENDTIME;
        Date amStartTime = secondStrFormatDate(amStartStr);
        Date amEndTime = secondStrFormatDate(amEndStr);
        Date pmStartTime = secondStrFormatDate(pmStartStr);
        Date pmEndTime = secondStrFormatDate(pmEndStr);

        if ((!date.after(amEndTime) && !date.before(amStartTime)) || (!date.after(pmEndTime) && !date.before(pmStartTime))) {
            return true;
        } else {
            return false;
        }
    }

    public static String dateFormatStr(Date date) {
        SimpleDateFormat format = new SimpleDateFormat(CommonConstant.DATE_FORMAT);
        String day = format.format(date);
        return day;
    }

    public static Date secondStrFormatDate(String time) {
        Date date = null;
        try {
            SimpleDateFormat format = new SimpleDateFormat(CommonConstant.DATEFORMAT_YMDHMS);
            date = format.parse(time);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

}
