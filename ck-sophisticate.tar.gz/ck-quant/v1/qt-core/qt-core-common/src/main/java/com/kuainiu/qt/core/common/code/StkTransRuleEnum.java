package com.kuainiu.qt.core.common.code;

/**
 * Created by lucaszhuang.
 */
public enum StkTransRuleEnum {

    STK_PA_MARKET("stkOrderCommitMarket", "平安证券市价交易"),
    STK_PA_LIMIT("stkOrderCommitLimit", "平安证券限价交易"),
    STK_PA_LIMIT_QK("stkOrderCommitLimitQk", "平安证券限价快速"),
    STK_PA_CANCEL("stkOrderCommitCancel", "平安证券委托取消");

    private String code;

    private String desc;

    StkTransRuleEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static StkTransRuleEnum getStkTransRuleEnumByCode(String code) {
        if (null == code){
            return null;
        }
        for (StkTransRuleEnum stkTransRuleEnum : StkTransRuleEnum.values()) {
            if (code.equals(stkTransRuleEnum.getCode())) {
                return stkTransRuleEnum;
            }
        }
        return null;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
