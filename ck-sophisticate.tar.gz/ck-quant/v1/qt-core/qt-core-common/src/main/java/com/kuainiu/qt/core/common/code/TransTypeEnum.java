package com.kuainiu.qt.core.common.code;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/17
 * Time: 11:58 AM
 */
public enum  TransTypeEnum {

    MARKET_BUY(100, "市价买入"),

    OPTIMAL_REMNANT_TRANS_BUY(101, "最优成交剩撤买入"),

    LIMIT_PRICE_BUY(110, "限价买入"),

    MARKET_SELL(200, "市价卖出"),

    OPTIMAL_REMNANT_TRANS_SELL(201, "最优成交剩撤卖出"),

    LIMIT_PRICE_SELL(210, "限价卖出"),

    TRANS_CANCEL(300, "委托撤销");

    private int code;

    private String desc;

    TransTypeEnum(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static TransTypeEnum getTransTypeByCode(int code) {
        if (0 == code){
            return null;
        }
        for (TransTypeEnum transType : TransTypeEnum.values()) {
            if (transType.getCode() == code) {
                return transType;
            }
        }
        return null;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
