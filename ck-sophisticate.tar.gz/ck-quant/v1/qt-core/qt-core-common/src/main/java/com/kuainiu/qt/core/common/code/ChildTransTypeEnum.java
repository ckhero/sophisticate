package com.kuainiu.qt.core.common.code;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/17
 * Time: 2:58 PM
 */
public enum ChildTransTypeEnum {

    DEFAULT(0, "指定手数"),

    MARKET(11, "指定金额"),

    PERCENT(12, "指定比例"),

    LOTS(13, "指定手数");

    private int code;

    private String desc;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    ChildTransTypeEnum(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static ChildTransTypeEnum getChildTransTypeByCode(int code) {
        if (0 == code){
            return null;
        }
        for (ChildTransTypeEnum childTransType : ChildTransTypeEnum.values()) {
            if (childTransType.getCode() == code) {
                return childTransType;
            }
        }
        return null;
    }
}
