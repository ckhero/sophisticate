package com.kuainiu.qt.core.common.code;

import org.apache.commons.lang3.StringUtils;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/7
 * Time: 5:29 PM
 */
public enum FuturesPositionEffectCode {
    OPEN("OPEN", "开"),
    CLOSE_TODAY("CLOSE_TODAY", "平今"),
    CLOSE_YESTERDAY("CLOSE_YESTERDAY", "平昨"),
    ;
    private String code;

    private String desc;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    FuturesPositionEffectCode(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static FuturesPositionEffectCode getEnumByCode(String code) {
        if (null == code) {
            return null;
        }

        for (FuturesPositionEffectCode futuresPositionEffect: FuturesPositionEffectCode.values()) {
            if (StringUtils.equals(code, futuresPositionEffect.getCode())) {
                return futuresPositionEffect;
            }
        }
        return null;
    }
}
