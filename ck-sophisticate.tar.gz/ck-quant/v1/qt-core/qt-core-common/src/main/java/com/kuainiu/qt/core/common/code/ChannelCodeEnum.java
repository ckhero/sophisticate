package com.kuainiu.qt.core.common.code;

/**
 * Created by lucaszhuang.
 * 渠道号枚举，1期限定
 */
public enum ChannelCodeEnum {

    STK_PA("PA", "平安证券"),
    STK_ZT("ZT", "中泰证券"),
   ;

    private String code;

    private String desc;

    ChannelCodeEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static ChannelCodeEnum getChannelCodeByCode(String code) {
        if (null == code){
            return null;
        }
        for (ChannelCodeEnum channelCodeEnum : ChannelCodeEnum.values()) {
            if (code.equals(channelCodeEnum.getCode())) {
                return channelCodeEnum;
            }
        }
        return null;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
