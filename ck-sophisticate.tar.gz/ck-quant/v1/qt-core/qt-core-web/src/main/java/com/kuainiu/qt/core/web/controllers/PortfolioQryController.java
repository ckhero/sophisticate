package com.kuainiu.qt.core.web.controllers;

import com.kuainiu.qt.core.facade.core.PortfolioQryFacade;
import com.kuainiu.qt.core.facade.request.PortfolioQryRequest;
import com.kuainiu.qt.core.facade.response.PortfolioQryResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/17
 * Time: 9:27 PM
 */
@RestController
@RequestMapping(value = "portifolio")
public class PortfolioQryController {

    @Autowired
    PortfolioQryFacade portfolioQryFacade;

    @PostMapping(value="/qryPortfolio",produces = "application/json;charset=UTF-8")
    public PortfolioQryResponse qryPortfolio(@RequestBody PortfolioQryRequest queryRequest){
        PortfolioQryResponse response = portfolioQryFacade.qryPortfolio(queryRequest);
        return response;
    }

}
