package com.kuainiu.qt.core.web.controllers;

import com.kuainiu.qt.core.facade.core.FuturesOrderFacade;
import com.kuainiu.qt.core.facade.request.FuturesOrderCommitRequest;
import com.kuainiu.qt.core.facade.response.FuturesOrderCommitResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/5
 * Time: 3:30 PM
 */
@RestController
@RequestMapping("/futuresOrder")
public class FuturesOrderController {

    @Autowired
    FuturesOrderFacade futuresOrderFacade;

    @PostMapping(value="/futuresOrderCommit",produces = "application/json;charset=UTF-8")
    public FuturesOrderCommitResponse futuresOrderCommit(@RequestBody FuturesOrderCommitRequest request){

        FuturesOrderCommitResponse response = futuresOrderFacade.commitFuturesOrder(request);
        return response;
    }
}
