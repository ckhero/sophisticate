package com.kuainiu.qt.core.web.controllers;

import com.kuainiu.qt.core.facade.core.FuturesQryFacade;
import com.kuainiu.qt.core.facade.request.FuturesAccountQryRequest;
import com.kuainiu.qt.core.facade.request.FuturesOrderQryRequest;
import com.kuainiu.qt.core.facade.request.FuturesPositionQryRequest;
import com.kuainiu.qt.core.facade.response.FuturesAccountQryResponse;
import com.kuainiu.qt.core.facade.response.FuturesOrderQryResponse;
import com.kuainiu.qt.core.facade.response.FuturesPositionQryResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/7
 * Time: 10:54 AM
 */
@RestController
@RequestMapping("futuresQry")
public class FuturesQryController
{
    @Autowired
    FuturesQryFacade futuresQryFacade;

    @PostMapping(value="/order",produces = "application/json;charset=UTF-8")
    public FuturesOrderQryResponse qryFuturesOrder(@RequestBody FuturesOrderQryRequest request){

        FuturesOrderQryResponse response = futuresQryFacade.qryFuturesOrder(request);
        return response;
    }

    @PostMapping(value="/account",produces = "application/json;charset=UTF-8")
    public FuturesAccountQryResponse qryFuturesAccount(@RequestBody FuturesAccountQryRequest request){

        FuturesAccountQryResponse response = futuresQryFacade.qryFuturesAccount(request);
        return response;
    }

    @PostMapping(value="/position",produces = "application/json;charset=UTF-8")
    public FuturesPositionQryResponse qryFuturesPosition(@RequestBody FuturesPositionQryRequest request){

        FuturesPositionQryResponse response = futuresQryFacade.qryFuturesPosition(request);
        return response;
    }
}
