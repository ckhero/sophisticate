package com.kuainiu.qt.core.web.controllers;

import com.kuainiu.qt.core.facade.core.StkOrderQueryFacade;
import com.kuainiu.qt.core.facade.request.StkAccountQueryRequest;
import com.kuainiu.qt.core.facade.request.StkOrderQueryRequest;
import com.kuainiu.qt.core.facade.request.StkPositionQueryRequest;
import com.kuainiu.qt.core.facade.response.StkAccountQueryResponse;
import com.kuainiu.qt.core.facade.response.StkOrderQueryResponse;
import com.kuainiu.qt.core.facade.response.StkPositionQueryResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/24
 * Time: 4:17 PM
 */
@RestController
@RequestMapping("/stkorder")
public class StkQryController {
    @Autowired
    StkOrderQueryFacade stkOrderQueryFacade;

    /**
     * 股票账户查询
     * @param queryRequest
     * @return
     */
    @PostMapping(value="/queryStkAccount",produces = "application/json;charset=UTF-8")
    public StkAccountQueryResponse queryStkAccount(@RequestBody StkAccountQueryRequest queryRequest){
        return stkOrderQueryFacade.queryStkAccount(queryRequest);
    }

    @PostMapping(value="/queryStkOrder",produces = "application/json;charset=UTF-8")
    public StkOrderQueryResponse queryStkOrder(@RequestBody StkOrderQueryRequest queryRequest){
        return stkOrderQueryFacade.queryStkOrder(queryRequest);
    }

    /**
     * 股票仓位查询
     * @param queryRequest
     * @return
     */
    @PostMapping(value="/queryStkPosition",produces = "application/json;charset=UTF-8")
    public StkPositionQueryResponse queryStkPosition(@RequestBody StkPositionQueryRequest queryRequest) {

        return stkOrderQueryFacade.queryStkPosition(queryRequest);
    }
}
