package com.kuainiu.qt.core.web;

import com.alibaba.nacos.spring.context.annotation.config.NacosPropertySource;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.annotation.PostConstruct;
import java.util.TimeZone;

@SpringBootApplication(scanBasePackages = "com.kuainiu.qt.core")
@MapperScan("com.kuainiu.qt.core.dal.dao")
@NacosPropertySource(dataId = "com.kuainiu.qt-core.properties",groupId = "application")
public class QtCoreWebApplication {

    @PostConstruct
    void started() {
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
    }

    public static void main(String[] args) {
        SpringApplication.run(QtCoreWebApplication.class, args);
    }

}
