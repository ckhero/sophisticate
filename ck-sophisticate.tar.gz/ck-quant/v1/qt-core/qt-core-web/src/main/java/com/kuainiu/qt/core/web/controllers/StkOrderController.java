package com.kuainiu.qt.core.web.controllers;

import com.kuainiu.qt.core.facade.core.StkOrderFacade;
import com.kuainiu.qt.core.facade.request.*;
import com.kuainiu.qt.core.facade.response.StkOrderCommitResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/stkorder")
public class StkOrderController {

    @Autowired
    StkOrderFacade stkOrderFacade;

    @PostMapping(value="/stkOrderCommit",produces = "application/json;charset=UTF-8")
    public StkOrderCommitResponse stkOrderCommit(@RequestBody StkOrderCommitRequest commitRequest){
        StkOrderCommitResponse commitResponse = stkOrderFacade.stkOrderCommit(commitRequest);
        return commitResponse;
    }

}
