package com.kuainiu.qt.core.web.controllers;

import com.kuainiu.qt.core.facade.core.StrategyQryFacade;
import com.kuainiu.qt.core.facade.request.StrategyQryMapRequest;
import com.kuainiu.qt.core.facade.response.StrategyQryMapResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/strategy")
public class StrategyController {
    @Autowired
    StrategyQryFacade strategyQryFacade;

    @PostMapping(value="/qryByPf",produces = "application/json;charset=UTF-8")
    StrategyQryMapResponse qryByPf(@RequestBody StrategyQryMapRequest request) {
        return strategyQryFacade.qryMapByPortfolioCode(request);
    }
}
