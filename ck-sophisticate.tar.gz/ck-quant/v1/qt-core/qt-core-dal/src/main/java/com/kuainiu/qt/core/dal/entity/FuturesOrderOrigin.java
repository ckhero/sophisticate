package com.kuainiu.qt.core.dal.entity;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class FuturesOrderOrigin {
    private Long id;

    private String frontOrderId;

    private String sysId;

    private String portfolioCode;

    private String strategyCode;

    private String assetNo;

    private String channelCode;

    private Integer transType;

    private String positionEffect;

    private String transSide;

    private BigDecimal limitPrice;

    private Integer orderQty;

    private Date createTime;

    private Date updateTime;
}