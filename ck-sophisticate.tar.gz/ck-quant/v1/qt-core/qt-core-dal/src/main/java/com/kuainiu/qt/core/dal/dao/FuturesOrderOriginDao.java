package com.kuainiu.qt.core.dal.dao;

import com.kuainiu.qt.core.dal.entity.FuturesOrderOrigin;

public interface FuturesOrderOriginDao {
    int deleteByPrimaryKey(Long id);

    int insert(FuturesOrderOrigin record);

    int insertSelective(FuturesOrderOrigin record);

    FuturesOrderOrigin selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(FuturesOrderOrigin record);

    int updateByPrimaryKey(FuturesOrderOrigin record);
}