package com.kuainiu.qt.core.dal.entity;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class OrderStkOrigin {
    private Long id;

    private String frontOrderId;

    private String sysId;

    private String portfolioCode;

    private String strategyCode;

    private String assetNo;

    private String transBoard;

    private String channelCode;

    private Integer transType;

    private String transSide;

    private BigDecimal limitPrice;

    private Integer amount;

    private Date createTime;

    private Date updateTime;
}