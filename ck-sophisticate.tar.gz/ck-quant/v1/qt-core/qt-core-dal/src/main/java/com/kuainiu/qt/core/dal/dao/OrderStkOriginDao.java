package com.kuainiu.qt.core.dal.dao;

import com.kuainiu.qt.core.dal.entity.OrderStkOrigin;

public interface OrderStkOriginDao {
    int deleteByPrimaryKey(Long id);

    int insert(OrderStkOrigin record);

    int insertSelective(OrderStkOrigin record);

    OrderStkOrigin selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(OrderStkOrigin record);

    int updateByPrimaryKey(OrderStkOrigin record);
}