package com.kuainiu.qt.core.facade.response;

import com.kuainiu.qt.core.facade.bean.FuturesPositionFacadeBean;
import lombok.Data;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/6
 * Time: 2:57 PM
 */
@Data
public class FuturesPositionQryResponse  extends BaseCoreResponse{
    private FuturesPositionFacadeBean data;
}
