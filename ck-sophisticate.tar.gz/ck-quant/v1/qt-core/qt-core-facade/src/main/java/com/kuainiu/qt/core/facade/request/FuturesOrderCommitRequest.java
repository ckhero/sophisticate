package com.kuainiu.qt.core.facade.request;

import lombok.Data;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/4
 * Time: 9:11 PM
 */
@Data
public class FuturesOrderCommitRequest extends BaseCoreRequest {
    /**
     * 前置委托编号
     */
    private String frontOrderId;

    /**
     * 投资组合编号
     */
    private String portfolioCode;

    private String strategyCode;

    /**
     * token
     */
    private String accessToken;

    /**
     * 股票代码
     */
    private String assetNo;

    /**
     * 渠道号[PASH:平安上证;PASZ:平安深证]
     */
    private String channelCode;

    /**
     * 委托类型[100:市价多头(默认策略) 101:市价空头 110:限价多头 111:限价空头 300:委托撤销]
     */
    private Integer transType;

    /**
     * 限价(单位：分)，限价买入卖出时必填
     */
    private BigDecimal limitPrice;

    /**
     * 委托数量（单位：手），指定手数时必填
     */
    private Integer orderQty;

    private String positionEffect;
}
