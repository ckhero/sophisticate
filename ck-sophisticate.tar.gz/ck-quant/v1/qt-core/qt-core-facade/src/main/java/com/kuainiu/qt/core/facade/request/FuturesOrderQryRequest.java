package com.kuainiu.qt.core.facade.request;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/7
 * Time: 10:36 AM
 */
@Data
public class FuturesOrderQryRequest extends BaseCoreRequest {
    private String frontOrderId;

}
