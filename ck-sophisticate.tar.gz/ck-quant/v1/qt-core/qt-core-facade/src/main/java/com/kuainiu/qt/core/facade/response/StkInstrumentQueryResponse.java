package com.kuainiu.qt.core.facade.response;

import com.kuainiu.qt.core.facade.bean.StkInstrumentQueryFacadeBean;
import lombok.Data;

/**
 * 股票合约查询
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/22
 * Time: 8:50 PM
 */
@Data
public class StkInstrumentQueryResponse extends BaseCoreResponse {

    private StkInstrumentQueryFacadeBean data;
}
