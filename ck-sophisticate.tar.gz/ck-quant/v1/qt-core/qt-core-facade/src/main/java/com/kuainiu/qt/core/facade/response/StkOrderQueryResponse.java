package com.kuainiu.qt.core.facade.response;

import com.kuainiu.qt.core.facade.bean.StkOrderCommitFacadeBean;
import com.kuainiu.qt.core.facade.bean.StkOrderQryFacadeBean;
import lombok.Data;

@Data
public class StkOrderQueryResponse extends BaseCoreResponse {

    private StkOrderQryFacadeBean data;
}
