package com.kuainiu.qt.core.facade.request;

import lombok.Data;

/**
 * 股票账户查询(入参)
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/22
 * Time: 8:47 PM
 */
@Data
public class StkAccountQueryRequest extends BaseCoreRequest{

    private String portfolioCode;

    private String strategyCode;

    private String accountCode;
}
