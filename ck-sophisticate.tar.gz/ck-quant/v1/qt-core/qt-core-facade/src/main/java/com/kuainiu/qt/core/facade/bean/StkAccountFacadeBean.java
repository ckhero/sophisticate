package com.kuainiu.qt.core.facade.bean;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.kuainiu.qt.core.facade.serializer.MoneySerializer;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/27
 * Time: 5:58 PM
 */
@Data
public class StkAccountFacadeBean extends BaseFacadeBean {
    private String portfolioCode;

    private String strategyCode;

    private String accountCode;
    /**
     * 可用余额
     */
    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal cash;

    /**
     * 冻结余额
     */
    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal frzCash;

    /**
     * 市值，单位(元)
     */
    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal marketValue;

    /**
     * 总权益，单位(元)
     */
    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal totalValue;

    /**
     * 当日费用明细
     */
    private StkFeeFacadeBean transactionCost;

    /**
     * 账户下的仓位
     */
    private List<StkPositionFacadeBean> positions;

}
