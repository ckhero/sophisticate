package com.kuainiu.qt.core.facade.response;

import lombok.Data;

@Data
public class StrategyResponseBean {

    private String strategyCode;

    private String strategyType;

    private String portfolioCode;

    private String status;

    private String accountType;

    private String accountCode;

    private String accountStatus;
}
