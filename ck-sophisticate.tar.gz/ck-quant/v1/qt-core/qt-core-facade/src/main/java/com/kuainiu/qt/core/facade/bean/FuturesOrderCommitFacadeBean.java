package com.kuainiu.qt.core.facade.bean;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/22
 * Time: 5:01 PM
 */
@Data
public class FuturesOrderCommitFacadeBean {
    private String qtOrderId;

    private String frontOrderId;
}

