package com.kuainiu.qt.core.facade.bean;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.kuainiu.qt.core.facade.serializer.MoneySerializer;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/4
 * Time: 9:17 PM
 */
@Data
public class FuturesOrderFacadeBean {
    private String portfolioCode;

    private String strategyCode;

    private String qtOrderId;

    private String frontOrderId;

    private String channelOrderId;

    private String futuresType;

    private String assetNo;

    private String channelCode;

    private String priceMode;

    private String positionEffect;

    private String transSide;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal limitPrice;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal avgPrice;

    private Integer orderQty;

    private Integer filledQty;

    private Integer unfilledQty;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal transCost;

    private String orderStatus;

    private Date orderCreateTime;

    private String message;
}
