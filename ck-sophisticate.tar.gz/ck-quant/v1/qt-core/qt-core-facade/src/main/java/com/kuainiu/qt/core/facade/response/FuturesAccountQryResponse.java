package com.kuainiu.qt.core.facade.response;

import com.kuainiu.qt.core.facade.bean.FuturesAccountFacadeBean;
import lombok.Data;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/6
 * Time: 2:44 PM
 */
@Data
public class FuturesAccountQryResponse extends BaseCoreResponse {
    private FuturesAccountFacadeBean data;
}
