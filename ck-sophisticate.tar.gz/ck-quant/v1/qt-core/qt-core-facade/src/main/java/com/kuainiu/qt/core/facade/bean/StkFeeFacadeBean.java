package com.kuainiu.qt.core.facade.bean;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.kuainiu.qt.core.facade.serializer.MoneySerializer;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/22
 * Time: 9:02 PM
 */
@Data
public class StkFeeFacadeBean extends BaseFacadeBean {

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal feeTrade;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal feeTransfer;
    /**
     * 净佣金
     */
//    private BigDecimal feeJyj;

//    /**
//     * 佣金
//     */
//    @JsonSerialize(using = MoneySerializer.class)
//    private BigDecimal feeYj;

    /**
     * 印花税
     */
    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal feeYhs;

//    /**
//     * 过户费
//     */
//    private BigDecimal feeGhf;
//
//    /**
//     * 清算费
//     */
//    private BigDecimal feeQsf;
//
//    /**
//     * 交易规费
//     */
//    private BigDecimal feeJygf;
//
//    /**
//     * 经手费
//     */
//    private BigDecimal feeJsf;
//
//    /**
//     * 证管费
//     */
//    private BigDecimal feeZgf;
//
//    /**
//     * 其他费
//     */
//    private BigDecimal feeQtf;

}
