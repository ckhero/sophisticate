package com.kuainiu.qt.core.facade.response;

import com.kuainiu.qt.core.facade.bean.PortfolioQryFacadeBean;
import lombok.Data;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/17
 * Time: 9:10 PM
 */
@Data
public class PortfolioQryResponse extends BaseCoreResponse {
    private PortfolioQryFacadeBean data;
}
