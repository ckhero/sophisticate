package com.kuainiu.qt.core.facade.request;

/**
 * 股票交易委托查询
 */
public class StkOrderQueryRequest extends BaseCoreRequest{


    /**
     * 前置委托编号
     */
    private String frontOrderId;

    public String getFrontOrderId() {
        return frontOrderId;
    }

    public void setFrontOrderId(String frontOrderId) {
        this.frontOrderId = frontOrderId;
    }


}
