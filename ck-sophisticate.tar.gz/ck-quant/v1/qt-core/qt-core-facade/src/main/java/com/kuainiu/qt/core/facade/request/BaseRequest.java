package com.kuainiu.qt.core.facade.request;

import lombok.Data;

import java.io.Serializable;

@Data
public class BaseRequest implements Serializable {

    private static final long serialVersionUID = 323057881476834599L;

    private String sysId;
    private Boolean remote;
}
