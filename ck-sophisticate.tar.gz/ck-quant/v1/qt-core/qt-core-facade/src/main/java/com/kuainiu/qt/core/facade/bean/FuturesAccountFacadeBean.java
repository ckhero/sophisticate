package com.kuainiu.qt.core.facade.bean;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.kuainiu.qt.core.facade.serializer.MoneySerializer;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/6
 * Time: 3:06 PM
 */
@Data
public class FuturesAccountFacadeBean {
    private String portfolioCode;

    private String strategyCode;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal cash;

//    @JsonSerialize(using = MoneySerializer.class)
//    private BigDecimal frzCash;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal marketValue;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal dailyPnl;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal holdingPnl;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal realizedPnl;

//    @JsonSerialize(using = MoneySerializer.class)
//    private BigDecimal totalValue;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal transCost;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal frzMargin;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal margin;

    private List<FuturesPositionFacadeBean> positions;

}
