package com.kuainiu.qt.core.facade.response;

import com.kuainiu.qt.core.facade.bean.StkOrderCommitFacadeBean;

public class StkOrderCommitResponse extends BaseCoreResponse {

    private StkOrderCommitFacadeBean data;

    public StkOrderCommitFacadeBean getData() {
        return data;
    }

    public void setData(StkOrderCommitFacadeBean data) {
        this.data = data;
    }
}
