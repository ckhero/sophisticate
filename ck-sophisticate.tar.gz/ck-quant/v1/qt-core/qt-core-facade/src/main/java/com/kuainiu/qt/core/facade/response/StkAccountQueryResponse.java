package com.kuainiu.qt.core.facade.response;

import com.kuainiu.qt.core.facade.bean.StkAccountFacadeBean;
import lombok.Data;

/**
 * 股票账户查询
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/22
 * Time: 8:48 PM
 */
@Data
public class StkAccountQueryResponse extends BaseCoreResponse{
    private StkAccountFacadeBean data;
}
