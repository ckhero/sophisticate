package com.kuainiu.qt.core.facade.core;

import com.kuainiu.qt.core.facade.request.FuturesAccountQryRequest;
import com.kuainiu.qt.core.facade.request.FuturesOrderQryRequest;
import com.kuainiu.qt.core.facade.request.FuturesPositionQryRequest;
import com.kuainiu.qt.core.facade.response.FuturesAccountQryResponse;
import com.kuainiu.qt.core.facade.response.FuturesOrderQryResponse;
import com.kuainiu.qt.core.facade.response.FuturesPositionQryResponse;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/7
 * Time: 10:34 AM
 */
public interface FuturesQryFacade {
    FuturesPositionQryResponse qryFuturesPosition(FuturesPositionQryRequest request);

    FuturesAccountQryResponse qryFuturesAccount(FuturesAccountQryRequest request);

    FuturesOrderQryResponse qryFuturesOrder(FuturesOrderQryRequest request);
}
