package com.kuainiu.qt.core.facade.code;

import lombok.Getter;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/9/27
 * Time: 5:41 PM
 */
public enum FuturesOrderStatusCode {
    /**
     * order status: init
     */
    INIT("INIT", 0),
    /**
     * order status: waiting
     */
    WAIT_TRANS("WAIT_TRANS", 1),
    /**
     * order status: part in transaction
     */
    TRANSING("TRANSING", 2),
    /**
     * order status: part canceled
     */
    PART_CANCEL("PART_CANCEL", 3),
    /**
     * order status: all finished
     */
    FINISH("FINISH", 4),
    /**
     * order status: all canceled
     */
    CANCEL("CANCEL", 5),
    /**
     * order status: invalid/void
     */
    VOID("VOID", 6),
    ;
    @Getter
    private String code;

    @Getter
    private int rtnCode;

    FuturesOrderStatusCode(String code, int rtnCode) {
        this.code = code;
        this.rtnCode = rtnCode;
    }

    public void setCode(String code) {
        this.code = code;
    }


    public void setRtnCode(int rtnCode) {
        this.rtnCode = rtnCode;
    }

    public static FuturesOrderStatusCode getEnumCode(String code) {
        if (null == code) {
            return null;
        }

        for (FuturesOrderStatusCode status: FuturesOrderStatusCode.values()) {
            if (code.equals(status.getCode())) {
                return status;
            }
        }
        return  null;
    }

    public static int getRtnCode(String code) {
        FuturesOrderStatusCode orderStatusCode = getEnumCode(code);
        return orderStatusCode.getRtnCode();
    }
}
