package com.kuainiu.qt.core.facade.bean;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.kuainiu.qt.core.facade.serializer.MoneySerializer;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/17
 * Time: 9:19 PM
 */
@Data
public class CashflowFacadeBean extends BaseFacadeBean {

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal totalValue;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal cashflowValue;

    private Date actionTime;
}
