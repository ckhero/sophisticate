package com.kuainiu.qt.core.facade.bean;

import lombok.Data;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/27
 * Time: 6:03 PM
 */
@Data
public class StkOrderCommitFacadeBean extends BaseFacadeBean {
    private String frontOrderId;

    private String qtOrderId;
}
