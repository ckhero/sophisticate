package com.kuainiu.qt.core.facade.bean;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.kuainiu.qt.core.facade.serializer.MoneySerializer;
import lombok.Data;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/11
 * Time: 2:16 PM
 */
@Data
public class PositionFacadeBean extends BaseFacadeBean {
    /**
     * 股票代码
     */
    private String assetNo;

    /**
     * 证券余额
     */
    private Integer amount;

    /**
     * 证券可用数量
     */
    private Integer sellableAmount;
}
