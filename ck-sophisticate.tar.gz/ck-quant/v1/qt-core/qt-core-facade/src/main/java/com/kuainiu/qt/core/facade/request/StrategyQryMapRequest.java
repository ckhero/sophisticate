package com.kuainiu.qt.core.facade.request;

import lombok.Data;

@Data
public class StrategyQryMapRequest extends BaseCoreRequest {
    private String strategyCode;
}
