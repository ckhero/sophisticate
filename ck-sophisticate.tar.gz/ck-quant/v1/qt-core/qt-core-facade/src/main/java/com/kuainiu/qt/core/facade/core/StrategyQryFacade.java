package com.kuainiu.qt.core.facade.core;

import com.kuainiu.qt.core.facade.request.StrategyQryMapRequest;
import com.kuainiu.qt.core.facade.response.StrategyQryMapResponse;

public interface StrategyQryFacade {
    StrategyQryMapResponse qryMapByPortfolioCode(StrategyQryMapRequest request);
}
