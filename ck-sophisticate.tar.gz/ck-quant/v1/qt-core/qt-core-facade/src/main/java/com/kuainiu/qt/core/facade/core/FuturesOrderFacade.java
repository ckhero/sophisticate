package com.kuainiu.qt.core.facade.core;

import com.kuainiu.qt.core.facade.request.FuturesOrderCommitRequest;
import com.kuainiu.qt.core.facade.response.FuturesOrderCommitResponse;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/4
 * Time: 9:20 PM
 */
public interface FuturesOrderFacade {
    FuturesOrderCommitResponse commitFuturesOrder(FuturesOrderCommitRequest request);
}
