package com.kuainiu.qt.core.facade.core;

import com.kuainiu.qt.core.facade.request.StkAccountQueryRequest;
import com.kuainiu.qt.core.facade.request.StkOrderQueryRequest;
import com.kuainiu.qt.core.facade.request.StkPositionQueryRequest;
import com.kuainiu.qt.core.facade.response.StkAccountQueryResponse;
import com.kuainiu.qt.core.facade.response.StkOrderQueryResponse;
import com.kuainiu.qt.core.facade.response.StkPositionQueryResponse;

/**
 * 委托交易查询接口
 */
public interface StkOrderQueryFacade {

    StkOrderQueryResponse queryStkOrder(StkOrderQueryRequest queryStkOrderRequest);

    /**
     * 股票账户查询
     * @param accountRequest
     * @return
     */
    public StkAccountQueryResponse queryStkAccount(StkAccountQueryRequest accountRequest);

    /**
     * 股票仓位查询
     * @param positionRequest
     * @return
     */
    public StkPositionQueryResponse queryStkPosition(StkPositionQueryRequest positionRequest);
}
