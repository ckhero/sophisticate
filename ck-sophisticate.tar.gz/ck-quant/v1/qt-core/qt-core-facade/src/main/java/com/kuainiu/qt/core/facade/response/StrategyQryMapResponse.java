package com.kuainiu.qt.core.facade.response;

import lombok.Data;

import java.util.Map;

@Data
public class StrategyQryMapResponse extends BaseCoreResponse{
    private Map<String, StrategyResponseBean> data;
}
