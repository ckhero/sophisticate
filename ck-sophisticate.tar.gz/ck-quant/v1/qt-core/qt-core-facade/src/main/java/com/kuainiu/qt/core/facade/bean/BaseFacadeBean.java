package com.kuainiu.qt.core.facade.bean;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/27
 * Time: 6:00 PM
 */
public class BaseFacadeBean {
}
