package com.kuainiu.qt.core.facade.code;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/7/2
 * Time: 10:48 AM
 */
public enum QtCoreExternalRspCode {
    SUCCESS(0, "10", "处理成功"),
    ;

    @Setter
    @Getter
    private Integer code;

    @Setter
    @Getter
    private String sysCode;

    @Setter
    @Getter
    private String  msg;

    QtCoreExternalRspCode(Integer code, String sysCode, String msg) {
        this.code = code;
        this.sysCode = sysCode;
        this.msg = msg;
    }

    public static Integer getCodeBySysCode(String sysCode) {
        for (QtCoreExternalRspCode qtCoreExternalRspCode: QtCoreExternalRspCode.values()) {
            if (sysCode.equals(qtCoreExternalRspCode.getSysCode())) {
                return qtCoreExternalRspCode.getCode();
            }
        }
        return Integer.parseInt(sysCode);
    }
}
