package com.kuainiu.qt.core.facade.request;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/6
 * Time: 3:10 PM
 */
@Data
public class FuturesAccountQryRequest extends BaseCoreRequest {
    private String portfolioCode;

    private String strategyCode;
}
