package com.kuainiu.qt.core.facade.bean;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.kuainiu.qt.core.facade.serializer.MoneySerializer;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/17
 * Time: 9:18 PM
 */
@Data
public class PortfolioQryFacadeBean extends BaseFacadeBean {

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal cash;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal frzCash;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal totalReturns;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal realtimeReturns;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal dailyPnl;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal marketValue;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal totalValue;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal units;

    private List<CashflowFacadeBean> cashflows;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal transCost;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal pnl;

    private Date startDate;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal annualizedReturns;

    private PortfolioPositionFacadeBean positions = new PortfolioPositionFacadeBean();
}
