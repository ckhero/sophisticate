package com.kuainiu.qt.core.facade.request;

/**
 * 核心系统请求基础类
 */
public class BaseCoreRequest extends BaseRequest{
}
