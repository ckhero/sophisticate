package com.kuainiu.qt.core.facade.serializer;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/8/6
 * Time: 3:11 PM
 */
public class MoneySerializer extends JsonSerializer<BigDecimal> {
    public static final int SCALE_DEFAULT = 6;

    public static final RoundingMode ROUND_DEFAULT = RoundingMode.HALF_DOWN;

    @Override
    public void serialize(BigDecimal value, JsonGenerator jgen, SerializerProvider provider) throws IOException,
            JsonProcessingException {
        jgen.writeNumber(value.setScale(SCALE_DEFAULT, ROUND_DEFAULT));
    }
}