package com.kuainiu.qt.core.facade.bean;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.kuainiu.qt.core.facade.serializer.MoneySerializer;
import lombok.Data;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/6
 * Time: 3:06 PM
 */
@Data
public class FuturesPositionFacadeBean {
    private String portfolioCode;

    private String strategyCode;

    private String assetNo;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal pnl;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal dailyPnl;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal holdingPnl;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal realizedPnl;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal transCost;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal margin;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal frzMargin;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal marketValue;

    private Integer closableBuyQty;

    private Integer buyTodayQty;

    private Integer buyAccountTodayQty;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal buyAvgOpenPrice;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal buyAvgHoldingPrice;

    private Integer closableSellQty;

    private Integer sellTodayQty;

    private Integer sellAccountTodayQty;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal sellAvgOpenPrice;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal sellAvgHoldingPrice;
}
