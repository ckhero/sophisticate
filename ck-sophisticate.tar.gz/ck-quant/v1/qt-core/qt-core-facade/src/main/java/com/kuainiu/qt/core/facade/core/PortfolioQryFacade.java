package com.kuainiu.qt.core.facade.core;

import com.kuainiu.qt.core.facade.request.PortfolioQryRequest;
import com.kuainiu.qt.core.facade.response.PortfolioQryResponse;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/17
 * Time: 9:25 PM
 */
public interface PortfolioQryFacade {
    PortfolioQryResponse qryPortfolio(PortfolioQryRequest request);
}
