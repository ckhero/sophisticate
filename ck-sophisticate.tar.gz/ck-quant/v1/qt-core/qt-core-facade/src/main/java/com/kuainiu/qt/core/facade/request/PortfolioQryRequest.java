package com.kuainiu.qt.core.facade.request;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/17
 * Time: 9:08 PM
 */
@Data
public class PortfolioQryRequest extends BaseCoreRequest{
    private String portfolioCode;
}
