package com.kuainiu.qt.core.facade.response;

import com.kuainiu.qt.core.facade.bean.FuturesOrderFacadeBean;
import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/7
 * Time: 10:37 AM
 */
@Data
public class FuturesOrderQryResponse extends BaseCoreResponse {
    private FuturesOrderFacadeBean data;

}
