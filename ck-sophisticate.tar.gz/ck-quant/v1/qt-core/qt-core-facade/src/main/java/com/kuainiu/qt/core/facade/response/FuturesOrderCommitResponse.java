package com.kuainiu.qt.core.facade.response;

import com.kuainiu.qt.core.facade.bean.FuturesOrderCommitFacadeBean;
import com.kuainiu.qt.core.facade.bean.FuturesOrderFacadeBean;
import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/4
 * Time: 9:12 PM
 */
@Data
public class FuturesOrderCommitResponse extends BaseCoreResponse {
    private FuturesOrderCommitFacadeBean data;
}
