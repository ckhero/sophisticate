package com.kuainiu.qt.core.facade.bean;

import lombok.Data;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/17
 * Time: 9:22 PM
 */
@Data
public class PortfolioPositionFacadeBean extends BaseFacadeBean {

    private List<StkPositionFacadeBean> stkPositions;

    private List<FuturesPositionFacadeBean> futuresPositions;
}
