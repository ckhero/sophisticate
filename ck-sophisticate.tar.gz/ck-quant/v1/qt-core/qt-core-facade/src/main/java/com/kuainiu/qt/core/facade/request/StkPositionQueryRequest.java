package com.kuainiu.qt.core.facade.request;

import lombok.Data;

/**
 * 股票仓位查询
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/22
 * Time: 9:09 PM
 */
@Data
public class StkPositionQueryRequest extends BaseCoreRequest {

    /**
     * 股票代码
     */
    private String assetNo;

    private String portfolioCode;

    private String strategyCode;
}
