package com.kuainiu.qt.core.facade.response;

import lombok.Data;

import java.io.Serializable;

@Data
public class BaseResponse implements Serializable {

    private static final long serialVersionUID = -7532622290827455277L;

    private static final String SYSTEM_NAME = "[Core]";

    private String msg;

    private Integer code;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = SYSTEM_NAME + msg;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }
//
//    private Throwable exception;
}
