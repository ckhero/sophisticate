package com.kuainiu.qt.core.facade.bean;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.kuainiu.qt.core.facade.serializer.MoneySerializer;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/24
 * Time: 6:53 PM
 */
@Data
public class StkOrderQryFacadeBean {
    private String frontOrderId;

    private String qtOrderId;

    private String assetNo;

    private Date orderCreateTime;

    private String transSide;

    private String priceMode;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal limitPrice;

    private Integer orderQty;

    private Integer filledQty;

    private Integer unfilledQty;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal avgPrice;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal transCost;

    private String orderStatus;

    private String message;

    private String channelCode;

    private String portfolioCode;

    private String strategyCode;
}
