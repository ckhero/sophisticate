package com.kuainiu.qt.core.facade.response;

import com.kuainiu.qt.core.facade.code.QtCoreRspCode;

public class BaseCoreResponse extends BaseResponse {

    public void setErrorCodeAndException(QtCoreRspCode qtCoreErr, Throwable e) {
        //TODO
    }
}
