package com.kuainiu.qt.core.facade.request;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/6
 * Time: 3:11 PM
 */
@Data
public class FuturesPositionQryRequest extends BaseCoreRequest {
    private String assetNo;

    private String portfolioCode;

    private String strategyCode;

}

