package com.kuainiu.qt.core.facade.bean;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.kuainiu.qt.core.facade.serializer.MoneySerializer;
import lombok.Data;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/27
 * Time: 5:58 PM
 */
@Data
public class StkPositionFacadeBean extends BaseFacadeBean {
    private String portfolioCode;

    private String strategyCode;
    /**
     * 股票代码
     */
    private String assetNo;

    /**
     * 持仓数量，单位(股)
     */
    private Integer qty;

    /**
     * 累积持仓盈亏，单位(元)
     */
    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal pnl;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal dailyPnl;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal holdingPnl;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal realizedPnl;
    /**
     * 可交易股数，单位(股)
     */
    private Integer sellableQty;

    /**
     * 持仓市值，单位(元)
     */
    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal marketValue;

    /**
     * 持仓比例%
     */
    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal valuePercent;

    /**
     * 平均建仓成本，单位(元)
     */
    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal avgPrice;

}
