package com.kuainiu.qt.core.facade.bean;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/27
 * Time: 6:04 PM
 */
public class StkInstrumentQueryFacadeBean extends BaseFacadeBean {
    /**
     * 股票代码
     */
    private String assetNo;

    /**
     * 股票简称
     */
    private String assetName;

    private Integer status;

    private Integer level;

    private Integer suspended;

    public String getAssetNo() {
        return assetNo;
    }

    public void setAssetNo(String assetNo) {
        this.assetNo = assetNo;
    }

    public String getAssetName() {
        return assetName;
    }

    public void setAssetName(String assetName) {
        this.assetName = assetName;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Integer getSuspended() {
        return suspended;
    }

    public void setSuspended(Integer suspended) {
        this.suspended = suspended;
    }
}
