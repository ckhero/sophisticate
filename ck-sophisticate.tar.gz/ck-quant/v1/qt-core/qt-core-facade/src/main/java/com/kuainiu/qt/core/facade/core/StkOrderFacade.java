package com.kuainiu.qt.core.facade.core;

import com.kuainiu.qt.core.facade.request.*;
import com.kuainiu.qt.core.facade.response.StkAccountQueryResponse;
import com.kuainiu.qt.core.facade.response.StkInstrumentQueryResponse;
import com.kuainiu.qt.core.facade.response.StkOrderCommitResponse;
import com.kuainiu.qt.core.facade.response.StkOrderQueryResponse;
import com.kuainiu.qt.core.facade.response.StkPositionQueryResponse;

/**
 * 委托交易接口
 * User: ckhero
 * Date: 2019/5/16
 * Time: 7:26 PM
 */
public interface StkOrderFacade {

    /**
     * 股票委托
     * @param request
     * @return
     */
    public StkOrderCommitResponse stkOrderCommit(StkOrderCommitRequest request);
}
