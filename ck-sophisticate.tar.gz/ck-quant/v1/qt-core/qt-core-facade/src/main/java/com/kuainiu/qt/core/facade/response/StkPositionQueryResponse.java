package com.kuainiu.qt.core.facade.response;

import com.kuainiu.qt.core.facade.bean.StkPositionFacadeBean;

import java.math.BigDecimal;

/**
 * 股票仓位查询
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/22
 * Time: 8:50 PM
 */
public class StkPositionQueryResponse extends BaseCoreResponse {

    private StkPositionFacadeBean data;

    public StkPositionFacadeBean getData() {
        return data;
    }

    public void setData(StkPositionFacadeBean data) {
        this.data = data;
    }
}
