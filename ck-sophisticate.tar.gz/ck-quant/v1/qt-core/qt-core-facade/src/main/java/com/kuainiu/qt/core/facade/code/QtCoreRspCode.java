package com.kuainiu.qt.core.facade.code;


/**
 * 目前统一使用11位，前三位为子系统码，中间4位为子系统模块功能码，最后四位为逻辑异常码
 * 0001 - biz
 * 0002 - service
 */
public enum QtCoreRspCode  {

    SUCCESS("成功", "10"),
    SUCCESS_CDOE_FACADE("外部系统处理成功", "0"),
    FAIL("失败", "20"),

    /**
     * 业务类异常 2XXX,外部需回滚
     */
    ERR_REPEAT_SUBMIT("重复的交易流水", "00100012001"),
    ERR_NOT_SUCH_CHANNEL_TRANSTYPE("不支持的渠道或者交易类型", "00100012002"),


    /**
     * 系统内异常 3xxx
     */
    ERR_SYS_ERROR("交易核心系统错误", "00100013001"),
    ERR_SYS_SER_BEAN_NULL_ERROR("service层入参Bean为空", "00100013002"),
    ERR_COPY_LIST_FAIL("Copy list fail", "00100013003"),

    /**
     * 系统间问题 ,4xxx
     */
    //外部系统（策略那边）依赖这个code进行重试
    ERR_SYS_TIMEOUT_NEED_RETRY("请求TRANS超时，需要重试", "00100014001"),
    ERR_PARAM_ERROR("参数错误", "00100014002"),
    ERR_CALL_TRANS_ERROR("调用交易系统错误", "00100014003"),
    ERR_PARAM_PORTIFILE_CODE_REQUIRED("投资组合不能为空", "00100014004"),
    ERR_PARAM_CHANNEL_CODE_REQUIRED("渠道号不能为空", "00100014005"),
    ERR_PARAM_ASSET_NO_REQUIRED("交易代码不能为空", "00100014006"),
    ERR_PARAM_ASSET_NO_FORMAT("无效的交易代码", "00100014007"),
    ERR_PARAM_ACCOUNT_NO_REQUIRED("账户号不能为空", "00100014008"),
    ERR_PARAM_ACCES_TOKEN_REQUIRED("accessToken不能为空", "00100014009"),
    ERR_PARAM_FRONT_ORDER_ID_REQUIRED("前置订单号不能为空", "00100014010"),
    ERR_PARAM_POSITION_EFFECT_REQUIRED("开平不能为空", "00100014011"),
    ERR_PARAM_TRANS_TYPE_REQUIRED("交易类型不能为空", "00100014012"),
    ERR_PARAM_AMOUNT_REQUIRED("手数必须大于0", "00100014013"),
    ERR_PARAM_LIMIT_PRICE_REQUIRED("价格不能为空", "00100014014"),
    ERR_PARAM_SYSID_NO_REQUIRED("系统编号不能为空", "00100014015"),
    ERR_PARAM_REMOTE_REQUIRED("是否远程不能为空", "00100014016"),

    ERR_DUBBO_REMOTE_NO_PROVIDER("DUBBO服务无服务提供者（trans系统）", "00100014017"),
    ERR_DUBBO_REMOTE_CONNECT_TIMEOUT("请求超时(测试环境一般是券商系统不稳定导致的)", "00100014018"),
    ERR_PARAM_STRATEGY_CODE("策略编号不能为空", "00100014019"),
    ERR_PARAM_ACCOUNT_CODE("账户编号不能为空", "00100014020"),


    /**
     *  业务类异常 5XXX,外部不用回滚
     */
    ERR_BUSI_ERROR("业务错误", "00100015001"),
    ERR_PORTFOLIO_QRY_FAIL("投资组合查询失败", "00100015600"),
    ERR_STRATEGY_MAP_QRY_FAIL("策略查询失败", "00100015602"),
    ERR_STRATEGY_MAP_QRY_NULL("策略查询结果为空，请检查策略号", "00100015603"),
    ERR_NOT_IN_MARKET_TIME("不在交易时间内", "00100015604"),


    /**
     * 股票相关 52XX
     */
    ERR_STK_ORDER_COMMIT_FAIL("股票委托失败", "00100015200"),
    ERR_STK_ORDER_QRY_FAIL("股票委托查询失败", "00100015201"),
    ERR_STK_ACCOUNT_QRY_FAIL("股票账户查询失败", "00100015202"),
    ERR_STK_POSITION_QRY_FAIL("股票仓位查询失败", "00100015203"),

    /**
     * 期货相关 54XX
     */
    ERR_FUTURES_ORDER_COMMIT("期货委托失败", "00100015401"),
    ERR_FUTURES_ORDER_CANCEL("期货委托失败", "00100015402"),
    ERR_FUTURES_ORDER_QRY("期货委托查询失败", "00100015403"),
    ERR_FUTURES_ACCOUNT_QRY("期货账户查询失败", "00100015404"),
    ERR_FUTURES_POSITION_QRY("期货仓位查询失败", "00100015405"),
    ERR_FUTURES_ORDER_ORIGIN_SER_BEAN("期货委托原始数据serBean不能为空", "00100015406"),

    /**
     *  数据库操作异常，6XXX
     */
    ERR_FUTURES_ORDER_ORIGIN_ADD_FAIL("期货委托原始数据添加异常", "00100026000"),
    ERR_FUTURES_ORDER_ORIGIN_REPEAT_SUBMIT("期货委托重复提交", "001000260001"),


    ERR_DBERR("db错误", "00100011022"),
    SYS_ERROR("系统错误", "00100011020"),
    SYS_TIMEOUT("系统超时", "00100011021");


    private String code;

    private String msg;

    private QtCoreRspCode(String message, String code){
        this.code = code;
        this.msg = message;
    }

    public String getCode(){
        return code;
    }

    public String getMessage(){
        return msg;
    }

    public static QtCoreRspCode getEnum(String value){
        QtCoreRspCode[] crc = QtCoreRspCode.values();
        for (int i = 0; i < crc.length; i++) {
            if (crc[i].getCode().equals(value)) {
                return crc[i];
            }
        }
        return null;
    }

    public static QtCoreRspCode getEnumOrDefault(String value){
        QtCoreRspCode[] crc = QtCoreRspCode.values();
        for (int i = 0; i < crc.length; i++) {
            if (crc[i].getCode().equals(value)) {
                return crc[i];
            }
        }
        return ERR_SYS_ERROR;
    }
}
