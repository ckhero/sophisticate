package com.kuainiu.qt.core.service;


import com.kuainiu.qt.core.service.bean.TransRuleConSerBean;
import com.kuainiu.qt.core.service.bean.TransRuleResSerBean;
import com.kuainiu.qt.core.service.exception.ServiceException;

/**
 * Created by lucaszhuang .
 */
public interface OrderTransRuleService {

    /**
     * 交易规则路由
     * @param transRuleConBean
     * @return
     */
    public TransRuleResSerBean stkTransRule(TransRuleConSerBean transRuleConBean) throws ServiceException;
}
