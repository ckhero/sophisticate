package com.kuainiu.qt.core.service.bean;

import lombok.Data;

import java.util.Map;

@Data
public class StrategyMapSerBean extends BaseSerBean {
    private Map<String, StrategySerBean> data;
}
