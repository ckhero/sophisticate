package com.kuainiu.qt.core.service.bean;

import com.kuainiu.qt.trans.facade.code.QtTransRspCode;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/20
 * Time: 11:31 AM
 */
public class BaseSerBean {
}
