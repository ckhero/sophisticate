package com.kuainiu.qt.core.service.bean;

import lombok.Data;

import java.math.BigDecimal;
@Data
public class AccountSerBean {
    private Long id;

    private String realAccountCode;

    private String accountCode;

    private String accountName;

    private BigDecimal initAmount;

    private BigDecimal balanceAmount;

    private BigDecimal frzBalanceAmount;

    private String channelCode;

    private String accountType;

    private String status;

    private BigDecimal balanceAmountForAdd = BigDecimal.ZERO;

    private BigDecimal frzBalanceAmountForAdd = BigDecimal.ZERO;
}
