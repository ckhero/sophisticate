package com.kuainiu.qt.core.service.bean;


import com.kuainiu.qt.core.facade.bean.StkFeeFacadeBean;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/23
 * Time: 3:36 PM
 */
@Data
public class StkAccountSerBean extends BaseSerBean {

    private String portfolioCode;

    private String strategyCode;

    private String accountCode;

    private String channelCode;

    /**
     * 可用余额
     */
    private BigDecimal cash;

    /**
     * 冻结余额
     */
    private BigDecimal frzCash;

    /**
     * 市值，单位(元)
     */
    private BigDecimal marketValue;

    /**
     * 总权益，单位(元)
     */
    private BigDecimal totalValue;

    /**
     * 当日费用明细
     */
    private StkFeeFacadeBean transactionCost;

    /**
     * 账户下的仓位
     */
    private List<StkPositionSerBean> positions;
}
