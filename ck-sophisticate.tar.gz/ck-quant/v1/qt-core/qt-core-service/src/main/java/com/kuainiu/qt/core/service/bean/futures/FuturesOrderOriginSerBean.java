package com.kuainiu.qt.core.service.bean.futures;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/4
 * Time: 9:38 PM
 */
@Data
public class FuturesOrderOriginSerBean {
    private Long id;

    private String frontOrderId;

    private String sysId;

    private String portfolioCode;

    private String strategyCode;

    private String assetNo;

    private String channelCode;

    private Integer transType;

    private String positionEffect;

    private String transSide;

    private BigDecimal limitPrice;

    private Integer orderQty;

    private Date createTime;

    private Date updateTime;
}
