package com.kuainiu.qt.core.service.exception;



import com.kuainiu.qt.core.common.util.CommonConstant;
import com.kuainiu.qt.core.facade.code.QtCoreExternalRspCode;
import com.kuainiu.qt.core.facade.code.QtCoreRspCode;
import com.kuainiu.qt.core.facade.response.BaseCoreResponse;
import org.apache.commons.lang3.StringUtils;

import java.text.MessageFormat;

/**
 * Created by lucaszhuang.
 * 需回滚异常
 */
public class ServiceRuntimeException extends Exception {

  private QtCoreRspCode qtCoreRspCode;

  private String resultCode;

  private String msg;

  public ServiceRuntimeException(QtCoreRspCode qtCoreRspCode){
    this.qtCoreRspCode = qtCoreRspCode;
    this.resultCode = qtCoreRspCode.getCode();
    this.msg = qtCoreRspCode.getMessage();
  }

  public ServiceRuntimeException(QtCoreRspCode qtCoreRspCode, Throwable t){
    super(t);
    this.qtCoreRspCode = qtCoreRspCode;
    this.resultCode = qtCoreRspCode.getCode();
    this.msg = qtCoreRspCode.getMessage();
  }

  public ServiceRuntimeException(QtCoreRspCode qtCoreRspCode, String msg, Throwable t){
    super(t);
    this.qtCoreRspCode = qtCoreRspCode;
    this.resultCode = qtCoreRspCode.getCode();
    this.msg = qtCoreRspCode.getMessage();
    if (StringUtils.isNotBlank(msg)) {
      this.msg += CommonConstant.COMMA + msg;
    }
  }

  public ServiceRuntimeException(QtCoreRspCode qtCoreRspCode, String msg){
    this.qtCoreRspCode = qtCoreRspCode;
    this.resultCode = qtCoreRspCode.getCode();
    this.msg = qtCoreRspCode.getMessage();
    if (StringUtils.isNotBlank(msg)) {
      this.msg += CommonConstant.COMMA + msg;
    }
  }

  public void setResultCode(String resultCode){
    this.resultCode = resultCode;
  }

  public String getResultCode(){
    return resultCode;
  }

  public String getMsg(){
    return msg;
  }

  public void setMsg(String msg){
    this.msg = msg;
  }

  public void exceptionToResponse(BaseCoreResponse baseResponse){
    baseResponse.setCode(QtCoreExternalRspCode.getCodeBySysCode(this.getResultCode()));
    baseResponse.setMsg(this.getMsg());
//    baseResponse.setException(this);
  }



  public ServiceRuntimeException(String pattern, Object... arguments){
    super(MessageFormat.format(pattern, arguments));
  }
}