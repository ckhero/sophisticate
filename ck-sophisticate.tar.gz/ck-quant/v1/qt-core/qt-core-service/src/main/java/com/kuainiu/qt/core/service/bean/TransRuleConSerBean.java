package com.kuainiu.qt.core.service.bean;

import com.kuainiu.qt.core.common.code.ChannelCodeEnum;
import com.kuainiu.qt.core.common.code.ChildTransTypeEnum;
import com.kuainiu.qt.core.common.code.TransTypeEnum;

public class TransRuleConSerBean {

    private ChannelCodeEnum channelCodeEnum;
    private TransTypeEnum transType;

    public TransTypeEnum getTransType() {
        return transType;
    }

    public ChannelCodeEnum getChannelCodeEnum() {
        return channelCodeEnum;
    }

    public void setChannelCodeEnum(ChannelCodeEnum channelCodeEnum) {
        this.channelCodeEnum = channelCodeEnum;
    }

    public void setTransType(TransTypeEnum transType) {
        this.transType = transType;
    }
}
