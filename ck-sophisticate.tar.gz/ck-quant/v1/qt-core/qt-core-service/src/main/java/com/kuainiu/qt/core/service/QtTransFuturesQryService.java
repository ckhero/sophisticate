package com.kuainiu.qt.core.service;

import com.kuainiu.qt.core.service.bean.futures.*;
import com.kuainiu.qt.core.service.exception.ServiceException;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/6
 * Time: 7:14 PM
 */
public interface QtTransFuturesQryService {
    FuturesPositionSerBean qryFuturesPosition(FuturesPositionReqSerBean reqSerBean) throws ServiceException;

    FuturesAccountSerBean qryFuturesAccount(FuturesAccountReqSerBean reqSerBean) throws ServiceException;

    FuturesOrderSerBean qryFuturesOrder(FuturesOrderSerBean reqSerBean) throws ServiceException;
}
