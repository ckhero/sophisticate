package com.kuainiu.qt.core.service.bean;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/20
 * Time: 11:30 AM
 */
public class StkOrderReqSerBean extends BaseReqSerBean {

    private String frontOrderId;

    public String getFrontOrderId() {
        return frontOrderId;
    }

    public void setFrontOrderId(String frontOrderId) {
        this.frontOrderId = frontOrderId;
    }
}
