package com.kuainiu.qt.core.service.check;

import com.kuainiu.qt.core.service.exception.ServiceException;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/11/8
 * Time: 11:43 AM
 */
public interface MarketTimeCheck {
    void check() throws ServiceException;
}
