package com.kuainiu.qt.core.service.stk;

import com.kuainiu.qt.core.service.bean.OrderStkOriginSerBean;
import com.kuainiu.qt.core.service.exception.ServiceException;

public interface OrderStkService {
    /**
     * 原始交易数据落单
     * @param orderStkOriginSerBean
     * @return
     */
    public int createOrderStkOrigin(OrderStkOriginSerBean orderStkOriginSerBean) throws ServiceException;
}
