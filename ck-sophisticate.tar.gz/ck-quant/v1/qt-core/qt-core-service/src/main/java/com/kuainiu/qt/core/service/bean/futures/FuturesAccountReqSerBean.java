package com.kuainiu.qt.core.service.bean.futures;

import com.kuainiu.qt.core.service.bean.BaseReqSerBean;
import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/6
 * Time: 7:06 PM
 */
@Data
public class FuturesAccountReqSerBean extends BaseReqSerBean {
    private String accountCode;

    private String channelCode;

    private String portfolioCode;

    private String strategyCode;

}
