package com.kuainiu.qt.core.service.bean;

import lombok.Data;

import java.util.Map;

@Data
public class StrategySerBean {
    private Integer id;

    private String strategyCode;

    private String strategyType;

    private String portfolioCode;

    private String strategyName;

    private String strategyDesc;

    private String status;

    private Map<String, AccountSerBean> accountMap;
}
