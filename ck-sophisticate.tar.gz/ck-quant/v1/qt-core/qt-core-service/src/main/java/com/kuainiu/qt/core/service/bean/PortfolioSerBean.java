package com.kuainiu.qt.core.service.bean;

import com.kuainiu.qt.core.service.bean.futures.FuturesPositionReqSerBean;
import com.kuainiu.qt.core.service.bean.futures.FuturesPositionSerBean;
import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/18
 * Time: 3:41 PM
 */
@Data
public class PortfolioSerBean extends BaseSerBean {
    private BigDecimal cash;

    private BigDecimal frzCash;

    private BigDecimal totalReturns;

    private BigDecimal realtimeReturns;

    private BigDecimal dailyPnl;

    private BigDecimal marketValue;

    private BigDecimal totalValue;

    private BigDecimal units;

    private List<CashflowSerBean> portfolioCashflowList = new ArrayList<>();

    private BigDecimal transCost;

    private BigDecimal pnl;

    private Date startDate;

    private BigDecimal annualizedReturns;

    private List<StkPositionSerBean> stkPositions = new ArrayList<>();

    private List<FuturesPositionSerBean> futuresPositions = new ArrayList<>();
}
