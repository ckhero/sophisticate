package com.kuainiu.qt.core.service;

import com.kuainiu.qt.core.service.bean.StrategyMapSerBean;
import com.kuainiu.qt.core.service.bean.StrategyReqSerBean;
import com.kuainiu.qt.core.service.exception.ServiceException;

public interface QtTransStrategyService {
    StrategyMapSerBean qryMapBySgCode(StrategyReqSerBean reqSerBean) throws ServiceException;
}
