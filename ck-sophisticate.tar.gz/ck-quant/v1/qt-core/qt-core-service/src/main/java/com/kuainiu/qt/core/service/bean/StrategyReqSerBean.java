package com.kuainiu.qt.core.service.bean;

import lombok.Data;

@Data
public class StrategyReqSerBean extends BaseReqSerBean {
    private String strategyCode;
}
