package com.kuainiu.qt.core.service.bean;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/23
 * Time: 3:35 PM
 */
@Data
public class StkAccountReqSerBean extends BaseReqSerBean {

    private String portfolioCode;

    private String strategyCode;

    private String accountCode;
}
