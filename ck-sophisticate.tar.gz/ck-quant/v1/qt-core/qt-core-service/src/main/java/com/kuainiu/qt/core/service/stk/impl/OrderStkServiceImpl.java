package com.kuainiu.qt.core.service.stk.impl;

import com.alibaba.fastjson.JSON;
import com.kuainiu.qt.core.common.code.LogFormatCode;
import com.kuainiu.qt.core.common.util.BeanMapUtils;
import com.kuainiu.qt.core.common.util.CommonConstant;
import com.kuainiu.qt.core.common.util.LoggerUtils;
import com.kuainiu.qt.core.dal.dao.OrderStkOriginDao;
import com.kuainiu.qt.core.dal.entity.OrderStkOrigin;
import com.kuainiu.qt.core.facade.code.QtCoreRspCode;
import com.kuainiu.qt.core.service.bean.OrderStkOriginSerBean;
import com.kuainiu.qt.core.service.exception.ServiceException;
import com.kuainiu.qt.core.service.stk.OrderStkService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
@Slf4j
public class OrderStkServiceImpl implements OrderStkService {

    @Autowired
    private OrderStkOriginDao orderStkOriginDao;

    /**
     * 原始交易数据落单
     *
     * @param orderStkOriginSerBean
     * @return
     */
    @Override
    public int createOrderStkOrigin(OrderStkOriginSerBean orderStkOriginSerBean) throws ServiceException {
        if (null == orderStkOriginSerBean) {
            log.warn(LogFormatCode.MODEL_STK_ORDER_ORIGIN_M_D.getFormat(), QtCoreRspCode.ERR_SYS_SER_BEAN_NULL_ERROR.getMessage(), JSON.toJSONString(orderStkOriginSerBean));
            throw new ServiceException(QtCoreRspCode.ERR_SYS_SER_BEAN_NULL_ERROR);
        }

        Date now = new Date();
        OrderStkOrigin orderStkOrigin=new OrderStkOrigin();

        BeanMapUtils.map(orderStkOriginSerBean, orderStkOrigin);
        orderStkOrigin.setCreateTime(now);
        orderStkOrigin.setUpdateTime(now);

        try {
            int rowId = orderStkOriginDao.insertSelective(orderStkOrigin);
            if (CommonConstant.ZERO >= rowId) {
                throw new ServiceException(QtCoreRspCode.ERR_DBERR, orderStkOriginSerBean.toString());
            }
            return rowId;
        } catch (DuplicateKeyException e) {
            log.warn(LogFormatCode.MODEL_STK_ORDER_ORIGIN_M_D.getFormat(), QtCoreRspCode.ERR_REPEAT_SUBMIT.getMessage(), JSON.toJSONString(orderStkOriginSerBean));
            throw new ServiceException(QtCoreRspCode.ERR_REPEAT_SUBMIT, orderStkOriginSerBean.toString(), e);
        }

    }
}
