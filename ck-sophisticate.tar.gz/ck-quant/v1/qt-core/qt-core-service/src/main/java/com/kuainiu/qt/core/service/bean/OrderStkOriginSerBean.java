package com.kuainiu.qt.core.service.bean;

import com.kuainiu.qt.trans.facade.code.TransSideCode;
import lombok.Data;

import java.math.BigDecimal;
@Data
public class OrderStkOriginSerBean {
    private String frontOrderId;

    private String sysId;

    private String portfolioCode;

    private String strategyCode;

    private String accountCode;

    private String accessToken;

    private String assetNo;

    private String transBoard;

    private String channelCode;

    private Integer transType;

    private BigDecimal limitPrice;

    private Integer orderQty;

    private String transSide;

    private TransSideCode transSideCode;
}
