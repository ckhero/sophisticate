package com.kuainiu.qt.core.service;

import com.kuainiu.qt.core.service.bean.PortfolioSerBean;
import com.kuainiu.qt.core.service.bean.PortfolioReqSerBean;
import com.kuainiu.qt.core.service.exception.ServiceException;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/18
 * Time: 3:40 PM
 */
public interface QtTransPortfolioService {
    PortfolioSerBean qryPortfolio(PortfolioReqSerBean serBean) throws ServiceException;
}
