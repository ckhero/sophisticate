package com.kuainiu.qt.core.service;

import com.kuainiu.qt.core.service.bean.*;
import com.kuainiu.qt.core.service.bean.OrderStkOriginResSerBean;
import com.kuainiu.qt.core.service.exception.ServiceException;

public interface QtTransStkOrderService {

    public OrderStkOriginResSerBean stkOrderCommitMarket(OrderStkOriginSerBean var1) throws ServiceException;


    public OrderStkOriginResSerBean stkOrderCommitLimit(OrderStkOriginSerBean var1) throws ServiceException;

    public OrderStkOriginResSerBean stkOrderCommitLimitQk(OrderStkOriginSerBean var1) throws ServiceException;

    public OrderStkOriginResSerBean stkOrderCommitCancel(OrderStkOriginSerBean var1) throws ServiceException;
}
