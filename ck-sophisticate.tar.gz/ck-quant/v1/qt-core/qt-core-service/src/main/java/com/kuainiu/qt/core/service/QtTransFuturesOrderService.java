package com.kuainiu.qt.core.service;

import com.kuainiu.qt.core.service.bean.futures.FuturesOrderSerBean;
import com.kuainiu.qt.core.service.exception.ServiceException;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/5
 * Time: 2:13 PM
 */
public interface QtTransFuturesOrderService {

    FuturesOrderSerBean commitFuturesOrder(FuturesOrderSerBean serBean) throws ServiceException;
    FuturesOrderSerBean cancelFuturesOrder(FuturesOrderSerBean serBean) throws ServiceException;
}
