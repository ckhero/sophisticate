package com.kuainiu.qt.core.service.bean;

import lombok.Data;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/20
 * Time: 11:31 AM
 */
@Data
public class BaseReqSerBean {

    private String sysId;

    private Boolean remote;
}
