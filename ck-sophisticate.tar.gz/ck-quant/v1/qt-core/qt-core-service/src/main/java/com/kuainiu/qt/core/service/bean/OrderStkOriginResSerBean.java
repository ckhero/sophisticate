package com.kuainiu.qt.core.service.bean;

import lombok.Data;

import java.math.BigDecimal;
@Data
public class OrderStkOriginResSerBean extends BaseSerBean{

    private String frontOrderId;

    private String qtOrderId;

    private String portfolioCode;

    private String strategyCode;

    private String accountCode;

    private String assetNo;

    private String channelCode;

    private Integer transType;

    private Integer childTransType;

    private BigDecimal limitPrice;

    private Integer amount;
}
