package com.kuainiu.qt.core.service.bean;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/6/18
 * Time: 3:40 PM
 */
@Data
public class PortfolioReqSerBean extends BaseReqSerBean {
    private String portfolioCode;
}
