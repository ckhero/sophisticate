package com.kuainiu.qt.core.service.bean;

import lombok.Data;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/23
 * Time: 3:38 PM
 */
@Data
public class StkPositionReqSerBean extends BaseReqSerBean {
    /**
     * 股票代码
     */
    private String assetNo;

    private String transBoard;

    /**
     * 投资组合编号
     */
    private String portfolioCode;

    private String accountCode;

    private String strategyCode;

    /**
     * 渠道号
     */
    private String channelCode;
}
