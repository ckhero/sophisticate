package com.kuainiu.qt.core.service.bean;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/20
 * Time: 11:30 AM
 */
@Data
public class StkOrderSerBean extends BaseSerBean {

    private String portfolioCode;

    private String strategyCode;

    private String qtOrderId;

    private String frontOrderId;

    private String assetNo;

    private String channelCode;

    private String transBoard;

    private String priceMode;

    private String transSide;

    private BigDecimal limitPrice;

    private BigDecimal avgPrice;

    private Integer orderQty;

    private Integer filledQty;

    private Integer withdrawQty;

    private Integer unfilledQty;

    private BigDecimal transCost;

    private String submitStatus;

    private String status;

    private String message;

    private Date createTime;
}
