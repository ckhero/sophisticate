package com.kuainiu.qt.core.service.bean;

import lombok.Data;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/5/22
 * Time: 9:04 PM
 */
@Data
public class PositionSerBean extends BaseSerBean {

    /**
     * 股票代码
     */
    private String assetNo;

    private String transBoard;

    /**
     * 证券余额
     */
    private Integer amount;

    /**
     * 证券可用数量
     */
    private Integer sellableAmount;
}
