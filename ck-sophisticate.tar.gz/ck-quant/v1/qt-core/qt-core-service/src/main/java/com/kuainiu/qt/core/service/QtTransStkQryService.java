package com.kuainiu.qt.core.service;

import com.kuainiu.qt.core.service.bean.*;
import com.kuainiu.qt.core.service.exception.ServiceException;

public interface QtTransStkQryService {
    StkOrderSerBean queryStkOrder(StkOrderReqSerBean serBean) throws ServiceException;

    /**
     * 股票仓位查询
     * @param serBean
     * @return
     */
    StkPositionSerBean queryStkPosition(StkPositionReqSerBean serBean) throws ServiceException;

    /**
     * 股票账户查询
     * @param serBean
     * @return
     */
    StkAccountSerBean queryStkAccount(StkAccountReqSerBean serBean) throws ServiceException;
}
