package com.kuainiu.qt.core.service.check.impl;

import com.kuainiu.qt.core.common.util.QtDateUtils;
import com.kuainiu.qt.core.facade.code.QtCoreRspCode;
import com.kuainiu.qt.core.service.check.MarketTimeCheck;
import com.kuainiu.qt.core.service.exception.ServiceException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Created by IntelliJ IDEA.
 * User: ckhero
 * Date: 2019/11/8
 * Time: 11:44 AM
 */
@Service
@Slf4j
public class MarketTimeCheckImpl implements MarketTimeCheck {
    @Value("${market.time.check}")
    private boolean marketTimeCheck;

    @Override
    public void check() throws ServiceException {
        if (marketTimeCheck) {
            if (!QtDateUtils.isInMarketTime()) {
                throw new ServiceException(QtCoreRspCode.ERR_NOT_IN_MARKET_TIME);
            }
        }
    }
}
