package com.kuainiu.qt.core.service.bean;

import com.kuainiu.qt.trans.facade.code.TransSideCode;

import java.lang.reflect.Method;

public class TransRuleResSerBean {

    private Method transMethod=null;
    private Class transClass=null;
    private TransSideCode transSideCode=null;


    public Method getTransMethod() {
        return transMethod;
    }

    public void setTransMethod(Method transMethod) {
        this.transMethod = transMethod;
    }

    public Class getTransClass() {
        return transClass;
    }

    public void setTransClass(Class transClass) {
        this.transClass = transClass;
    }

    public TransSideCode getTransSideCode() {
        return transSideCode;
    }

    public void setTransSideCode(TransSideCode transSideCode) {
        this.transSideCode = transSideCode;
    }
}
